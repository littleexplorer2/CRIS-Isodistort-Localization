# 当前验证证据与缺口

## 2026-10-19 清单重建与官网材料整理

用户确认撤销全部旧冻结、归档清除旧下载/debug/checkpoint、删除开发程序的本地产物；
保留三晶体全部 k 标签的 nmod=0/1 下载范围，并明确保留、统一放置官网输出。
当前批次 `20261019-official-rebuild-v1`。机器重置记录见
[validation_reset_20261019.json](manifests/validation_reset_20261019.json)。

### 修改与实物证据

- 对 CRIS 工作文件做全树清点，排除 `.git`、实体 `.venv`、node_modules、字节码缓存等基础设施；
  理论资料和资源源码不修改。清点路径与排除项见 `output/validation/rebuild_20261019/workspace_inventory.json`。
- 重点读取两个官网树中的 651 张 HTML、523 个含 subgroup.cif 的输出目录及相关文件。
  53 张单查询结果列表按 (SG,basis,origin,s,i) 多重集与文件身份核对一致；叠加 IR 页另作参考，
  不混入单 IR 查询。精确分数解析复用既有审计器；无数值容差、无候选预计算。
- 官网 Method 1 候选 330；Method 2 已有 94（EuAl4 LD 22、NdNiO2 Y 48、4310 X 24），
  nmod 均从 IsoVIZ 文件读得为 0。Method 3 已有 40 个案例、77 个候选；Method 4 有 24 个
  案例根、额外 auto-origin/失败响应，22 个含 CIF 的输出目录。无 CIF 的响应不直接判作缺下载。
- NdNiO2 六个 Method 3 模式详情页原来放在案例上层，已按完整身份配对并归位，不重下。
  EuAl4 LD、NdNiO2 Y 原平铺目录移入 K/nmod0；Method 3 单候选统一放入 C01_SG<n>，
  六份误放在候选目录的结果列表归回案例根。169 项搬移、740 个文件逐项哈希一致，不覆盖。
- 额外检查官网树外 1,236 张 HTML；找到的 12 张列表/IR 页面均为已知 4310 历史修复副本，
  没有新发现 LD2/LD5 或 Y2/Y3/Y4 列表。旧清单的缺列表不能表述为候选文件未下载。
- 旧输出归档后清理了 14754 个工作文件；按用户后续保留官网材料的要求，
  从已校验归档恢复 97 个历史网页副本/资源文件和 3 个上传输入，分别放入网页 `_variants` 和
  当前报告的 `preserved_user_uploads`。净清理 14654 个旧文件、
  3582252350 字节。主官网原件全程保留，副本恢复后逐文件哈希一致。
- 官网文件总数和内容的保护核对、原路径到新路径、修复副本恢复、删除目标及归档明细均在
  `output/validation/rebuild_20261019/`。Method 4 的 24 份 daughter 输入、实验输入、用户 CSV/isoviz
  及理论资料保留。没有修改生产科学算法。

### 新冻结范围与当前缺口

下载清单和检验任务已冻结；状态按页面、文件、集合完整性、科学检验分别记录。
102 个 Method 2 查询中：99 个未取得完整页面集，2 个只缺共 5 张列表，1 个列表齐全。
已有 94 个四件套全部复用。未来新查询候选数须读真实官网列表，不用 Method 1 或本地结果猜测。
全部旧通过/失败/debug 进度不继承，新的数值检验状态是 `not_run`。

旧 Method 3/4 冻结和 4310 空列表冻结均撤销；已下载材料纳入固定参考清单，独立输入来源与
有限范围尚未核定，因此相应检验任务为 blocked，不冻结虚构的可执行案例，也不恢复污染闭包。
新的本地浏览器批次/运行签名仍未就绪；这不等于下载任务清单未冻结。

### 科学影响与依据

科学参数、单位、坐标和归一化不变；本轮改动是文件身份识别、路径、登记状态及运行门禁。
输入网格继续使用独立指定的母相/k/nmod/Types，身份解析只在只读参考审计中执行，不进入
本地计算链。来源与适用性检查参照 `reference_library/coverage.json` 的 C01/C02、
`reference_library/audit/implementation_audit.json` 及
`reference_library/latex/unsupported_algorithm_proofs.tex` 的 `sec:grid-duality`。
本轮实际审读相关合同与对偶证明段落，未声称重审全部参考文献。

直接原胞基 P 按行、k 为倒易分数列向量，相位 exp(2πi kᵀt)，倒格等价判据 PΔk∈Z³；
调用既有独立网格检查，102 查询 / 51 标签、0 issue。输入仍是有限有理代表，不证明非公度物理
或全参数域覆盖。归档以字节 SHA-256 不变量验证，身份以精确分数多重集验证；结构守恒、
模式正交与幅度回代不适用于纯归档搬移，本轮未执行这些数值验收。

### 验证命令与结果

- `verify_parametric_k_grid.py --manifest docs/manifests/official_output_download_manifest.json --report output/validation/rebuild_20261019/grid-report.json`：pass，0 issue，仅输入网格。
- `register_official_archive_reuse.py`：94 个既有 Method 2 候选四格式文件合同通过；官网树 4,753 文件、566,828,527 字节。
- 定向测试与根门禁初跑：108 passed、1 failed；失败为 Windows 测试硬链接创建被环境拒绝，未改生产代码绕过。
- 根门禁权限复查：`powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_cris.ps1 -m pytest tests_repo -q --tb=line`：34 passed，含架构门禁。
- 全套初跑：11 failed、1126 passed、33 skipped。10 项失败涉及沙箱内 `Wsl/E_ACCESSDENIED`，另 1 项依赖用户要求清除的旧 Method 3 debug 证据。该历史集成测试现在仅在清单明确为 unfrozen 时跳过，既有数学断言保留；未用旧结果重建输入或宣称通过。
- 全套权限复查：`powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_cris.ps1 -m pytest ISODISTORT/tests -q --tb=line`（另指定本批次 basetemp）：1166 passed、3 skipped、1 failed，1144.51 秒。唯一失败为 `test_local_archive_matches_registered_reuse_contract`；测试收集时加载的登记说明仍含 20261017，运行期间元数据已更新为本批次，内存与落盘清单不同。此轮不是全绿，原始日志保留。
- 文件稳定后的定向复查：`test_official_archive_reuse.py`、`test_method3_stage_b_feasibility_audit.py`、`test_method12_numeric_semantic_audit.py`、`test_parametric_k_grid.py`：75 passed、1 skipped，16.22 秒；包含上述唯一失败项。跳过项是已撤销旧冻结的 Method 3 历史集成检查。没有以放宽数值断言或恢复旧 debug 结果消除失败。
- 文件核查：4,953 个主官网存档文件逐项 SHA-256 一致，97 个历史修复副本/资源恢复一致；53 份单查询列表身份核对一致，2,757 条 HTML 资源引用可解析。主官网原件删除数为 0，页面内容修改数为 0。24 份独立 Method 4 daughter 输入哈希不变。
- 新生成测试产物清理：20 个临时目录/导出 CIF 目标已删除，目标清单和结果见 `verification_output_cleanup_targets.json`、`verification_output_cleanup.json`。保留本批次核对日志、报告和独立输入。
- JSON、当前文档链接和 `git -c core.safecrlf=false diff --check` 检查通过。下载/检验清单及支撑文件的最终 SHA-256 见 [冻结记录](manifests/checklist_freeze_20261019.json)。

日志和文件核查明细位于 `ISODISTORT/output/validation/rebuild_20261019/`，包括
`full-suite.log`、`full-suite-verified.log`、`final-targeted.log`、`repo-suite.log`、
`official_conservation.json`、`final_file_verification.json`。本次回归执行过真实 WSL 二进制，
但没有执行新冻结批次的逐候选科学验收；新任务的 `not_run`/blocked 状态不因工程测试通过而改变。

旧记录恢复方式见 [历史索引](history/README.md)。本报告的文件识别/哈希结果不代表新的科学验收。
