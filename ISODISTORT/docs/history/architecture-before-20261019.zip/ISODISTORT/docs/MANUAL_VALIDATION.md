# 当前手工与长时验证操作

下载步骤与路径只维护在 [DOWNLOAD_CHECKLIST.md](DOWNLOAD_CHECKLIST.md)。
检验任务见 [validation_checklist_20261019.json](manifests/validation_checklist_20261019.json)。
旧命令、输入签名、运行结果和 checkpoint 已在 [历史索引](history/README.md) 归档；不按旧进度续跑。

## 工程检查

从 `E:\CRIS` 运行；若执行策略禁止脚本，按下面的进程级 Bypass 调用，不修改系统策略。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_cris.ps1 -m pytest tests_repo -q --tb=line
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_cris.ps1 -m pytest ISODISTORT/tests -q --tb=line
git diff --check
```

## 独立输入网格复核

此工具只读取输入清单、母相和通用 k 表，不读取官网结果；结论仅限有限代表输入。
使用新的报告路径，避免覆盖冻结证据。

```powershell
.\.venv\Scripts\python.exe -X utf8 ISODISTORT/tests/manual/verify_parametric_k_grid.py --manifest ISODISTORT/docs/manifests/official_output_download_manifest.json --report ISODISTORT/output/validation/<新批次>/grid-report.json
```

## 文件清单与归档检查

主登记为 `docs/manifests/official_archive_reuse_20261019.json`，包含按内容识别的全部候选与文件指纹；
`official_result_list_stage_20261019.json` 分别记录列表、候选四件套和待检验状态。
一次性重建脚本和机器证据位于 `output/validation/rebuild_20261019/`，含已执行的归档/搬移步骤，
不可把有写操作的重建脚本当作日常审计重复执行。

`tests/manual/register_official_archive_reuse.py` 仅复核三个已知 Method 2 查询的文件合同，
输出 `docs/manifests/official_archive_reuse_known_method2.json`。它不是全部查询发现器或完整清单，
不能用它覆盖主登记；新增官网材料应先按完整查询身份与当前主登记核对。

## 本地重跑与只读对照

`local_web_output_refresh_manifest.json` 当前为 `unfrozen`；历史 runtime 路径保留为无有效签名的
兼容入口，旧下载器拒绝启动是预期行为。新的检验任务清单已经冻结，但缺少官网列表、独立
输入或运行签名的任务仍未达到执行条件。

Method 3/4 旧机器清单已撤销可执行案例；完整旧文件只在历史归档中。先证明输入来源与合同，
再生成新批次，不得为恢复工具运行而把官网结果回填为输入。

本地独立求解、导出并冻结之后，才可以调用公共只读比较入口：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_cris.ps1 -m tests.validation compare --local "<本地冻结CIF>" --reference "<官网CIF>" --json
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_cris.ps1 -m tests.validation batch --local-dir "<本地目录>" --reference-dir "<官网目录>" --json
```

母相、方法、k/nmod、IR/OPD、完整子群身份、单位/坐标/归一化、实际外部读取、配置/源码/依赖
和输出指纹必须登记；每个数值比较须引用已有理论合同和适用容差。不存在输入、结果或有效
配对时记未执行/不支持/inconclusive，不把零案例或进程成功退出记成科学通过。
