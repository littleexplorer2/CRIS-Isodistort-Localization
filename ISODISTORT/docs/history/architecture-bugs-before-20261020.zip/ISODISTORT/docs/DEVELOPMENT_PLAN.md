# 当前开发与验证计划

本文件只保存待办；已完成架构调整、理论影响和实测结果见
[验证报告](BUGFIX_VALIDATION_REPORT.md)。下载动作唯一入口是
[下载清单](DOWNLOAD_CHECKLIST.md)，任务状态见
[检验清单](manifests/validation_checklist_20261019.json)。

## 当前顺序

1. 补齐现有 Method 2 下载任务：102 查询保持不变，优先补 LD2/LD5、Y2/Y3/Y4
   共 5 张缺失列表，再按官网实际列表补其他查询；已有 94 个四件套继续引用原件。
2. 核定 Method 3/4 的独立输入、有限界限、daughter 指纹、基矢/原点及匹配合同。
   不使用官网结果反推输入，不恢复已撤销的闭包种子或 checkpoint。
3. 为满足前置条件的任务创建新运行签名，独立计算并冻结本地结果，再只读对照官网。
   工程回归和有限反例测试不能代替逐候选科学验收。
4. 在真实用户浏览器完成上传、连续动作、下载、取消、关闭及 GD 实际计算接收的人工验收；
   HTTP 自动化与转换器测试仅覆盖各自合同。

## 待修的程序漏洞

本轮已修复的缺陷及证据移入验证报告，不在这里重复维护。

2026-10-20 完成原定架构修改后，复审发现以下必须修复的问题，当前仅记录，不扩大本轮实现范围：

- P2：`application/workflows/service.py::export_archive` 对显式请求的候选编号静默取交集。
  请求 `[1,999]` 而现有候选为 `[1]` 时，实际只导出 1，仍报告完成、成功 1、失败 0。
  应在创建任务和快照前拒绝缺失编号，不能把遗漏请求算作完整完成。隔离反例见
  `output/validation/architecture_followup_20261020/workflows/review/reproduce_export_selection.json`。
- P2：`frontend/web/index.html::applyNmod` 使用 `parseInt`，非整数文本可能在发送请求前
  被截断为整数，绕过后端的严格整数输入合同。应完整解析并验证原值，拒绝小数和空值，
  覆盖 0..3、超域与指数表示的明确语义；不得只依赖 HTML 输入框类型。
  `1.9→1` 已在实际页面脚本复现，此问题会改变用户指定的科学输入。
- P2：`frontend/web/index.html::cancelExport` 的取消响应未检查发起时的 job_id。
  旧任务的迟到响应可把新任务的进度改成“已请求取消”，即使新任务仍在运行。
  后端已有 job_id 保护，此反例只证明前端状态误报；应按任务所有权拒绝过时成功/错误提示。
  两项页面反例见 `output/validation/architecture_followup_20261020/frontend/remaining-review.json`。

后续遇到最小反例须登记受影响合同与证据；仍未支持的物理类型、输入域及缺证明能力
继续按照 `reference_library/coverage.json` 拒绝或标记 inconclusive，不能视为已修复。

## 待执行的优化计划

- 完成缺失官网结果集合的身份、角色、资源引用和 SHA-256 审计；不存在的结果不造占位。
- 完成已定义三晶体、四 Method 的独立科学验证，保留 unsupported/diagnostic/inconclusive。
- 仅在真实性能基线指出瓶颈后优化会话/运行目录复制成本；优化须保持事务隔离和生成数据库完整性。
- 根据实际新增用例扩充可执行模块边界与数学反例，禁止重新引入已移除的旧入口或答案缓存。
