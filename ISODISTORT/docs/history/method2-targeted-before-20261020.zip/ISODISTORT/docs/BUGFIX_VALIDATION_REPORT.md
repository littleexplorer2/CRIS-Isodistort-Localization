# 当前验证证据与缺口

## 2026-10-20 连续修复与架构复审

持续范围为 ISODISTORT。按用户要求循环执行最小反例、修复、定向检查和独立复审，
本轮未启动全量回归、全量科学验证或官网对照。ISOVIZ_INPUT 和 GD 代码未修改。
旧报告已完整归档；本文只维护当前结论、在用证据与剩余缺口。

### 修复结果

- **查询和下载归属**：Method 1/2/3/4 共用查询失效入口。开始替换查询时清除
  对应列表、revision、筛选及关联模式；失败后不能下载被隐藏的旧候选/幅度。
  迟到成功仍接收服务器已提交的版本事实，但不恢复旧表或擦掉新请求的错误提示。
- **模式基与 Method 4**：所有来源的模式请求均绑定来源查询。应用不同 nmod、
  发起另一候选计算或更换上下文后，旧基不能被隐藏复用。Method 4 在读取文件和
  消费响应的异步边界复核同一已确认基；合法同基连续 daughter 分解保持可用。
  核心与只读快照共用完整模式上下文校验，在读取 daughter/调用分解器前拒绝
  候选、类型、物种范围、nmod 不匹配。可选 nmod 仅核对已有基，不自动重算。
- **物种范围**：显式空和加载母相后解析为空的范围不能扩大为全部物种；
  非法标量、布尔、列表元素和未知类型键明确拒绝，校验完毕才一次替换范围。
  禁用类型可保留 none，strain 不套用原子物种限制；尚无母相时允许声明非空范围，
  不把未知物种集合误判为空。工作流发布核心规范范围，页面缺字段显示 all，
  显式空显示 none，显示与再次提交一致。HTTP 原有较窄 JSON 输入域保持。
- **数值配置**：布尔值在转为 float/int 前拒绝，避免 true 成为容差 1 或 false
  成为无限额 0。合法数值、明确数值 0 哨兵、默认值和既有单位均不变。
- **失败反馈**：当前网络、JSON 解析和非对象 JSON 错误按请求/依赖身份显示，
  不因兼容事务推进 revision 而被吞。旧请求不能覆盖新状态。
  已发 ZIP 独立快照的本地失败按导出生命周期处理，更换母相后仍可报告下载失败；
  不放宽服务器旧版本 payload 的接收条件。

实现复用现有请求代次、模式上下文键、范围解析与事务，不保留旧逻辑作为并行分支。
共享测试替身仅同步公开属性，未复制科学算法或另建测试实现。

### 科学影响与依据

本轮涉及科学输入域及结果身份，不能按纯展示修改豁免。完整对象定义、假设、
正反例和逐步程序推导见
[架构合同第 5.5–5.7 节](reference_library/notes/ARCHITECTURE_CONTRACTS_20261019.md)，
能力/来源登记仍以 [coverage.json](reference_library/coverage.json) 和
[实现审计](reference_library/audit/implementation_audit.json) 为准。
这些是本项目程序合同推导，没有冒称外部数学或晶体学定理。

模式基身份使用候选 embedding、nmod、规范类型与解析物种集合的精确比较；
物种范围使用集合交集，显式非法/空输入不能变成缺省全选；
状态机使用请求序号、revision 和对象身份。未改变模式列、群作用、晶格对偶、
行基/分数坐标、Å 制位移、应变、归一化或最小二乘公式。
配置仍为正有限容差与明确的整数上限，本轮没有新增或放宽数值容差。
群闭包、物理守恒和数值逼近公式未改，相关科学证明不由工程测试替代。
测试使用独立构造的状态、受控 DOM/网络及调度替身；未读取官网结果参与求解，
未启动科学二进制，不能把合成模式数组或成功调度当成真实晶体科学验收。

### 当前验证证据

本机证据目录：`ISODISTORT/output/validation/architecture_loop_20261020/`。
完整命令和每轮原始日志见 `frontend/commands.txt`、
`review_application/commands.json`、`review_application/round2/commands.json`
及根 `commands.json`；所有修前和中间失败保留。

- 前端最终 `frontend/round5-final.log` / `.exit`：
  **215 passed、55 deselected，20.53 秒，退出码 0**。
  覆盖当前/倒序请求、来源查询、nmod、模式基、daughter 文件读取及响应消费、
  同基重复分解、ZIP 快照、失败反馈、范围显示/提交及实际 HTTP nmod 校验/传递。
  修前各轮反例为 10 failed、18 failed、1 failed/1 passed、
  当前本地失败 6 failed/6 passed、ZIP 本地失败 8 failed/8 passed、
  范围显示 2 failed/4 passed；逐轮结果不重复累计。
- 应用最终 `review_application/round2/final.log` / `.exit`：
  **231 passed、172 deselected，6.89 秒，退出码 0**。
  其中 163 项工作流工程测试和 68 项 session 范围/上下文/快照定向测试。
  原独立 scope/旧基反例修后拒绝进入分解器；非法范围的 8 个原探针均拒绝，
  且保留旧 scope 对象及内容。修前 19 failed/14 passed；后续空交集、
  非法范围、发布规范值、加载前兼容反例分别见对应 before 日志。
  中间两项 nmod=4 测试曾错误预期 ValueError，已改为既有 NotImplementedError，
  没有改变生产支持域或放宽断言。
- 配置 `config/after.log` / `.exit`：
  **33 passed、66 deselected，1.26 秒，退出码 0**。
  `config/before.log` 为确认行为缺陷的 14 failed/16 passed；
  更早日志中的一项消息措辞断言调整另行保留，不把它算作行为缺陷。
- 最终 ISODISTORT 分层、实际 wheel 和审计签名门禁 `gates-final.log` / `.exit`：
  **41 passed、5 deselected，12.02 秒，退出码 0**；筛除 ISOVIZ_INPUT 范围。
  模块定向共 **479 项**，与门禁分别记录，不代表完整套件通过。
- Ruff F/E9 最终通过。首次发现新测试的局部 `_parent` 遮蔽导入，最后只重命名
  该未使用变量；`lint-fix.json` 证明反向单点替换能恢复此前完整测试文件指纹，
  生产文件未变。受影响重复 daughter 6 例重跑通过，不再累加至 479。
  首次 Ruff 失败、首次门禁 41 通过和旧快照均保留；最终 `git diff --check` 通过。

独立复审见 `review_frontend/independent-review.json`：8 个组合场景及两条原始
transport/ZIP 反例通过。8 场景初次探针错误要求 Method 3 导出包含 IR 列，
实际合同是 embedding 表；改为核对新候选 index 与实际导出列后通过，
初次脚本/失败日志均保留，未改变生产源码或科学期望来迎合测试。
这些独立探针对应前端 round4；最终 scope 局部变更经独立静态复核，
并核验 owner 的 6 个新增例及此前 209 例重跑结果，未声称独立探针在另一指纹运行。

最后只读复审覆盖 HTTP → workflows → session → backend 的实际调用，
查询/选择/模式基/Method 4/导出归属、输入解析和配置域、比较器的不可变快照/
空批次/strict 状态、来源签名/报告发布及服务器关闭所有权。
在此审读范围内，**未再确认仍须修复的架构漏洞**。这不是逐行形式化验证，
也不保证所有输入组合无 bug；小的展示或性能优化未作为必须修改项。
根代理审读范围及指纹见 `root-review.json`，应用独立复核见对应 review-conclusion。

`run-source.json` 固定最终 89 份源码/配置/测试文件和 7 项依赖；
`actual-runner-runtime.json` 记录 run_cris.ps1 实际使用的 Python 3.12.5 基础解释器
及共享 .venv 依赖。`final-verification.json` 核对最终门禁期间无漂移、
6 份本轮未改的规则/包装器原字节、8 份归档恢复字节和 35 项冻结文件指纹。
冻结记录仅更新计划、报告和历史索引三份支撑文档至 revision 8，
官网下载/检验范围、独立输入和科学验收合同不变，旧运行签名不可复用。
临时目录清理只针对本轮证据根内经绝对路径和 reparse point 检查的目标，
见 `cleanup-plan.json` / `cleanup-result.json`；原始反例、日志及指纹保留。

共享回归计数仅为本次用户请求加一，当前 **1/5**。
子代理、修复迭代和定向测试不另计；用户已明确拒绝全量，本轮没有全量授权提示，
没有把未运行记作通过或再次归零。

### 仍存在的验收缺口与历史入口

- Method 3/4 的独立输入、有限界限和逐候选科学验收缺口保持，未满足前置条件的
  任务仍 blocked/not_run；未支持物理类型/输入域仍拒绝或标为 inconclusive。
- 真实用户浏览器完整操作、GD 实际计算接收、长时 GenDB 中途取消没有本轮人工验收。
  HTTP/DOM/调度替身的通过不能替代这些验收。
- 本轮没有新官网下载或重新盘点官网全集；动作和路径以
  [下载清单](DOWNLOAD_CHECKLIST.md) 为准，后续工作只维护在
  [开发计划](DEVELOPMENT_PLAN.md)。ISOVIZ_INPUT 继续延后。

历史架构迁移、测试整合、安装/启动器、WSL 和前几轮查询修复的完整记录，
连同当时的真实回归结果及限制，已逐字节保存在
[归档索引](history/README.md) 所列 `architecture-loop-before-20261020.zip` 中。
旧结果只证明旧指纹的相应范围，不能作为当前代码全量通过的证据。
当前理论与来源入口持续保留在 reference_library，不被历史状态覆盖。
