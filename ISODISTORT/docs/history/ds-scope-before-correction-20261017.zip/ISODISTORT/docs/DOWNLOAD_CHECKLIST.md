# ISODISTORT 官网有限全量下载清单（人工动作与目录）

本文件是人工下载动作与目录的唯一入口。2026-10-16 重置后，当前阶段先把**官网三母相的
有限全量输出**下载完成，再重建本地网页版刷新清单并重新开始验证与 debug。作废范围、
归档指纹与开放上界见[重置记录](manifests/validation_reset_20261016.json)；范围枚举的证据
与不确定点见 `../output/tmp/official_scope/`（临时研究产物）。机器可读范围见
[official_output_download_manifest.json](manifests/official_output_download_manifest.json)。
完成后的逐例结论写入 [BUGFIX_VALIDATION_REPORT.md](BUGFIX_VALIDATION_REPORT.md)。

## 0. 硬性边界

- `output_compare/` 与 `webpage_info/` 永远只读：已登记的 2026-08…10 官网归档只登记、
  不重下，也不把新下载混入其中（其文件清单指纹已登记，不能失效）。
- 新官网材料写入批次根
  `ISODISTORT/output/validation/official_full_download/20261016-official-full-v1/`。
  该目录是**官网参考只读区**：只由用户的下载动作写入；之后只允许只读审计读取，
  禁止进入预处理、搜索、筛选、模式构造、归一化、拟合、缓存、导出的任何一环。
- 官网页面里的候选全集、子群/setting 答案、模式基、振幅、归一化因子不得用于替代本地
  求解，也不得从结果页反推输入；上传或改名不改变数据来源与角色。
- 有限性：只下载本清单冻结的项。参数化 k 必须先给参数值；Method 3/4 必须先给上界。
- 下载即登记：每项记录查询/候选身份、文件清单、字节数与 SHA-256；官网确实未提供者记
  `not_available`，禁止补造或用别的案例顶替。

## 1. 范围总表（有限可判定集）

| 母相 | Method 1 | Method 2 固定特殊 k | Method 2 参数化 k | Method 3 | Method 4 |
|---|---|---|---|---|---|
| `EuAl4 Parent.cif` (#139) | 123 候选已归档 → 只登记 | 5 标签 × nmod{0,1} = 10 查询（可立即开始） | 10 标签：`LD g=1/6` 已核定，其余 9 待参数值 | 闭包，待 `k_max`/`c_max` | 12 角色起，待上界 |
| `NdNiO2 own.cif` (#123) | 82 已归档 → 只登记 | 6 标签 × 2 = 12 查询（可立即开始） | 15 标签：`Y a=1/3` 已核定，其余 14 待参数值 | 同上 | 同上 |
| `4310_tetra.cif` (#139) | 125 已归档 → 只登记 | 5 标签 × 2 = 10 查询（可立即开始） | 10 标签：全部待参数值（已归档 X 点 24 候选只登记） | 官网目录为空，需新建 | 官网目录为空，需新建 |

固定特殊 k 标签（无自由参数；来源 `ISODISTORT/backend/tables/kpoints_official.py`，
已与 `webpage_info/<母相>/2*.html` 的 k 下拉逐条核对一致）：

- #139（EuAl4、4310）：`GM (0,0,0)`、`X (1/2,1/2,0)`、`M (1,1,1)`、`N (1/2,0,1/2)`、
  `P (1/2,1/2,1/2)`
- #123（NdNiO2）：`GM (0,0,0)`、`M (1/2,1/2,0)`、`X (0,1/2,0)`、`A (1/2,1/2,1/2)`、
  `R (0,1/2,1/2)`、`Z (0,0,1/2)`

## 2. 目录、命名与文件门禁

批次根：`ISODISTORT/output/validation/official_full_download/20261016-official-full-v1/`

```text
<根>/<母相>/官网/Method2/<K>_nmod0/          # K = GM/X/M/N/P/A/R/Z
<根>/<母相>/官网/Method2/<K>_nmod1/
<根>/<母相>/官网/Method2/<IR>_<OPD>/         # 每个候选一个目录
<根>/<母相>/官网/Method3/<稳定案例号>/
<根>/<母相>/官网/Method4/<稳定案例号>/
<根>/<母相>/官网补页/Method4/               # 仅 EuAl4 G05 auto-origin basis
```

每个查询/案例目录内的必备文件：

| 文件 | 要求 |
|---|---|
| `result_table.html` | Method 2/3 的完整结果表原页；必须含 `Finish selecting the distortion mode` 与候选行，或明确显示 `There are no subgroups` 加 `Try again`。只含输入控件的搜索页不能代替 |
| `<IR>_<OPD>/subgroup.cif` | 结果表中**每一个**候选一份，非空 |
| `<IR>_<OPD>/data.isoviz` | 同上 |
| `<IR>_<OPD>/topas.str` | 同上 |
| `<IR>_<OPD>/complete_modes_details.html` | 同上，含完整模式标签与顺序 |
| `*_files` 资源目录 | 浏览器“网页，完整”生成的资源目录保持原名，不计入候选核心文件 |

命名：候选目录用 `<IR>_<OPD>`（如 `X1+_P1`、`LD1_C1`）；Method 3/4 多候选用
`C01_SG<n>`、`C02_SG<n>`…，按结果行顺序，避免同名覆盖。HTML 保留 `.html`/`.htm` 后缀与
原名，审计按内容角色识别，不按文件名。
官网不提供本地网页版的 TXT/CSV 合计导出，这不算官网缺件。

## 3. A 阶段（可立即开始）：Method 2 固定特殊 k

每个查询：打开官网 Method 2 → 选 k 标签（固定点无需参数）→
`# of independent incommensurate modulations` 取 `0`（nmod0）或 `1`（nmod1）→ 提交 →
保存完整结果表 → 对结果表里每个候选保存四件套。

| 母相 | k 标签 | Kovalev | 坐标 | nmod=0 候选数（审计参考） | nmod=1 |
|---|---|---|---|---|---|
| `EuAl4 Parent.cif` | GM | k14 | (0,0,0) | 10 | 未知，下载后登记 |
| `EuAl4 Parent.cif` | X | k13 | (1/2,1/2,0) | 24 | 未知 |
| `EuAl4 Parent.cif` | M | k15 | (1,1,1) | 9 | 未知 |
| `EuAl4 Parent.cif` | N | k11 | (1/2,0,1/2) | 52 | 未知 |
| `EuAl4 Parent.cif` | P | k12 | (1/2,1/2,1/2) | 28 | 未知 |
| `NdNiO2 own.cif` | GM | k17 | (0,0,0) | 11 | 未知 |
| `NdNiO2 own.cif` | M | k18 | (1/2,1/2,0) | 12 | 未知 |
| `NdNiO2 own.cif` | X | k15 | (0,1/2,0) | 18 | 未知 |
| `NdNiO2 own.cif` | A | k20 | (1/2,1/2,1/2) | 11 | 未知 |
| `NdNiO2 own.cif` | R | k16 | (0,1/2,1/2) | 21 | 未知 |
| `NdNiO2 own.cif` | Z | k19 | (0,0,1/2) | 9 | 未知 |
| `4310_tetra.cif` | GM | k14 | (0,0,0) | 11 | 未知 |
| `4310_tetra.cif` | X | k13 | (1/2,1/2,0) | 24 | 未知 |
| `4310_tetra.cif` | M | k15 | (1,1,1) | 10 | 未知 |
| `4310_tetra.cif` | N | k11 | (1/2,0,1/2) | 52 | 未知 |
| `4310_tetra.cif` | P | k12 | (1/2,1/2,1/2) | 28 | 未知 |

计数口径：`output_compare/<母相>/官网/Method1/` 的候选目录按 IR 前缀分区，三母相合计
123/82/125，与目录总数、冻结 manifest、`method_outputs_static_current_20261005.json`
自洽。它是**审计参考**，不是官网 Method 2 的预定答案，也不能决定其它 k 点的期望值。
“Method 1 分区 ⊆ Method 2 候选集”目前只有一个点被独立证实：4310 `X`
（24 个 (IR, 子群类) 身份键相同、`subgroup.cif` 除注释空格逐字节相同、
`!numberOfModulations` 全为 0）；其余标签只是约定，不能当结论。

`nmod` 只取 0 与 1。旧清单约定 `nmod≥2` 与 `nmod=1` 语义重复故不下载；本轮没有重新证明
该约定，若你要字面完整可另加，但必须单独登记。

4310 `X` nmod=0 的四件套与旧归档重复。两种做法都可，需在批次记录里写明选了哪种：

- 字面完整：照下载，与旧归档重复也保留；
- 去重：只存 `result_table.html`，并在审计里登记“候选身份与已归档 Method 1 相同”。

## 4. A 阶段：官网补页 —— EuAl4 Method 4 G05 auto-origin 的 basis/matching 页

> **状态：2026-10-17 已补齐并完成只读核对（`pass_with_warnings`）。** 文件落在
> `output_compare/EuAl4 Parent.cif/官网/Method4/G05/auto-origin/ISODISTORT_ distorted structure (basis).html`
> （SHA-256 `9e2bfc515d6c13ef7e322041fe16d162976d08936d92dc51193f2e289d020c9a`，9055 B）＋同名
> `_files/` 资源目录（5 个文件，与显式那份相同）。目录、文件名、页面角色（title/h1 均为
> `ISODISTORT: distorted structure (basis)`）与隐藏字段（`origintype=method4`、`spacegroup=139 I4/mmm`）
> 全部正确，且与显式那份**不是同一份**（后者 SHA-256 `ce01fea7…`）。
>
> **保留的警告**：新页与显式那份**只差一个隐藏字段**（服务端会话文件名
> `isodistort_50588.iso` vs `isodistort_18838.iso`），其余控件态完全相同，都是该步表单的**默认态**
> （`inputbasis=list`、基矢=单位阵、`chooseorigin=false`、`origin=(0,0,0)`、`trynearest=true`、`dmax=1`）。
> 因此这页**不能证明** auto-origin 那次提交的超胞基矢与 `Automatic origin detection` 选择；清单
> 第 4.3 节要求的“提交前截图/PDF”仍然缺（目录里只有 2026-09-27 的旧截图）。审计旧记录
> `automatic_origin_checked_in_saved_html: true` 也**无法**由这份 HTML 支持——两份 basis 页都是
> `chooseorigin=false`。要关闭该 warning 只能补一张提交前截图；在此之前保持
> `pass_with_warnings`，且**不得**改写已有数值证据。
>
> 为它准备的落盘目录 `…/official_full_download/20261016-official-full-v1/EuAl4 Parent.cif/官网补页/`
> 已在核对后按用户要求删除（删除前确认 0 个文件）。以下 4.1–4.6 保留为操作与验收记录。

### 4.1 缺的是什么

`auto-origin/` 目录里已有 `subgroup.cif`、`topas.str`、`data.isoviz`、
`ISODISTORT_ distortion.html`（结果页）、`ISODISTORT_ complete modes details.html` 和填写完成
的截图 `Screenshot 2026-09-27 204517.png`，**缺**该次运行的
`ISODISTORT_ distorted structure (basis).html`（basis/matching 输入页）。同案的显式原点那次
（`G05/`）有这页（SHA-256 `ce01fea7520cce2fe92a9075c54ce0356d51df67f5e49cc481967e27b721b26c`），
不能拿它冒充 auto-origin 那次。两次运行的子群身份相同（见 4.5），缺的是 auto-origin 那次
“超胞基矢 + 原点处理 + 匹配方式”的提交态记录，属**证据完整性**缺口，不是数值缺口。

### 4.2 上传哪个结构（冻结输入，不得改动）

| 项 | 值 |
|---|---|
| 母相 | `experiment_data/EuAl4 Parent.cif`，SHA-256 `2a01942bff7aa74d6156e4907de207ff864b134ccdc85f38f88d53e2d6ebf5e7` |
| 上传的 daughter CIF | `ISODISTORT/output/validation/method4_inputs/EuAl4/G05-origin-shift/daughter.cif` |
| daughter SHA-256 | `a503025301b508690dcf3941f2080d39f1abd7d440ca0cef63a010a875a32dda`（1214 B，Eu2Al8，10 原子） |
| Types | `strain` + 全物种 `displacive`（改动后要按页面提示点 `Change` 才生效） |

不要重新生成 daughter CIF；上传的就是这份哈希固定的文件。

### 4.3 官网操作（两步）

**第一步：Method 4 入口页**

1. 打开官网载入母相 CIF，Types 设为 strain + 全物种 displacive。
2. `Upload distorted structure from CIF file:` 选 4.2 的 `daughter.cif`。
3. `Atom-matching method:` 选 `nearest-site`；`Robust distance threshold` 不启用（留默认）。
4. `Known origin shift (daughter fractional x,y,z; optional):` **留空**。这是 auto-origin 那次
   与显式那次唯一的输入差别：显式那次填 daughter 分数坐标 `0.125, 0.25, 0.0`，即母相分数
   坐标 `(-0.25, -0.125, -0.125)`。
5. 点 `OK` 进入第二步。

**第二步：`ISODISTORT: distorted structure (basis)` 页（就是缺的那一页）**

| 控件（官方字段名） | 应选/应填 | 说明 |
|---|---|---|
| 基矢选择（`inputbasis` 的 `list` + `basisselect`，或 `specify` + `basis11..basis33`） | 选到目标超胞，或选 `specify` 后逐格填 | 目标超胞基矢按行 `(0,1,1)`、`(1,0,0)`、`(0,0,-1)`；`specify` 时九个整数按 `0 1 1 / 1 0 0 / 0 0 -1` 填，保序保号 |
| `Automatic origin detection`（`chooseorigin=true`） | **选它** | auto-origin 那次的定义；不要选 `Specify origin as` |
| `Wyckoff-site matching`（`trynearest=true`） | 选它 | 对应 `nearest-site` |
| `More robust but slower method`（`dmax`） | 不启用，留默认 | 与两份已归档运行一致（robust 未启用） |

**提交前先截屏或打印 PDF**，把上面四项的填写状态拍下来：保存下来的 HTML 只能证明表单结构，
不能证明提交时的勾选状态。

### 4.4 保存到哪、怎么命名

```text
ISODISTORT/output/validation/official_full_download/20261016-official-full-v1/EuAl4 Parent.cif/官网补页/Method4/
```

- 用浏览器“网页，完整”保存第二步页面，保持原名 `ISODISTORT_ distorted structure (basis).html`，
  连同 `ISODISTORT_ distorted structure (basis)_files/` 资源目录一起放入；HTML 按原名引用资源，
  不要改名或只存单文件。
- 官网若同时给出结果页或幅度表，按官网原文件名一并放入本目录。
- 截图/PDF 建议命名 `controls-auto-origin-<YYYYMMDD-HHMMSS>.png`，并注明是提交前状态。

### 4.5 验收（新页面必须满足）

1. 标题（`<title>`/`<h1>`）为 `ISODISTORT: distorted structure (basis)`，审计角色等价于
   `distorted_structure_basis`。
2. 该次分解的子群身份与 `auto-origin/` 已有产物一致：`SG 1 (P1)`、
   basis `{(0,1,1),(1,0,0),(0,0,-1)}`、origin `(-0.25,-0.125,-0.125)`、`s=2`、`i=32`。
3. 幅度表与 `auto-origin/` 已有件一致：30 个 displacive + 6 个 strain 模式；例如
   `[0,0,0]GM2+(a)[Al1:d:dsp]B2(a)` 的 `As=-0.78141 / Ap=-0.55254`、
   `[0,0,0]GM5+(a,b)[Al1:d:dsp]E(a)` 的 `As=0.52824 / Ap=0.37352`。
4. 新页面不得覆盖 `G05/` 里的显式原点那份；若与它逐字节相同，必须在审计记录里写明
   “与显式原点页相同”，不能当成独立证据。

**已知的旧证据矛盾（写进审计，不要掩盖）**：官网审计把本案例记为
`automatic_origin_checked_in_saved_html: true`，但已归档的显式原点那次 basis 页里
`chooseorigin=false`（`Specify origin`，`origin1..3 = 0,0,0`）。所以提交态只能靠本次截图/PDF
确认；若本次复现出的是显式那次的结果而不是 `auto-origin/` 的产物，保留 `pass_with_warnings`
并在审计里记录差异，不得改写已有数值证据。

### 4.6 取不到时

按第 8 节写 `not_available`：母相、Method 4、案例 `G05-origin-shift`、上传 daughter 的哈希、
四项控件设置、尝试时间、官网原始响应（错误文本或页面截图）、结论；保留原有
`pass_with_warnings`，不改动已接受的数值证据。

## 5. B 阶段：Method 3（待上界冻结后执行）

**闭包测量当前已暂停（用户指示：本轮只改计划与冻结，不跑程序验证）**：上一次测量运行期间生产
源码被改动（`backend/method4/decomposition.py` 等在测量进行中修改），该次测量判为无效；未签名的
54 条查询结果单独归档为
`output/validation/method3_closure_checkpoint_unsigned_20261016.json`。重跑的前置条件是源码稳定，
且报告必须逐查询记录源码签名与漂移（`measure_method3_closure.py` 已支持 `source_signature` 与
`source_signature_drifted`）。**在冻结 `k_max`/`c_max` 之前不下载任何 Method 3 查询。**

有限定义（可判定、可穷举，唯一自由量是 `k_max` 与 `c_max`）：

- 一个查询 = 唯一的（目标空间群, 超胞基矢 `B`, 心化）组合；官网自动枚举全部取向与原点位移。
- 目标空间群集合 = 点群 ≤ 4/mmm 且 Bravais 类与母相点阵某个子格同轨的类型
  （1–230 穷举的实测上界 114 种；I 心母相只允许 P/I，P4/mmm 只允许 P）。
- `B` 为整数 3×3，`1 ≤ |det| ≤ k_max`、`|元素| ≤ c_max`，按母相点群轨道取代表
  （HNF 规范枚举；指数 1–8 的代表类数 1/6/13/35/31/91/57/155，Σ=389）。
- 四类判据（只由 `B` 决定，互斥且穷尽，与 40 个已冻结 `category` 全部一致）：
  identity ⇔ `det=1` 且 `B=I`；oriented-cell ⇔ `det=1` 且 `B≠I`；
  special-supercell ⇔ `det>1` 且 `adj(B)` 全偶；parameter-k ⇔ `det>1` 且 `adj(B)` 有奇元素。
- 完备机制 = 以官网 Method 1 归档行为种子，按上述算子取最小不动点闭包；单调且有界，
  必然终止，不是抽样。

规模（种子为精确归档值，区间为闭包投影，须实跑闭包后确定）：4310 125…190、
EuAl4 123…185、NdNiO2 82…130 个案例。全网格（`|SGset| × Bgrid`）是万级，**不采用**。
已覆盖：EuAl4 5/3/8/4、NdNiO2 4/4/8/4（identity/oriented-cell/special-supercell/
parameter-k），只有 Default 心化、`det ∈ {1,2,4,6,12}`；缺口是 `det ∈ {3,5,7,8,>12}`
与显式 P/A/B/C/I/F/R 心化。4310 官网 Method 3 目录当前为空。

官网操作（逐案例）：载入母相 CIF → Types = `strain` 加全物种 `displacive` → Method 3 →
选目标空间群 → Sublattice type = `direct` → Centering 选 `Default`（`P` 不是 Default）→
逐格照抄九个整数基矢（保序保号）→ OK → 保存整页结果表，并对每个候选保存四件套。

冻结前置：母相 SHA-256 与官网显示的 setting、Types 与作用域、显式案例表
（case_id / 目标 SG / 3×3 基矢 / 心化 / lattice_type）、`k_max`、`c_max` 与种子清单、
案例号→目录映射、产物名契约、批次根、本地来源与运行时签名。

## 6. B 阶段：Method 4（待上界冻结后执行）

Method 4 的对照案例由 Method 3 的核定路径生成，因此其上界同样等闭包测量恢复后确定；
在此之前只做第 4 节那一个补页动作，不下载任何 Method 4 新案例。

有限定义：`N = |P| · (3 + 同 IR 正交对 + 跨 IR 混合 + 噪声变体) + 拒绝案例 + 原点对照`，
其中 `P` = 通过本地身份门的核定路径。最小覆盖 = 已核定的 12 个角色
（G01–G06、P01–P03、F01–F03）⇒ 每母相至少 12，三母相至少 36；4310 需先建立核定路径。
需你给定上界：`k4_max`（daughter 超胞指数）、`m_max`（每 daughter 模式数）、
`L_daughter`（每路径 daughter 数）、每母相核定路径数、`dmax_max`（Å）、噪声 σ、
robust 阈值、应变因子、原点位移值。

官网操作（逐案例）：上传哈希匹配的 frozen daughter.cif → 设定 matching 方法与原点位移
（daughter 分数坐标）→ 下载上传副本、母相身份、填写完成的控件截图/PDF、结果页、
Complete modes details、subgroup.cif/topas.str/data.isoviz、幅度表（官网另提供时）、
预期失败案例的错误页。Method 4 没有 ZIP，不补造四格式。

冻结前置：核定路径表（含 `k_active`）与模式顺序、daughter 哈希、幅度规则、变换清单、
容差、原点约定（施加的 daughter 分数坐标 vs 填入的 parent 分数坐标）。

## 7. 参数化 k：代表值已冻结

统一代表值（按标签声明的参数顺序代入）：`a=1/6`、`b=1/4`、`g=1/3`。多参数标签代入后各参数
互不相等，按构造排除 `a=b`、`a=g`、`b=g` 这类更高对称子空间；已冻结归档的 EuAl4 `LD g=1/6`
（nmod 0/1 各 22 候选）与 NdNiO2 `Y a=1/3`（各 48 候选）保留原值，只登记不重下。

一般位置验证可复现：`tests/manual/verify_parametric_k_grid.py` 用精确有理数代入仿射模板，
计算该点在母相点群 4/mmm 下的 little group，与同一标签上通用取样点的 little group 比较，
并检查它是否与同一母相其它标签的点重合（精确与模倒格矢两种判定）。报告
`output/validation/official_full_download_parametric_k_grid_check_20261016.json`：
verdict = `pass`、0 issue。唯一提示是 #139 的 `GM` 与 `M` 模倒格矢重合，两者都是官网固定
模板、归档也分别保存，属信息项而非缺陷。

| 母相 | 标签 | 模板 | 代表值 | 坐标 | 动作 |
|---|---|---|---|---|---|
| EuAl4 | LD k10 | (0,0,g) | g=1/6 | (0 , 0 , 1/6) | 已归档，只登记 |
| NdNiO2 | Y k6 | (a,1/2,0) | a=1/3 | (1/3 , 1/2 , 0) | 已归档，只登记 |
| EuAl4 | A k3 | (a,a,g) | a=1/6, g=1/3 | (1/6 , 1/6 , 1/3) | 新查询 ×2（nmod 0/1） |
| EuAl4 | B k1 | (a,0,g) | a=1/6, g=1/3 | (1/6 , 0 , 1/3) | 新查询 ×2（nmod 0/1） |
| EuAl4 | C k2 | (a,b,0) | a=1/6, b=1/4 | (1/6 , 1/4 , 0) | 新查询 ×2（nmod 0/1） |
| EuAl4 | DT k7 | (a,a,0) | a=1/6 | (1/6 , 1/6 , 0) | 新查询 ×2（nmod 0/1） |
| EuAl4 | GP k0 | (a,b,g) | a=1/6, b=1/4, g=1/3 | (1/6 , 1/4 , 1/3) | 新查询 ×2（nmod 0/1） |
| EuAl4 | Q k5 | (1/2,b,1/2) | b=1/4 | (1/2 , 1/4 , 1/2) | 新查询 ×2（nmod 0/1） |
| EuAl4 | SM k6 | (a,0,0) | a=1/6 | (1/6 , 0 , 0) | 新查询 ×2（nmod 0/1） |
| EuAl4 | W k9 | (1/2,1/2,g) | g=1/3 | (1/2 , 1/2 , 1/3) | 新查询 ×2（nmod 0/1） |
| EuAl4 | Y k8 | (a,-a+1,0) | a=1/6 | (1/6 , 5/6 , 0) | 新查询 ×2（nmod 0/1） |
| 4310 | A k3 | (a,a,g) | a=1/6, g=1/3 | (1/6 , 1/6 , 1/3) | 新查询 ×2（nmod 0/1） |
| 4310 | B k1 | (a,0,g) | a=1/6, g=1/3 | (1/6 , 0 , 1/3) | 新查询 ×2（nmod 0/1） |
| 4310 | C k2 | (a,b,0) | a=1/6, b=1/4 | (1/6 , 1/4 , 0) | 新查询 ×2（nmod 0/1） |
| 4310 | DT k7 | (a,a,0) | a=1/6 | (1/6 , 1/6 , 0) | 新查询 ×2（nmod 0/1） |
| 4310 | GP k0 | (a,b,g) | a=1/6, b=1/4, g=1/3 | (1/6 , 1/4 , 1/3) | 新查询 ×2（nmod 0/1） |
| 4310 | LD k10 | (0,0,g) | g=1/3 | (0 , 0 , 1/3) | 新查询 ×2（nmod 0/1） |
| 4310 | Q k5 | (1/2,b,1/2) | b=1/4 | (1/2 , 1/4 , 1/2) | 新查询 ×2（nmod 0/1） |
| 4310 | SM k6 | (a,0,0) | a=1/6 | (1/6 , 0 , 0) | 新查询 ×2（nmod 0/1） |
| 4310 | W k9 | (1/2,1/2,g) | g=1/3 | (1/2 , 1/2 , 1/3) | 新查询 ×2（nmod 0/1） |
| 4310 | Y k8 | (a,-a+1,0) | a=1/6 | (1/6 , 5/6 , 0) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | B k3 | (0,b,g) | b=1/4, g=1/3 | (0 , 1/4 , 1/3) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | C k5 | (a,a,g) | a=1/6, g=1/3 | (1/6 , 1/6 , 1/3) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | D k1 | (a,b,0) | a=1/6, b=1/4 | (1/6 , 1/4 , 0) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | DT k8 | (0,b,0) | b=1/4 | (0 , 1/4 , 0) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | E k2 | (a,b,1/2) | a=1/6, b=1/4 | (1/6 , 1/4 , 1/2) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | F k4 | (a,1/2,g) | a=1/6, g=1/3 | (1/6 , 1/2 , 1/3) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | GP k0 | (a,b,g) | a=1/6, b=1/4, g=1/3 | (1/6 , 1/4 , 1/3) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | LD k13 | (0,0,g) | g=1/3 | (0 , 0 , 1/3) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | S k11 | (a,a,1/2) | a=1/6 | (1/6 , 1/6 , 1/2) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | SM k10 | (a,a,0) | a=1/6 | (1/6 , 1/6 , 0) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | T k7 | (a,1/2,1/2) | a=1/6 | (1/6 , 1/2 , 1/2) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | U k9 | (0,b,1/2) | b=1/4 | (0 , 1/4 , 1/2) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | V k14 | (1/2,1/2,g) | g=1/3 | (1/2 , 1/2 , 1/3) | 新查询 ×2（nmod 0/1） |
| NdNiO2 | W k12 | (0,1/2,g) | g=1/3 | (0 , 1/2 , 1/3) | 新查询 ×2（nmod 0/1） |

计数：参数化标签 35 个（其中 33 个是新查询），
查询 70 个（新查询 66 个）。
连同固定特殊 k 的 32 个查询，Method 2 本轮共需下载 98 个查询。

下载前仍缺一步：逐个查询的本地运行规模预估（候选数与四格式体积），需要跑一次本地 Method 2，
受 pwsh/权限问题阻塞（见重置记录开放项）。

## 8. 未提供项与失败记录

每个 `not_available` 记录：母相、Method、查询/案例身份、参数、尝试时间、官网原始响应
（错误页或文本）、结论与后续动作。禁止用其它案例的输出顶替，禁止改名冒充。

## 9. 下载完成后的只读审计

1. **Method 2**（新根目录）：目前没有可复用的维护版审计工具，需要新增一个只读审计：
   解析 `result_table.html` 得到候选全集，核对每个候选的四件套非空、身份
   `(SG, basis, origin, s, i)`、`!numberOfModulations`，以及结果表候选数与目录数一致。
2. **Method 3**：`tests/manual/audit_method3_downloads.py <root> --json-output <path>`
   可直接指向新根目录；所属 manifest 由根路径或案例名推断，必要时加 `--parent-cif`。
3. **Method 4**：`tests/manual/audit_method4_official.py` 的官网根目前硬编码
   `output_compare`，需要新增 `--official-root`（后续实现项）才能审计新根目录。
4. **Method 1**：只登记；`output/validation/audit_method1_official_downloads_20261003.json`
   的 330/330 结论继续作为旧归档记录，不用于新范围验收。

命令按仓库约定经 `..\run_cris.ps1` 执行。注意当前 `pwsh` 受限（见重置记录开放项），
恢复前这些审计无法运行。

## 10. 之后：本地清单重建与重跑

1. 审计通过后，按新官网集生成新的 `local_web_output_refresh_manifest.json`
   （新 batch id，每个官网页面/候选对应一个本地案例）与新的 runtime revision；
   旧清单保持 `superseded`。
2. `download_local_web_outputs.mjs` 只有在 `status == "frozen"` 且
   `parent_manifest_sha256` 与新 revision 一致时才会运行；这是恢复本地刷新的前置条件。
3. 本地产物写入
   `ISODISTORT/output/validation/web_output_refresh/<新批次>/<母相>/现有网页版/<Method>/`；
   官网材料与本地产物分树存放，审计只读官网树。
4. 用新官网集重跑 Method 1 → 2 → 3 → 4 对照；旧报告的数字与结论不得作为新范围验收。
