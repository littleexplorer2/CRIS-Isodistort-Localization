#!/usr/bin/env python3
"""Measure the graduated Method 3 closure per parent (read-only scope study).

What it does
------------
The official Method 3 download scope is the least fixed point of

    Cl(S) = union over s in S of Method3(SG(s), B(s), centering(s))

seeded by the registered official Method 1 archive rows (read-only input).
Every node of that closure is one website query: one target space group, one
integral supercell basis and the Default centering.  This tool enumerates the
closure for a ladder of ``(k_max, c_max)`` bounds and reports, per level, the
number of new and cumulative queries, the candidates returned, the wall-clock
cost, the failures and the resource delta, plus the four-category coverage
(identity / oriented-cell / special-supercell / parameter-k).

Rules that keep the result decidable
------------------------------------
* Seeds are always included; ``(k_max, c_max)`` bound only newly generated
  children: ``|det B| <= k_max`` and ``max |entry| <= c_max``.
* A child whose basis is not integral cannot be typed into the official nine
  integer basis fields.  It is recorded as ``non_integral_basis`` and is *not*
  silently dropped or rescaled.
* ``generate_if_missing`` follows the existing convention: enabled only for the
  parameter-k category.
* Every query result is checkpointed, so an interrupted long run resumes.

Isolation: the seed rows are read from the read-only archive report; nothing
here may be fed into the local computation chain, and no official candidate
answer is used as a query or as an expected value.
"""
from __future__ import annotations

import argparse
import contextlib
import io
import json
import statistics
import sys
import time
from fractions import Fraction
from pathlib import Path
from typing import Any

WORKSPACE = Path(__file__).resolve().parents[3]
PACKAGE_ROOT = WORKSPACE / "ISODISTORT"
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

SEED_REPORT = PACKAGE_ROOT / "output" / "validation" / "audit_method1_official_downloads_20261003.json"
DEFAULT_REPORT = PACKAGE_ROOT / "output" / "validation" / "method3_closure_measurement.json"
DEFAULT_CHECKPOINT = PACKAGE_ROOT / "output" / "validation" / "method3_closure_checkpoint.json"
DEFAULT_LADDER = "2,6;4,6;6,6"
DISTORTION_TYPES = ["strain", "displacive"]
CENTERING = "d"
SIGNATURE_ROOTS = ("ISODISTORT/backend", "ISODISTORT/application", "ISODISTORT/frontend")
SIGNATURE_FILES = (
    "ISODISTORT/main_web.py",
    "ISODISTORT/pyproject.toml",
    "ISODISTORT/requirements.txt",
    "ISODISTORT/resources/config/settings.yaml",
    "ISODISTORT/tests/manual/measure_method3_closure.py",
)


def source_signature() -> dict[str, Any]:
    """Hash the production tree so a mid-run source edit cannot go unnoticed."""
    import hashlib

    digest = hashlib.sha256()
    entries = 0
    paths: list[Path] = []
    for root in SIGNATURE_ROOTS:
        directory = WORKSPACE / root
        if directory.is_dir():
            paths.extend(sorted(directory.rglob("*.py")))
    paths.extend(WORKSPACE / name for name in SIGNATURE_FILES)
    for path in sorted(set(paths)):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        digest.update(path.relative_to(WORKSPACE).as_posix().encode())
        digest.update(path.read_bytes())
        entries += 1
    return {"sha256": digest.hexdigest(), "file_count": entries}


def _fraction(value: Any) -> Fraction:
    if isinstance(value, str):
        return Fraction(value)
    return Fraction(value).limit_denominator(64)


def _basis_key(basis: tuple[tuple[Fraction, ...], ...]) -> str:
    return ";".join(",".join(str(component) for component in row) for row in basis)


def _integral_basis(basis: tuple[tuple[Fraction, ...], ...]) -> list[list[int]] | None:
    if all(component.denominator == 1 for row in basis for component in row):
        return [[int(component) for component in row] for row in basis]
    return None


def _det(basis: list[list[int]]) -> int:
    (a, b, c), (d, e, f), (g, h, i) = basis
    return a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)


def _adjugate(basis: list[list[int]]) -> list[list[int]]:
    (a, b, c), (d, e, f), (g, h, i) = basis
    return [
        [e * i - f * h, c * h - b * i, b * f - c * e],
        [f * g - d * i, a * i - c * g, c * d - a * f],
        [d * h - e * g, b * g - a * h, a * e - b * d],
    ]


def category(basis: list[list[int]]) -> str:
    """Classify a query supercell basis.

    ``special-supercell`` is the exact condition ``2 (B^T)^{-1}`` integral, i.e.
    the determinant divides twice every entry of ``adj(B)^T``; the simplified
    "adj(B) entries even" shortcut is wrong for even determinants and disagrees
    with the frozen Method 3 labels, so it is not used.
    """
    determinant = _det(basis)
    identity = basis == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    if determinant == 1:
        return "identity" if identity else "oriented-cell"
    adjugate = _adjugate(basis)
    twice_inverse_transpose_integral = all(
        (2 * adjugate[j][i]) % determinant == 0 for i in range(3) for j in range(3)
    )
    return "special-supercell" if twice_inverse_transpose_integral else "parameter-k"


def _seed_queries(parent: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    payload = json.loads(SEED_REPORT.read_text(encoding="utf-8"))
    queries: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    for entry in payload["parents"]:
        if entry["parent"] != parent:
            continue
        for candidate in entry["candidates"]:
            expected = candidate["expected"]
            basis = tuple(
                tuple(_fraction(component) for component in row) for row in expected["basis"]
            )
            record = {
                "ir": expected.get("ir"),
                "opd": expected.get("opd"),
                "space_group": int(expected["space_group"]),
                "basis": basis,
            }
            integral = _integral_basis(basis)
            if integral is None:
                skipped.append({**{k: v for k, v in record.items() if k != "basis"},
                                "basis": _basis_key(basis), "reason": "non_integral_basis"})
                continue
            queries.append(
                {
                    "space_group": record["space_group"],
                    "basis": basis,
                    "integral_basis": integral,
                    "category": category(integral),
                    "origin": [str(value) for value in expected.get("origin", [])],
                    "source": f"seed:{record['ir']}_{record['opd']}",
                }
            )
    return queries, skipped


def _cache_bytes() -> int:
    total = 0
    for root in (PACKAGE_ROOT / "output" / "tmp", PACKAGE_ROOT / "output" / "validation"):
        if not root.is_dir():
            continue
        for path in root.rglob("*"):
            if path.is_file():
                try:
                    total += path.stat().st_size
                except OSError:
                    continue
    return total


def _run_query(iso: Any, query: dict[str, Any], signature: str) -> dict[str, Any]:
    started = time.perf_counter()
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            items = iso.search_method_3(
                distortion_types=DISTORTION_TYPES,
                space_group_type=query["space_group"],
                supercell_basis=query["integral_basis"],
                direct_sublattice_centering=CENTERING,
                lattice_type="direct",
                generate_if_missing=query["category"] == "parameter-k",
            )
        children = []
        for item in items:
            subgroup = item.subgroup
            basis = tuple(
                tuple(_fraction(component) for component in row)
                for row in (subgroup.basis_vectors or [])
            )
            children.append(
                {
                    "space_group": int(subgroup.space_group_number),
                    # Fractions are stored as strings so the checkpoint stays JSON.
                    "basis": [[str(component) for component in row] for row in basis],
                    "irrep": str(getattr(subgroup, "irrep_label", "")),
                    "opd": str(getattr(subgroup, "opd_symbol", "")),
                    "origin": [str(value) for value in (subgroup.origin or [])],
                }
            )
        return {
            "status": "pass",
            "seconds": round(time.perf_counter() - started, 3),
            "candidate_count": len(children),
            "children": children,
            "source_signature": signature,
        }
    except Exception as exc:  # noqa: BLE001 - failures are recorded verbatim
        return {
            "status": "fail",
            "seconds": round(time.perf_counter() - started, 3),
            "error": f"{type(exc).__name__}: {exc}",
            "source_signature": signature,
        }


def _within_bounds(integral_basis: list[list[int]], k_max: int, c_max: int) -> bool:
    if abs(_det(integral_basis)) > k_max:
        return False
    return all(abs(entry) <= c_max for row in integral_basis for entry in row)


def run_level(
    iso_by_parent: dict[str, Any],
    parent: str,
    seeds: list[dict[str, Any]],
    k_max: int,
    c_max: int,
    seen: set[str],
    checkpoint: dict[str, Any],
    max_queries: int,
    max_seconds: float,
    checkpoint_path: Path,
) -> dict[str, Any]:
    # Cheap categories first so a long parameter-k generation cannot hide the
    # measurement of the bulk of the closure.
    queue: list[dict[str, Any]] = sorted(
        seeds, key=lambda item: item["category"] == "parameter-k"
    )
    level_new: list[str] = []
    candidates_total = 0
    failures: list[dict[str, Any]] = []
    non_integral: list[dict[str, Any]] = []
    seconds: list[float] = []
    coverage = {"identity": 0, "oriented-cell": 0, "special-supercell": 0, "parameter-k": 0}
    signatures: set[str] = set()
    cache_before = _cache_bytes()
    started = time.perf_counter()
    time_budget_exhausted = False

    while queue and len(level_new) < max_queries:
        if time.perf_counter() - started > max_seconds:
            time_budget_exhausted = True
            break
        query = queue.pop(0)
        key = f"{query['space_group']}|{_basis_key(query['basis'])}|{CENTERING}"
        if key in seen:
            continue
        seen.add(key)
        level_new.append(key)
        coverage[query["category"]] = coverage.get(query["category"], 0) + 1

        record = checkpoint["queries"].get(key)
        if record is None:
            current_signature = source_signature()["sha256"]
            signatures.add(current_signature)
            record = _run_query(iso_by_parent[parent], query, current_signature)
            checkpoint["queries"][key] = record
            checkpoint["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            checkpoint_path.write_text(
                json.dumps(checkpoint, ensure_ascii=False, indent=2, default=str) + "\n",
                encoding="utf-8",
            )
        else:
            signatures.add(str(record.get("source_signature", "unsigned")))
        seconds.append(float(record.get("seconds", 0.0)))
        print(
            f"  query {len(level_new)} new={len(level_new)} {key} {record['status']} "
            f"{record.get('seconds')}s candidates={record.get('candidate_count')}",
            flush=True,
        )
        if record["status"] != "pass":
            failures.append({"key": key, "error": record.get("error")})
            continue
        candidates_total += int(record["candidate_count"])
        for child in record["children"]:
            child_basis = tuple(
                tuple(_fraction(component) for component in row) for row in child["basis"]
            )
            if len(child_basis) != 3:
                non_integral.append({"from": key, "reason": "missing_basis"})
                continue
            integral = _integral_basis(child_basis)
            if integral is None:
                non_integral.append(
                    {
                        "from": key,
                        "space_group": child["space_group"],
                        "basis": _basis_key(child_basis),
                        "reason": "non_integral_basis",
                    }
                )
                continue
            if not _within_bounds(integral, k_max, c_max):
                continue
            child_key = f"{child['space_group']}|{_basis_key(child_basis)}|{CENTERING}"
            if child_key in seen:
                continue
            queue.append(
                {
                    "space_group": child["space_group"],
                    "basis": child_basis,
                    "integral_basis": integral,
                    "category": category(integral),
                    "origin": child["origin"],
                    "source": f"closure:{key}",
                }
            )

    elapsed = round(time.perf_counter() - started, 3)
    return {
        "k_max": k_max,
        "c_max": c_max,
        "new_query_count": len(level_new),
        "cumulative_query_count": len(seen),
        "candidates_returned": candidates_total,
        "category_coverage": coverage,
        "elapsed_seconds": elapsed,
        "query_seconds": {
            "count": len(seconds),
            "min": round(min(seconds), 3) if seconds else None,
            "median": round(statistics.median(seconds), 3) if seconds else None,
            "max": round(max(seconds), 3) if seconds else None,
            "total": round(sum(seconds), 3),
        },
        "failures": failures,
        "non_integral_children": non_integral,
        "resource_delta_bytes": _cache_bytes() - cache_before,
        "stopped_early": bool(queue) or len(level_new) >= max_queries,
        "time_budget_exhausted": time_budget_exhausted,
        "source_signatures": sorted(signatures),
        "source_signature_drifted": len(signatures) > 1,
        "new_query_keys": level_new,
    }


def _write_report(report: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parent", action="append", dest="parents", default=None)
    parser.add_argument("--ladder", default=DEFAULT_LADDER, help="k_max,c_max pairs separated by ';'")
    parser.add_argument("--max-queries-per-level", type=int, default=200)
    parser.add_argument(
        "--max-seconds-per-level",
        type=float,
        default=5400.0,
        help="wall-clock budget per level so a long parameter-k generation cannot run away",
    )
    parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CHECKPOINT)
    parser.add_argument("--report", type=Path, default=DEFAULT_REPORT)
    parser.add_argument("--dry-run", action="store_true", help="seed and level plan only, no local run")
    args = parser.parse_args()

    parents = args.parents or ["EuAl4 Parent.cif", "NdNiO2 own.cif", "4310_tetra.cif"]
    ladder = []
    for item in args.ladder.split(";"):
        k_text, c_text = item.split(",")
        ladder.append((int(k_text), int(c_text)))

    checkpoint = {"queries": {}}
    if args.checkpoint.exists():
        saved = json.loads(args.checkpoint.read_text(encoding="utf-8"))
        if isinstance(saved.get("queries"), dict):
            checkpoint = saved

    report: dict[str, Any] = {
        "schema": "method3-closure-measurement/v1",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "tool": "ISODISTORT/tests/manual/measure_method3_closure.py",
        "seed_report": str(SEED_REPORT.relative_to(WORKSPACE)).replace("\\", "/"),
        "ladder": [{"k_max": k, "c_max": c} for k, c in ladder],
        "max_queries_per_level": args.max_queries_per_level,
        "isolation_note": (
            "Seed rows come from the read-only official Method 1 archive report; they define the "
            "download scope only and never enter the local computation chain."
        ),
        "parents": {},
        "blocker_note": (
            "Seeds with a non-integral basis cannot be typed into the official nine integer basis "
            "fields; they are listed, not rescaled."
        ),
    }

    iso_by_parent: dict[str, Any] = {}
    report["status"] = "running"
    report["source_signature_start"] = source_signature()
    exit_code = 0
    try:
        for parent in parents:
            seeds, skipped_seeds = _seed_queries(parent)
            entry: dict[str, Any] = {
                "seed_query_count": len(seeds),
                "seed_query_count_by_category": {
                    name: sum(1 for seed in seeds if seed["category"] == name)
                    for name in ("identity", "oriented-cell", "special-supercell", "parameter-k")
                },
                "seeds_not_typeable": skipped_seeds,
                "levels": [],
            }
            report["parents"][parent] = entry
            _write_report(report, args.report)
            if args.dry_run:
                continue
            if parent not in iso_by_parent:
                from application.session import IsoDistort  # noqa: PLC0415 - only when running

                iso = IsoDistort()
                with contextlib.redirect_stdout(io.StringIO()):
                    iso.load_structure(WORKSPACE / "experiment_data" / parent)
                iso_by_parent[parent] = iso
            seen: set[str] = set()
            for k_max, c_max in ladder:
                level = run_level(
                    iso_by_parent, parent, seeds, k_max, c_max, seen, checkpoint,
                    args.max_queries_per_level, args.max_seconds_per_level, args.checkpoint,
                )
                entry["levels"].append(level)
                _write_report(report, args.report)
                print(
                    f"{parent} level ({k_max},{c_max}): new={level['new_query_count']} "
                    f"cumulative={level['cumulative_query_count']} candidates={level['candidates_returned']} "
                    f"elapsed={level['elapsed_seconds']}s failures={len(level['failures'])}",
                    flush=True,
                )
                if level["stopped_early"]:
                    break
        report["status"] = "complete"
    except Exception as exc:  # noqa: BLE001 - a long run must still leave a report
        report["status"] = "failed"
        report["error"] = f"{type(exc).__name__}: {exc}"
        exit_code = 1
        print(f"FAILED: {report['error']}", flush=True)

    _write_report(report, args.report)
    report["source_signature_end"] = source_signature()
    report["source_signature_stable"] = (
        report["source_signature_start"]["sha256"] == report["source_signature_end"]["sha256"]
    )
    _write_report(report, args.report)
    for parent, entry in report["parents"].items():
        print(
            f"{parent}: seeds={entry['seed_query_count']} "
            f"by_category={entry['seed_query_count_by_category']} "
            f"not_typeable={len(entry['seeds_not_typeable'])}"
        )
    print(
        f"report: {args.report} "
        f"(source signature stable: {report['source_signature_stable']})"
    )
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
