# 当前验证证据与缺口

## 2026-10-19 架构调整

本轮按计算状态安全、职责与调用方向、公开合同、验证可信度的优先级实施。
改动保留已有官网下载任务、原件及独立实验输入；没有以官网输出构造本地计算输入。
调整前的下载重建报告等六份原文已逐条校验归档，见
[历史索引](history/README.md) 和 [归档](history/architecture-before-20261019.zip)。

### 已完成调整

1. **动作事务和资源所有权。** `frontend/web` 经 `application/workflows` 执行有状态计算/选择时操作独立会话快照，
   输入校验、计算、响应构造及 UTF-8 JSON 编码全部成功才单次发布状态并增加 revision。
   异常保留原会话。ISO/SMODES/FINDSYM 各实例拥有私有运行目录；快照复制生成数据库及
   临时结果，避免对象已隔离而底层文件仍共享。构造失败、关闭和克隆失败均回收资源。
   真实回归的线程栈定位到 Windows 超时后无界等管道 EOF；改用文件捕获、有界 wait，
   并使超时实例失效，避免未知 Linux 后代继续写入的缓存被复用。
   新母相上传从新计算实例开始，已失效引擎也可恢复；成功才替换，失败保留旧输入和状态。
   另以 20 秒自然空闲反例定位到 WSL 的 `/tmp` 随发行版退出清空；对象仍存活且清理器未执行。
   WSL 暂存迁到持久文件系统的 `/var/tmp`，保留独占所有权和关闭回收，避免会话中途丢目录。
2. **导出任务唯一状态。** `workflows/jobs.py` 管理 job_id、来源 revision、进度、取消与终态；
   删除旧进度/取消/锁的平行全局实现。过期任务不能取消或覆盖新任务；HTTP/UI 传递同一身份。
   下载响应携带本任务终态，避免下一任务启动后把部分 ZIP 显示成全部完成。
   关闭服务先结束在途请求，再释放会话。坏 JSON、空/重复参数及不支持请求得到明确错误。
3. **求解职责归位并删除旧代码。** 删除 `method1/search_methods.py`，将原 Method 1/2/3
   计算体分别放入所属模块的 `search.py`；会话仅协调各 solver。Method 4 继续由
   `method4/decomposition.py` 负责。共有仿射格算法迁入 `utils/affine_embeddings.py`，
   相路径合同迁入 `models/phase_path.py`，删除旧位置文件；k 格助手、Hall/晶系查询统一来源。
   没有给旧单体增加兼容覆盖层。33 个原计算体的 AST 迁移比对保存在本轮证据目录。
4. **会话、导出和身份合同。** 导出批次发布移入 `session/publication.py`，精确子胞 Seitz
   变换移入 `export/child_frame.py`。ModeIdentityFailure/Status 与 Method 3 route/embedding
   进入正式数据模型，去掉动态私有字段和重复身份。nmod 共用整数/范围验证，不再截断或隐式转换。
   `select_path()` 收敛到 `search_method_2()`，删除另一套模式计算分支；保留当前 nmod/物种作用域，
   统一重复候选与诊断路线拒绝，修复显式类型选择后快照上下文过期的缺陷。
5. **GD 使用公开结果快照。** `DisplacementSnapshot` 固定候选、计算上下文、模式顺序/符号、
   晶格和未移原点超胞；GD 不再读取会话私有字段。输出身份只来自计算结果；含糊候选、
   不完整列、失效上下文及无效模式被拒绝。修复非对称 B 的倒易变换 `h_c=h_p Bᵀ`，
   格指数按精确行列式判断，不再四舍五入；未支持非整数指数显式拒绝。
   float32 转换后再次校验所有输出及倒易阵，超域结果在返回/写文件前拒绝。
6. **共享归一化根因修复。** 删除极小非零列绕过归一化的阈值分支和伪单位因子。
   同一算法验证有限非零模式、有效晶格及正整数计数；可表示域内保留模式方向和符号。
   补充必要分量下溢的明确拒绝，避免“整列非零”掩盖丢失方向后错误归一化；
   病态晶格的误差保证未扩大，正常极端尺度的既有容差未放宽。
   GD 明确使用所表示母胞的均方约定，不把它自动称作 ISO 原胞 As/Ap。
7. **比较与证据统一。** CIF 结构、字节及哈希来自一次不可变读取；严格模式要求
   语义、可信参考哈希和字节均匹配；缺哈希且无其他差异为 inconclusive，已知差异仍为 fail。
   手工工具共享快照、哈希、运行环境及原子 JSON 写入服务，各审计定义签名材料，尚非全部报告均原子写入。
   Method 4 及 Stage A/B 的解析和来源签名绑定同一文件快照，防止旧解析配新指纹；
   Method 4 起止来源漂移及 Stage A/B 恢复签名不匹配时拒绝旧结果。
   Method 3/4 准备器签名改为读取共享生产源码注册表及运行配置，删除易漏项的小列表；
   改变仿射求解实现后，旧通过 checkpoint 与旧输入批次必须失效，不能继续跳过计算。
   独立数学比较器保留独立实现，避免测试直接复用被验证算法。架构门禁阻止比较层
   启动生产计算及 GD 绕过公开会话合同，打包检查验证实际可安装入口。

### 科学影响、依据与适用条件

完整定义、逐步推导、反例、单位和容差见
[架构数学合同](reference_library/notes/ARCHITECTURE_CONTRACTS_20261019.md)。
`coverage.json` 和 `audit/implementation_audit.json` 的模块路径已同步，既有未证明/未支持状态保留。
实际审读范围限于该证明文档列出的项目推导段落；没有宣称通读全部外部文献。

- Seitz 共轭采用可逆有理 B、q 与 Fraction 算术；保持群乘法、恒等元、逆和闭包，
  非对角 B/非零 q 及完整 Hall 操作集测试检查坐标合同。精确路径无浮点容差。
- 行基 A_c=B A_p 对应倒易行指数 h_c=h_p Bᵀ，由相位配对直接推导；
  非对称剪切矩阵反例能区分旧错误算法。精确整数格指数不使用容差。
- 模式采用分数位移 U、以 Å 表示的晶格 A、基准长度 ℓ₀=1 Å，
  V=U ℓ₀ sqrt(N/Σ||UA||²)。检查均方、正负尺度、斜晶格、线性叠加及上界×dmax=1 Å。
  GD float32 回代使用 rtol=2e−7、atol=2e−8；双精度坐标复制 atol=1e−14、rtol=0。
- nmod 0..3 是实现支持范围，不是数学空间维数上限；非法类型/负值和更高维分别拒绝。
- 会话回滚、文件隔离、任务所有权与 SHA-256 同源性是工程不变量；守恒定律或能量最小化
  不适用于这些状态管理改动。它们也不能证明数值算法或参考来源真实。

### 验证命令与结果

在最终源码冻结后执行，两个进程均退出 0：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_cris.ps1 -m pytest ISODISTORT/tests E:/GD/tests_dev -q -ra -x --tb=short -o faulthandler_timeout=120 --basetemp=ISODISTORT/output/validation/architecture_20261019/full-final-temp
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_cris.ps1 -m pytest tests_repo -q -ra --tb=short --basetemp=ISODISTORT/output/validation/architecture_20261019/repo-final-complete-temp
```

- ISODISTORT + GD 全量：**1395 passed、4 skipped、2027 warnings，1186.18 秒**。
  日志 `full-final.log`。跳过项分别为缺少 X4− P3 官网/本地 CIF 配对、Method 3 旧输入冻结撤销、
  原生 POSIX 用例、LD1 g=1/6 的本地 ISO 子群数据库未生成。
  最后一项是本地计算数据库前置条件，不是漏读已下载的官网输出；本轮没有自动启动长时 GenDB。
  警告为依赖弃用及 CIF/元素解析提示，未发现未捕获线程异常或 finalizer 异常警告。
- 仓库架构、启动部署器和实际 wheel 安装门禁：**54 passed，12.11 秒**。
  日志 `repo-final-complete.log`；包含安装后规范入口与已删除旧入口的核查。
- 改动的 104 个 Python 文件运行 `ruff check --select F,E9`，通过。
  CRIS 与 GD 的 `git -c core.safecrlf=false diff --check` 通过；未提交或推送。
- 文档核查覆盖 11 个当前文档、2 个能力/证明映射，检查本地链接、模块路径和证明标签。
- 文件保护核查：4953 个登记官网文件、100 个保留的历史副本/上传输入、3 份独立母相输入、
  25 个通用套件文件指纹一致；调整前六份文档归档 CRC 和逐文件哈希核验通过。

源码快照 `run-environment.json` 登记 195 个源码/配置/测试文件及依赖版本；
`actual-runner-runtime.json` 记录实际 run_cris 使用的 Python 3.12.5 基础解释器、`-S` 与
`E:/CRIS/.venv/Lib/site-packages` 依赖来源，区别于采集清单使用的 venv 启动器。
`source-stability.json` 记录全量前后的源码、通用资源和依赖一致性。
这些指纹是运行材料清单，不声称进行了每一次操作系统文件读取的全链追踪。

定向最小反例、修前失败和修后结果亦保留：归一化下溢、Windows 后代持有输出句柄、
WSL 自然空闲目录丢失、select_path 双入口不一致、准备器漏签名与文件快照漂移。
它们与全量测试有重叠，不累加通过数量。
本轮结束后仅清理明确列出的 57 个临时目录（9186 文件，约 1.48 GB），
保留根层日志、来源清单、反例探针与核查报告；范围及结果见 `cleanup-plan.json`、`cleanup-result.json`。

原始日志、AST 迁移记录与本轮文件核查位于
`ISODISTORT/output/validation/architecture_20261019/`。
第一次全量回归因审查发现归一化反例而主动中止。
第二次记录两项失败（4310 实际模式导出、nmod 错误文案），在末尾 WSL 超时处理发生
无界输出管道等待；取得线程栈后精确停止该 pytest 进程。两次都不是全绿，原始日志保留。
4310 案例单独复查曾通过，但第三次联合回归仍在该项失败（748 passed、3 skipped 后停止），
取得了暂存目录不存在的明确异常；随后用自然空闲反例定位到 tmpfs 生命周期。
单项通过不能替代整套验证；最终整套复查结果见上。

### 当前官网下载与科学验收状态

下载/检验任务仍为批次 `20261019-official-rebuild-v1`：Method 2 共 102 查询，
99 个页面集未齐、2 个部分齐、1 个齐，已知缺 5 张结果列表，已有 94 个四件套复用。
精确路径和动作以 [下载清单](DOWNLOAD_CHECKLIST.md) 为准；本轮没有执行新官网下载。
下载整理的历史测试及文件保护数字保留在上述归档，不能替代当前代码回归。

独立输入和有限界限未核定的 Method 3/4 任务仍 blocked；新逐候选科学验收仍 not_run。
真实用户浏览器全操作链、GD 的 TensorFlow 计算接收、长时 GenDB 中途取消未作本轮人工验收。
真实 WSL 与自动化 HTTP 测试的结果仅按上述检查各自范围解释。
WSL 混合编码诊断文本仍可能乱码，已在开发计划登记；这项文本解码不属于本轮已完成修复。
不宣称已证明全部 230 空间群、无限 k 范围、外部二进制或所有未支持物理表示。

支撑文档/工具发生架构变化后，冻结记录登记为后继修订 `freeze_revision=2`，
保留原冻结文件的可恢复归档及逐项支撑修订；
下载任务、参考原件及输入指纹不因支撑修订变化，旧运行签名不复用。
后续工作只维护在 [开发计划](DEVELOPMENT_PLAN.md)。
