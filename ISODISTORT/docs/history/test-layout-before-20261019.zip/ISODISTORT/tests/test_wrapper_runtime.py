"""A binary wrapper owns its working directory and mutable database lifetime."""

from __future__ import annotations

import gc
import os
import shlex
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path, PurePosixPath
from types import SimpleNamespace

import pytest

from backend.utils import WrapperRunError, WrapperTimeoutError
from backend.wrappers import base_wrapper as module
from backend.wrappers.base_wrapper import BaseWrapper
from backend.wrappers.isotropy_cache import list_isotropy_cache


@pytest.mark.skipif(os.name != "nt", reason="regresses Windows inherited pipe handles")
@pytest.mark.parametrize("parent_waits", [True, False])
def test_wsl_capture_does_not_wait_for_descendant_output_handles(tmp_path, monkeypatch, parent_waits):
    """A finite-lived grandchild makes the old run(PIPE) hang measurable, not infinite."""
    ready = tmp_path / "grandchild-ready"
    finished = tmp_path / "grandchild-finished"
    grandchild = (
        "from pathlib import Path; import time; "
        f"Path({str(ready)!r}).write_text('ready'); "
        "time.sleep(5); "
        f"Path({str(finished)!r}).write_text('finished')"
    )
    parent = (
        "import subprocess, sys, time\nfrom pathlib import Path\n"
        f"subprocess.Popen([sys.executable, '-c', {grandchild!r}], "
        "stdout=sys.stdout, stderr=sys.stderr)\n"
        "deadline = time.monotonic() + 3\n"
        f"while not Path({str(ready)!r}).exists():\n"
        "    assert time.monotonic() < deadline, 'grandchild did not start'\n"
        "    time.sleep(0.01)\n"
        "print('captured stdout', flush=True)\n"
        "print('captured stderr', file=sys.stderr, flush=True)\n"
        + ("time.sleep(30)" if parent_waits else "")
    )
    real_popen = subprocess.Popen

    def launch_owned_python(args, **kwargs):
        assert args[:4] == ["wsl.exe", "-e", "sh", "-c"]
        return real_popen([sys.executable, "-c", parent], **kwargs)

    monkeypatch.setattr(module.subprocess, "Popen", launch_owned_python)
    wrapper = object.__new__(BaseWrapper)
    wrapper._init_runtime_state()
    wrapper._mode = "wsl"
    wrapper.cfg = SimpleNamespace(timeout=1)
    started = time.monotonic()
    try:
        if parent_waits:
            with pytest.raises(WrapperTimeoutError):
                wrapper._wsl("owned fixture", timeout=1)
        else:
            result = wrapper._wsl("owned fixture", timeout=1)
            assert result.returncode == 0
            assert result.stdout == "captured stdout"
            assert result.stderr == "captured stderr"
        elapsed = time.monotonic() - started
        assert ready.is_file(), "Fixture never established inherited output handles"
        assert elapsed < 3, "Capture waited for a descendant after the parent ended"
        assert not finished.exists(), "Descendant exited before the bound was checked"
    finally:
        # Only this test's finite-lived descendant is awaited, outside the
        # measured wrapper call; no process lookup or unrelated WSL kill occurs.
        deadline = started + 10
        while ready.exists() and not finished.exists() and time.monotonic() < deadline:
            time.sleep(0.05)
        assert not ready.exists() or finished.exists(), "Fixture descendant failed to exit"


@pytest.mark.parametrize("cleanup_failure", ["kill", "wait"])
def test_wsl_timeout_cleanup_is_bounded_and_preserves_primary_error(monkeypatch, cleanup_failure):
    calls = []
    streams = []
    primary = subprocess.TimeoutExpired("owned fixture", 0.01)
    cleanup = OSError("kill denied") if cleanup_failure == "kill" else subprocess.TimeoutExpired("reap", 1)

    class Process:
        def __init__(self, args, **kwargs):
            self.args = args
            streams.extend((kwargs["stdout"], kwargs["stderr"]))
            assert all(stream != subprocess.PIPE for stream in streams)

        def wait(self, timeout):
            calls.append(("wait", timeout))
            if len(calls) == 1:
                raise primary
            raise cleanup

        def kill(self):
            calls.append(("kill",))
            if cleanup_failure == "kill":
                raise cleanup

        def communicate(self, *args, **kwargs):
            pytest.fail("Pipe communication can wait forever for inherited handles")

    monkeypatch.setattr(module.subprocess, "Popen", Process)
    wrapper = object.__new__(BaseWrapper)
    wrapper._init_runtime_state()
    wrapper._mode = "wsl"
    wrapper.cfg = SimpleNamespace(timeout=0.01)
    with pytest.raises(WrapperTimeoutError) as captured:
        wrapper._wsl("owned fixture")
    assert captured.value.__cause__ is primary
    assert primary.__cause__ is cleanup
    assert calls[:2] == [("wait", 0.01), ("kill",)]
    if cleanup_failure == "wait":
        assert calls[2] == ("wait", 1.0)
    assert all(stream.closed for stream in streams)


def test_wsl_timeout_retires_runtime_before_execution_or_cache_reuse(monkeypatch):
    wrapper = object.__new__(BaseWrapper)
    wrapper._init_runtime_state()
    wrapper._mode = "wsl"
    wrapper.cfg = SimpleNamespace(timeout=0.01)
    cleaned = []
    wrapper._wsl_cleanup = lambda: cleaned.append("private workspace")

    def timeout(*args, **kwargs):
        raise subprocess.TimeoutExpired("owned fixture", 0.01)

    monkeypatch.setattr(module, "_run_captured_command", timeout)
    with pytest.raises(WrapperTimeoutError):
        wrapper._wsl("cache mutation")
    assert wrapper._closed
    assert cleaned == ["private workspace"]
    with pytest.raises(RuntimeError, match="closed"):
        wrapper._wsl("any later command")
    with pytest.raises(RuntimeError, match="closed"):
        wrapper.run_stdin(Path("iso"), "QUIT")
    with pytest.raises(RuntimeError, match="closed"):
        list_isotropy_cache(wrapper)
    with pytest.raises(RuntimeError, match="closed"):
        wrapper._ensure_writable_isodata()


@pytest.fixture
def isolated_transport(tmp_path, monkeypatch):
    """Simulate only external allocation/linking; exercise real local copies."""
    source = tmp_path / "source"
    source.mkdir()
    (source / "database").write_text("reference", encoding="utf-8")
    temporary = tmp_path / "runtime"
    temporary.mkdir()
    cfg = SimpleNamespace(
        timeout=5,
        temp_dir=temporary,
        _cfg={"isobyu": {"data_dir": str(source)}},
        resolve_path=Path,
    )
    paths = []
    links = {}
    removed = []

    def transport(_self, command, timeout=None):
        if command.startswith("umask 077; mktemp"):
            path = f"/var/tmp/id-{len(paths):08d}"
            paths.append(path)
            return subprocess.CompletedProcess(command, 0, path + "\n", "")
        tokens = shlex.split(command)
        if tokens[:2] == ["ln", "-sfn"]:
            links[tokens[3]] = Path(tokens[2])
            return subprocess.CompletedProcess(command, 0, "", "")
        raise AssertionError(f"Unexpected shell command: {command}")

    def cleanup(path, _timeout):
        removed.append(path)
        links.pop(path + "/data", None)

    monkeypatch.setattr(module, "get_config", lambda: cfg)
    monkeypatch.setattr(BaseWrapper, "_detect_mode", staticmethod(lambda: "wsl"))
    monkeypatch.setattr(BaseWrapper, "_wsl", transport)
    monkeypatch.setattr(BaseWrapper, "_win_to_wsl", lambda _self, path: str(path))
    monkeypatch.setattr(module, "_remove_wsl_workspace", cleanup)
    return SimpleNamespace(source=source, paths=paths, links=links, removed=removed)


def test_interleaved_wrappers_cannot_retarget_generated_database(isolated_transport):
    transport = isolated_transport
    with BaseWrapper() as first:
        first._ensure_writable_isodata()
        private = transport.links[first._isodata_path().rstrip("/")]
        (private / "database").write_text("generated A", encoding="utf-8")
        with BaseWrapper() as second:
            assert first._stage_dir != second._stage_dir
            assert first._isodata_path() != second._isodata_path()
            first._ensure_writable_isodata()
            assert transport.links[first._isodata_path().rstrip("/")] == private
            assert transport.links[second._isodata_path().rstrip("/")] == transport.source
            second._ensure_writable_isodata()
            private_b = transport.links[second._isodata_path().rstrip("/")]
            assert private_b != private
            assert (private_b / "database").read_text(encoding="utf-8") == "reference"
        assert private.exists()
        assert first._stage_dir not in transport.removed
    assert not private.exists()
    assert not private_b.exists()
    assert (transport.source / "database").read_text(encoding="utf-8") == "reference"
    assert len(transport.removed) == 2


def test_close_is_idempotent_and_never_reopens_cache(isolated_transport):
    wrapper = BaseWrapper()
    stage = wrapper._stage_dir
    wrapper.close()
    wrapper.close()
    assert isolated_transport.removed == [stage]
    with pytest.raises(RuntimeError, match="closed"):
        wrapper.run_stdin(Path("iso"), "QUIT")
    with pytest.raises(RuntimeError, match="closed"):
        wrapper._ensure_writable_isodata()
    with pytest.raises(RuntimeError, match="closed"):
        list_isotropy_cache(wrapper)


def test_abandoned_wrapper_releases_only_its_own_workspace(isolated_transport):
    first = BaseWrapper()
    second = BaseWrapper()
    stage = first._stage_dir
    del first
    gc.collect()
    assert isolated_transport.removed == [stage]
    assert second._stage_dir not in isolated_transport.removed
    second.close()


def test_failed_database_binding_cleans_partial_workspace(isolated_transport, monkeypatch):
    def fail_binding(_self, data_dir_win=None):
        raise WrapperRunError("wsl", 1, "link denied")

    monkeypatch.setattr(BaseWrapper, "_wsl_link_isodata", fail_binding)
    with pytest.raises(WrapperRunError, match="link denied"):
        BaseWrapper()
    assert isolated_transport.removed == isolated_transport.paths


def test_initialization_preserves_primary_error_when_cleanup_fails(isolated_transport, monkeypatch):
    primary_error = WrapperRunError("wsl", 1, "link denied")
    cleanup_error = OSError("workspace cleanup denied")
    original_cleanup = module._remove_wsl_workspace

    def fail_binding(_self, data_dir_win=None):
        raise primary_error

    def fail_cleanup(path, timeout):
        original_cleanup(path, timeout)
        raise cleanup_error

    monkeypatch.setattr(BaseWrapper, "_wsl_link_isodata", fail_binding)
    monkeypatch.setattr(module, "_remove_wsl_workspace", fail_cleanup)
    with pytest.raises(WrapperRunError, match="link denied") as captured:
        BaseWrapper()
    assert captured.value is primary_error
    assert captured.value.__cause__ is cleanup_error
    assert isolated_transport.removed == isolated_transport.paths


def test_runtime_clone_preserves_primary_error_when_cleanup_fails(isolated_transport, monkeypatch):
    primary_error = ValueError("cache cannot be copied")
    cleanup_error = OSError("workspace cleanup denied")
    with BaseWrapper() as source:
        target = BaseWrapper()
        original_cleanup = target._wsl_cleanup

        def fail_copy(_source):
            raise primary_error

        def fail_cleanup():
            original_cleanup()
            raise cleanup_error

        monkeypatch.setattr(target, "_copy_runtime_cache_from", fail_copy)
        monkeypatch.setattr(target, "_wsl_cleanup", fail_cleanup)
        with pytest.raises(ValueError, match="cache cannot be copied") as captured:
            target.clone_runtime_from(source)
        assert captured.value is primary_error
        assert captured.value.__cause__ is cleanup_error
        assert target._closed
        assert not source._closed
        assert target._stage_dir in isolated_transport.removed


def test_cleanup_rejects_nonowned_paths_without_launching_process(monkeypatch):
    def unexpected(*_args, **_kwargs):
        pytest.fail("Unsafe cleanup launched a process")

    monkeypatch.setattr(subprocess, "run", unexpected)
    for path in ("/tmp", "/var/tmp", "/", "/var/tmp/id-12345678/..", "/home/user/.id", "E:\\CRIS"):
        with pytest.raises(ValueError, match="unowned"):
            module._remove_wsl_workspace(path, 1)


@pytest.mark.skipif(os.name != "nt", reason="real WSL transport requires Windows")
def test_real_wsl_interleaved_and_parallel_workspaces(tmp_path, monkeypatch):
    """Use an independent tiny database, never generate into packaged ISODATA."""
    source = tmp_path / "source"
    source.mkdir()
    reference = source / "database"
    reference.write_bytes(b"reference\n")
    runtime = tmp_path / "inputs"
    runtime.mkdir()
    cfg = SimpleNamespace(
        timeout=20,
        temp_dir=runtime,
        _cfg={"isobyu": {"data_dir": str(source)}},
        resolve_path=Path,
    )
    monkeypatch.setattr(module, "get_config", lambda: cfg)
    before = reference.read_bytes()
    # Construction failure is a test failure, so environment errors cannot be
    # mistaken for acceptance of the isolation contract on the supported host.
    with BaseWrapper() as first:
        first._ensure_writable_isodata()
        with BaseWrapper() as second:
            first._ensure_writable_isodata()
            second._ensure_writable_isodata()
            stages = [first._stage_dir, second._stage_dir]
            assert len(set(stages)) == 2
            assert all(len(stage.encode("ascii")) == 20 for stage in stages)
            for wrapper in (first, second):
                result = wrapper._wsl(f"stat -c %a {shlex.quote(wrapper._stage_dir)}")
                assert result.returncode == 0 and result.stdout == "700"

            def invoke(pair):
                wrapper, content = pair
                script = (
                    'printf "%s\\n" ' + shlex.quote(content) + ' > "$ISODATA/database"\ncat "$ISODATA/database"\npwd\n'
                )
                output = wrapper.run_stdin(PurePosixPath("/bin/sh"), script).splitlines()
                assert output == [content, wrapper._stage_dir]
                staged = wrapper._stage_text("fs", "fixture\n")
                assert len(staged.encode("ascii")) < 48
                return output[0]

            with ThreadPoolExecutor(max_workers=2) as pool:
                assert list(pool.map(invoke, [(first, "first"), (second, "second")])) == ["first", "second"]
            assert reference.read_bytes() == before
        assert first._wsl(f"test -d {shlex.quote(stages[0])}").returncode == 0
        assert first._wsl(f"test ! -e {shlex.quote(stages[1])}").returncode == 0
    assert reference.read_bytes() == before
    assert not list(runtime.glob("isodata-*"))


@pytest.mark.skipif(os.name != "nt", reason="real WSL transport requires Windows")
def test_real_wsl_staging_survives_natural_distro_idle_lifecycle(tmp_path, monkeypatch):
    """The Windows owner can outlive WSL's automatic idle distro shutdown."""
    source = tmp_path / "source"
    source.mkdir()
    (source / "database").write_bytes(b"reference\n")
    cfg = SimpleNamespace(
        timeout=20, temp_dir=tmp_path,
        _cfg={"isobyu": {"data_dir": str(source)}}, resolve_path=Path,
    )
    monkeypatch.setattr(module, "get_config", lambda: cfg)
    with BaseWrapper() as wrapper:
        wrapper._ensure_writable_isodata()
        staged = wrapper._stage_text("fs", "owned input\n")
        assert len(staged.encode("ascii")) < 48
        # No Linux process is kept alive, and no shutdown/restart command is
        # issued. On this host /tmp is tmpfs and disappears during this gap.
        time.sleep(20)
        assert wrapper._wsl(f"cat {shlex.quote(staged)}").stdout == "owned input"
        assert wrapper.run_stdin(
            PurePosixPath("/bin/sh"), 'cat "$ISODATA/database"\n'
        ) == "reference"
        assert wrapper._wsl_cleanup.alive
        assert not wrapper._closed
    assert (source / "database").read_bytes() == b"reference\n"


@pytest.mark.skipif(os.name != "nt", reason="real WSL transport requires Windows")
def test_real_wsl_transaction_clone_keeps_generated_tables_after_parent_close(tmp_path, monkeypatch):
    source_data = tmp_path / "reference"
    source_data.mkdir()
    reference = source_data / "database"
    reference.write_bytes(b"reference\n")
    cfg = SimpleNamespace(
        timeout=20, temp_dir=tmp_path,
        _cfg={"isobyu": {"data_dir": str(source_data)}}, resolve_path=Path,
    )
    monkeypatch.setattr(module, "get_config", lambda: cfg)
    with BaseWrapper() as parent, BaseWrapper() as transaction:
        parent._ensure_writable_isodata()
        parent.run_stdin(
            PurePosixPath("/bin/sh"),
            'printf "generated\\n" > "$ISODATA/database"\n'
            'printf "Space Group 139, Irrep LD1, kparam 1/6\\n" > i123.iso\n',
        )
        assert [entry.name for entry in list_isotropy_cache(parent)] == ["i123.iso"]
        transaction.clone_runtime_from(parent)
        parent.close()
        # This step performs no generation or source recreation: it must use
        # the transaction's independent copy of the previous step's state.
        assert transaction.run_stdin(
            PurePosixPath("/bin/sh"), 'cat "$ISODATA/database"\ncat i123.iso\n'
        ).splitlines() == ["generated", "Space Group 139, Irrep LD1, kparam 1/6"]
        entries = list_isotropy_cache(transaction)
        assert [(entry.name, entry.parent_sg, entry.irrep, entry.kparam) for entry in entries] == [
            ("i123.iso", 139, "LD1", "1/6")
        ]
    assert reference.read_bytes() == b"reference\n"
    assert not list(tmp_path.glob("isodata-*"))
