"""OPD line format and Distortion Page batch export formats."""
from __future__ import annotations

import io
import json
import re
import zipfile
from fractions import Fraction
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
from pymatgen.core import Lattice, Structure

from application.session.core_api import IsoDistort
from backend.utils import OutputParseError, format_opd_line, parse_subgroup_table
from backend.utils.opd_format import (
    active_k_star_coordinates,
    format_k_active,
    format_number,
    k_star_tuples,
    resolve_active_k_star_coordinates,
)
from backend.wrappers import FindsymResult, FindsymWrapper, SubgroupInfo
from backend.export.distortion_formats import (
    FORMAT_CIF,
    FORMAT_ISOVIZ,
    FORMAT_MODES,
    FORMAT_TOPAS,
    SubgroupExportSpec,
    build_export_zip,
    cart_normalized_mode_matrix,
    folder_label_for_subgroup,
    format_filename,
    method3_case_folder,
    parse_export_formats,
    parse_export_method,
    render_cif,
    render_complete_modes,
    render_isoviz,
    render_topas,
    subgroup_identity_digest,
    subgroup_label,
    unique_folder_name,
    write_subgroup_files,
)

_REPO = Path(__file__).resolve().parents[2]
_OFFICIAL_HTML = (
    _REPO / "webpage_info" / "a. ISODISTORT_ order parameter direction.html"
)


def test_findsym_parser_retains_standard_wyckoff_form_and_signed_parameter():
    raw = """\
Space Group: 139  D4h-17    I4/mmm
Origin at    0.00000   0.00000   0.00000
Vectors a,b,c:
   1.00000   0.00000   0.00000
   0.00000   1.00000   0.00000
   0.00000   0.00000   1.00000
Atomic positions and occupancies in terms of a,b,c:
Wyckoff position e (11), z = -0.13885
    1   0.00000   0.00000   0.86115     1.00000
------------------------------------------
# CIF file created by FINDSYM, version 7.1.3
data_findsym-output
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_symmetry_multiplicity
_atom_site_Wyckoff_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
_atom_site_occupancy
_atom_site_fract_symmform
11 1 4 e 0.0000000000 0.0000000000 0.8611500000 1.0000000000 0,0,Dz
"""
    result = FindsymWrapper._parse_output(raw)
    assert result.origin == (0.0, 0.0, 0.0)
    assert np.allclose(result.basis_vectors, np.eye(3))
    assert result.wyckoff_sites[0]["parameters"] == {"z": -0.13885}
    assert result.standardized_sites == [{
        "atom_type": "1",
        "multiplicity": 4,
        "wyckoff_letter": "e",
        "representative_frac_coords": [0.0, 0.0, 0.86115],
        "symmform": "0,0,z",
        "parameters": {"z": -0.13885},
        "input_atom_indices": [0],
    }]


def test_findsym_orbit_metadata_rejects_a_missing_setting_transform():
    structure = Structure(Lattice.cubic(4), ["H"], [[0, 0, 0]])
    wrapper = object.__new__(FindsymWrapper)
    wrapper.identify = lambda *args, **kwargs: FindsymResult(  # type: ignore[method-assign]
        space_group_number=1,
        standardized_sites=[{
            "atom_type": "1",
            "multiplicity": 1,
            "wyckoff_letter": "a",
            "representative_frac_coords": [0.0, 0.0, 0.0],
            "symmform": "x,y,z",
            "parameters": {"x": 0.0, "y": 0.0, "z": 0.0},
        }],
    )

    with pytest.raises(OutputParseError, match="basis transformation"):
        wrapper.standardize_wyckoff_orbits(
            structure,
            [{
                "wyckoff_letter": "a",
                "multiplicity": 1,
                "equivalent_indices": [0],
                "orbit_id": "p1:a:h",
            }],
            expected_space_group=1,
        )


def test_findsym_symmform_supports_implicit_crystallographic_products():
    assert FindsymWrapper._absolute_symmform(
        [0.2, 0.05, 0.3],
        "2Dx,1/2Dx,Dz",
        {"x": 0.1, "z": 0.3},
    ) == "2x,1/2x,z"


def test_findsym_parser_matches_reordered_repeated_letters_by_output_label():
    raw = """\
Space Group: 139  D4h-17    I4/mmm
Origin at    0.00000   0.00000   0.00000
Vectors a,b,c:
   1.00000   0.00000   0.00000
   0.00000   1.00000   0.00000
   0.00000   0.00000   1.00000
Atomic positions and occupancies in terms of a,b,c:
Wyckoff position e (11), z = 0.125
    1   0.00000   0.00000   0.12500     1.00000
Wyckoff position e (21), z = 0.375
    2   0.00000   0.00000   0.37500     1.00000
------------------------------------------
# CIF file created by FINDSYM, version 7.1.3
data_findsym-output
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_symmetry_multiplicity
_atom_site_Wyckoff_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
_atom_site_occupancy
_atom_site_fract_symmform
21 2 4 e 0.0000000000 0.0000000000 0.3750000000 1.0000000000 0,0,Dz
11 1 4 e 0.0000000000 0.0000000000 0.1250000000 1.0000000000 0,0,Dz
"""
    result = FindsymWrapper._parse_output(raw)
    by_type = {site["atom_type"]: site for site in result.standardized_sites}
    assert by_type["1"]["parameters"] == {"z": 0.125}
    assert by_type["2"]["parameters"] == {"z": 0.375}


# --- from test_opd_format.py ---


def test_format_number_preserves_exact_fractions_without_rounding_to_zero():
    assert format_number(Fraction(1, 97)) == "1/97"
    assert format_number(Fraction(2_000_001, 2_000_000)) == "2000001/2000000"
    assert format_number("1/2000001") == "1/2000001"
    assert format_number(0.25) == "1/4"
    approximate = format_number(1 / 97)
    assert approximate == repr(1 / 97)
    assert approximate != "0"
    assert format_number(0.5000000001) == repr(0.5000000001)

def test_parse_subgroup_table_keeps_letter_opd_and_raw_basis():
    text = (
        "Subgroup  Max Index Size Dir         Basis Vectors                Origin\n"
        "139 I4/mmm yes 1     1    P1  (a) (1,0,0),(0,1,0),(0,0,1) (0,0,0)\n"
        "123 P4/mmm yes 4     4    P1  (a;a) (1,-1,0),(1,1,0),(0,0,1) (0,0,0)\n"
        " 12 C2/m  no  4     1    P1  (a,0) (0,1,1),(-1,0,0),(0,-1,0) (1/2,-1/2,0)\n"
    )
    rows = parse_subgroup_table(text)
    assert len(rows) == 3
    assert rows[0]["opd_dir_raw"] == "(a)"
    assert rows[0]["basis_raw"] == "(1,0,0),(0,1,0),(0,0,1)"
    assert rows[0]["origin_raw"] == "(0,0,0)"
    assert rows[1]["opd_dir_raw"] == "(a;a)"
    assert rows[2]["origin_raw"] == "(1/2,-1/2,0)"
    assert rows[2]["origin"] == [0.5, -0.5, 0.0]


def test_format_opd_line_gm1_matches_official_visible_text():
    line = format_opd_line(
        irrep_label="GM1+",
        opd_symbol="P1",
        opd_dir_raw="(a)",
        space_group_number=139,
        space_group_symbol="I4/mmm",
        basis_raw="(1,0,0),(0,1,0),(0,0,1)",
        origin_raw="(0,0,0)",
        size=1,
        subgroup_index=1,
        k_coordinates=["0", "0", "0"],
        parent_sg=139,
    )
    assert line == (
        "GM1+     P1   (a) 139 I4/mmm, basis={(1,0,0),(0,1,0),(0,0,1)}, "
        "origin=(0,0,0), s=1, i=1, k-active= (0,0,0)"
    )


def test_format_opd_line_pads_sg_number_and_x_point():
    line = format_opd_line(
        irrep_label="GM2+",
        opd_symbol="P1",
        opd_dir_raw="(a)",
        space_group_number=71,
        space_group_symbol="Immm",
        basis_raw="(1,0,0),(0,1,0),(0,0,1)",
        origin_raw="(0,0,0)",
        size=1,
        subgroup_index=2,
        k_coordinates=["0", "0", "0"],
        parent_sg=139,
    )
    assert line.startswith("GM2+     P1   (a)  71 Immm")


def test_x_star_and_k_active_two_arms():
    star = k_star_tuples(["1/2", "1/2", "0"], 139)
    assert star[0] == "(1/2,1/2,0)"
    assert len(star) == 2
    assert "(1/2,1/2,1)" in star
    both = format_k_active("(a;a)", ["1/2", "1/2", "0"], 139)
    one = format_k_active("(a;0)", ["1/2", "1/2", "0"], 139)
    assert both == " (1/2,1/2,0),(1/2,1/2,1)"
    assert one == " (1/2,1/2,0)"


def test_n_star_four_arms_partial_active():
    star = k_star_tuples(["1/2", "0", "1/2"], 139)
    assert star == [
        "(1/2,0,1/2)",
        "(1/2,1,1/2)",
        "(0,1/2,1/2)",
        "(1,1/2,1/2)",
    ]
    assert format_k_active("(a;a;0;0)", ["1/2", "0", "1/2"], 139) == (
        " (1/2,0,1/2),(1/2,1,1/2)"
    )
    assert format_k_active("(a;0;a;0)", ["1/2", "0", "1/2"], 139) == (
        " (1/2,0,1/2),(0,1/2,1/2)"
    )


def test_m_point_k_active_keeps_cdml_coords():
    star = k_star_tuples(["1", "1", "1"], 139)
    assert star == ["(1,1,1)"]
    assert format_k_active("(a)", ["1", "1", "1"], 139) == " (1,1,1)"


def test_y_star_keeps_exact_thirds_after_reciprocal_rotation():
    star = k_star_tuples(["1/3", "1/2", "0"], 123)

    assert star[:2] == ["(1/3,1/2,0)", "(1/2,1/3,0)"]
    assert len(star) == 4
    assert all("0.333333" not in arm for arm in star)
    assert format_k_active("(a;a)", ["1/3", "1/2", "0"], 123) == (
        " (1/3,1/2,0),(1/2,1/3,0)"
    )


def test_exact_vector_column_selects_conjugate_dt_and_self_conjugate_x_arms():
    # VECTOR tells us how many conjugate classes are active; the exact child
    # lattice, not local k-star list order, uniquely identifies which classes.
    assert active_k_star_coordinates(
        ("0", "1/3", "0"), 123, "VECTOR,0,0,A,0", 0,
        subgroup_translation_lattice=((3, 0, 0), (0, 2, 0), (0, 0, 1)),
    ) == (("1/3", "0", "0"), ("2/3", "0", "0"))
    assert active_k_star_coordinates(
        ("0", "1/2", "0"), 123, "VECTOR,A,B", 0,
        subgroup_translation_lattice=((3, 0, 0), (0, 2, 0), (0, 0, 1)),
    ) == (("0", "1/2", "0"),)
    assert active_k_star_coordinates(
        ("0", "1/2", "0"), 123, "VECTOR,A,B", 1,
        subgroup_translation_lattice=((2, 0, 0), (0, 3, 0), (0, 0, 1)),
    ) == (("1/2", "0", "0"),)
    exact = resolve_active_k_star_coordinates(
        ("0", "1/2", "0"), 123, "VECTOR,A,B", 0,
        subgroup_translation_lattice=((3, 0, 0), (0, 2, 0), (0, 0, 1)),
    )
    assert exact.resolution_kind == "exact_column_support"
    assert exact.active_class_count == exact.compatible_class_count == 1


def test_active_k_star_resolution_rejects_inconsistent_vector_dimensions():
    with pytest.raises(ValueError, match="cannot be partitioned"):
        active_k_star_coordinates(
            ("0", "1/3", "0"), 123, "VECTOR,A,0,0", 0,
            subgroup_translation_lattice=((3, 0, 0), (0, 2, 0), (0, 0, 1)),
        )


def test_active_k_star_resolution_marks_ambiguous_support_as_envelope():
    resolution = resolve_active_k_star_coordinates(
        ("0", "1/2", "0"), 123, "VECTOR,A,0", 0,
        subgroup_translation_lattice=((2, 0, 0), (0, 2, 0), (0, 0, 1)),
    )

    assert resolution.coordinates == (
        ("0", "1/2", "0"),
        ("1/2", "0", "0"),
    )
    assert resolution.resolution_kind == "compatible_envelope"
    assert resolution.active_class_count == 1
    assert resolution.compatible_class_count == 2


def test_active_k_star_resolution_rejects_too_few_compatible_classes():
    with pytest.raises(ValueError, match="fewer compatible k-star classes"):
        resolve_active_k_star_coordinates(
            ("0", "1/2", "0"), 123, "VECTOR,A,A", 0,
            subgroup_translation_lattice=((3, 0, 0), (0, 2, 0), (0, 0, 1)),
        )


def test_strain_only_gamma_keeps_gm4_not_gm3():
    # This exercises the exact strain representation only.  Bypass the public
    # constructor so an unavailable WSL wrapper cannot turn a pure unit test
    # into an environment-dependent integration test.
    api = object.__new__(IsoDistort)
    api._strain_representation_cache = None
    api.structure = Structure.from_spacegroup(
        "I4/mmm", Lattice.tetragonal(4.0, 10.0), ["Eu"], [[0, 0, 0]],
    )
    gm4 = SimpleNamespace(subgroup=SubgroupInfo(
        index=0,
        parent_sg=139,
        k_point_label="GM",
        irrep_label="GM4+",
        size=1,
        subgroup_index=2,
        space_group_number=69,
        space_group_symbol="Fmmm",
        basis_vectors=[[1, 1, 0], [-1, 1, 0], [0, 0, 1]],
        origin=[0, 0, 0],
    ))
    gm3 = SimpleNamespace(subgroup=SubgroupInfo(
        index=1,
        parent_sg=139,
        k_point_label="GM",
        irrep_label="GM3+",
        size=1,
        subgroup_index=2,
        space_group_number=87,
        space_group_symbol="I4/m",
        basis_vectors=[[1, 0, 0], [0, 1, 0], [0, 0, 1]],
        origin=[0, 0, 0],
    ))
    mirror_only = SimpleNamespace(subgroup=SubgroupInfo(
        index=2,
        parent_sg=139,
        k_point_label="GM",
        # Synthetic even label isolates the representation test: Cs fixes
        # more tensors than D4h, but inversion acts trivially on every strain
        # tensor, so its exact pointwise stabilizer is strictly larger than Cs.
        irrep_label="GM_FAKE+",
        size=1,
        subgroup_index=8,
        space_group_number=8,
        space_group_symbol="Cm",
        basis_vectors=[[-1, 1, 0], [0, 0, 1], [1, 0, 0]],
        origin=[0, 0, 0],
    ))
    assert api._keep_strain_only_irrep(gm4, 139)
    assert not api._keep_strain_only_irrep(gm3, 139)
    assert not api._keep_strain_only_irrep(mirror_only, 139)


def test_subgroup_from_row_uses_iso_basis_raw():
    """Display tokens come from iso output, not a memorized official OPD table."""
    from backend.wrappers.iso_wrapper import IsoWrapper

    row = {
        "space_group_number": 12,
        "space_group_symbol": "C2/m",
        "is_maximal": True,
        "subgroup_index": 4,
        "size": 1,
        "opd_symbol": "P1",
        "opd_vector": [1.0, 0.0],
        "opd_dir_raw": "(a,0)",
        "basis_vectors": [[0, 1, 1], [1, 0, 0], [0, 0, -1]],
        "basis_raw": "(0,1,1),(1,0,0),(0,0,-1)",
        "origin": [0.0, 0.0, 0.0],
        "origin_raw": "(0,0,0)",
    }
    sg = IsoWrapper._subgroup_from_row(
        row, index=0, k_point="GM", irrep_label="GM5+",
        k_coordinates=["0", "0", "0"], parent_sg=139,
    )
    assert sg.basis_raw == "(0,1,1),(1,0,0),(0,0,-1)"
    assert "basis={(0,1,1),(1,0,0),(0,0,-1)}" in sg.opd_line()


def test_subgroupinfo_opd_line_no_maximal_asterisk():
    sg = SubgroupInfo(
        index=0,
        space_group_number=139,
        space_group_symbol="I4/mmm",
        subgroup_index=1,
        size=1,
        is_maximal=True,
        opd_symbol="P1",
        opd_dir_raw="(a)",
        basis_raw="(1,0,0),(0,1,0),(0,0,1)",
        origin_raw="(0,0,0)",
        irrep_label="GM1+",
        k_point_label="GM",
        k_coordinates=["0", "0", "0"],
        parent_sg=139,
    )
    line = sg.opd_line()
    assert "*" not in line
    assert "k-active= (0,0,0)" in line


def test_official_html_radio_lines_parseable():
    if not _OFFICIAL_HTML.is_file():
        return
    html = _OFFICIAL_HTML.read_text(encoding="utf-8", errors="replace")
    lines = re.findall(r'name="orderparam"[^>]*>([^<]+)<br>', html)
    assert len(lines) >= 50
    assert lines[0].startswith("GM1+     P1   (a) 139 I4/mmm")
    assert "basis={(1,0,0),(0,1,0),(0,0,1)}" in lines[0]
    assert "k-active=" in lines[0]
    formatted = format_opd_line(
        irrep_label="GM1+",
        opd_symbol="P1",
        opd_dir_raw="(a)",
        space_group_number=139,
        space_group_symbol="I4/mmm",
        basis_raw="(1,0,0),(0,1,0),(0,0,1)",
        origin_raw="(0,0,0)",
        size=1,
        subgroup_index=1,
        k_coordinates=["0", "0", "0"],
        parent_sg=139,
    )
    assert formatted == lines[0].strip()
    x_p1 = next(ln for ln in lines if ln.startswith("X1+") and "(a;a)" in ln)
    assert "k-active= (1/2,1/2,0),(1/2,1/2,1)" in x_p1
    gm4 = next(ln for ln in lines if ln.startswith("GM4+"))
    assert "69 Fmmm" in gm4
    assert "basis={(1,1,0),(-1,1,0),(0,0,1)}" in gm4
    gm5_bases = [
        ln for ln in lines if ln.startswith("GM5+")
    ]
    assert any("{(0,1,1),(-1,0,0),(0,-1,0)}" in ln for ln in gm5_bases)
    assert any("{(1,-1,0),(1,1,0),(-1/2,1/2,1/2)}" in ln for ln in gm5_bases)
    assert any("{(1,0,0),(0,1,0),(-1/2,-1/2,1/2)}" in ln for ln in gm5_bases)
    m1 = next(ln for ln in lines if ln.startswith("M1+"))
    assert "k-active= (1,1,1)" in m1


def test_official_method1_fields_match_radio_tokens():
    from backend.utils.opd_format import official_method1_fields

    fields = official_method1_fields(
        irrep_label="GM1+",
        opd_symbol="P1",
        opd_dir_raw="(a)",
        space_group_number=139,
        space_group_symbol="I4/mmm",
        basis_raw="(1,0,0),(0,1,0),(0,0,1)",
        origin_raw="(0,0,0)",
        size=1,
        subgroup_index=1,
        k_coordinates=["0", "0", "0"],
        parent_sg=139,
    )
    assert fields["irrep"] == "GM1+"
    assert fields["opd"] == "P1"
    assert fields["dir"] == "(a)"
    assert fields["sg"] == "139 I4/mmm"
    assert fields["basis"] == "{(1,0,0),(0,1,0),(0,0,1)}"
    assert fields["origin"] == "(0,0,0)"
    assert fields["s"] == 1
    assert fields["i"] == 1
    assert fields["k_active"] == "(0,0,0)"
    sg = SubgroupInfo(
        index=0,
        space_group_number=139,
        space_group_symbol="I4/mmm",
        subgroup_index=1,
        size=1,
        opd_symbol="P1",
        opd_dir_raw="(a)",
        basis_raw="(1,0,0),(0,1,0),(0,0,1)",
        origin_raw="(0,0,0)",
        irrep_label="GM1+",
        k_coordinates=["0", "0", "0"],
        parent_sg=139,
    )
    assert sg.official_fields()["k_active"] == "(0,0,0)"
    assert "k-active= (0,0,0)" in sg.opd_line()


# --- from test_distortion_export.py ---

def _sg(irrep: str, opd: str, index: int = 0, number: int = 123,
        symbol: str = "P4/mmm") -> SubgroupInfo:
    return SubgroupInfo(
        index=index,
        space_group_number=number,
        space_group_symbol=symbol,
        subgroup_index=12,
        size=12,
        opd_symbol=opd,
        basis_vectors=[[1, 0, 0], [0, 1, 0], [0, 0, 6]],
        origin=[0, 0, 0],
        k_point_label="LD",
        irrep_label=irrep,
        k_parameters=["1/6"],
    )


def _cubic() -> Structure:
    return Structure(
        [[4.0, 0, 0], [0, 4.0, 0], [0, 0, 4.0]],
        ["Eu", "Al"],
        [[0, 0, 0], [0.5, 0.5, 0.5]],
    )


def test_parse_export_formats_aliases():
    assert parse_export_formats(None) == [FORMAT_CIF]
    assert parse_export_formats("cif,isoviz,modes,topas") == [
        FORMAT_CIF, FORMAT_ISOVIZ, FORMAT_MODES, FORMAT_TOPAS,
    ]
    assert parse_export_formats("structurefile,completemodesdetails,TOPAS.STR") == [
        FORMAT_CIF, FORMAT_MODES, FORMAT_TOPAS,
    ]
    assert parse_export_formats(["CIF file", "Save interactive distortion"]) == [
        FORMAT_CIF, FORMAT_ISOVIZ,
    ]


def test_parse_export_formats_rejects_unknown():
    with pytest.raises(ValueError, match="未知导出格式"):
        parse_export_formats("poscar")


def test_parse_export_method_single_only():
    assert parse_export_method(None) == 2
    assert parse_export_method("1") == 1
    assert parse_export_method("method2") == 2
    assert parse_export_method("M3") == 3
    with pytest.raises(ValueError, match="不能多选"):
        parse_export_method("1,2")
    with pytest.raises(ValueError, match="未知 Method"):
        parse_export_method("4")


def test_subgroup_label_and_filenames():
    sg = _sg("LD1", "C1")
    assert subgroup_label(sg) == "LD1 C1"
    assert format_filename("LD1 C1", FORMAT_CIF) == "subgroup.cif"
    assert format_filename("LD1 C1", FORMAT_ISOVIZ) == "data.isoviz"
    assert format_filename("LD1 C1", FORMAT_MODES) == "Complete modes details.txt"
    assert format_filename("LD1 C1", FORMAT_TOPAS) == "topas.str"


def test_safe_name_cleans_windows_characters_without_losing_irrep_signs():
    from backend.export.distortion_formats import safe_name

    assert safe_name("N1+/<bad>: 4D1*") == "N1+_bad_4D1"
    assert safe_name("N1- 4D1") == "N1-_4D1"
    assert safe_name("CON") == "_CON"


def test_opd_line_body_omits_irrep_for_cif_comment():
    from backend.utils.opd_format import format_opd_line_body

    body = format_opd_line_body(
        opd_symbol="P1",
        opd_dir_raw="(a)",
        space_group_number=71,
        space_group_symbol="Immm",
        basis_raw="(1,0,0),(0,1,0),(0,0,1)",
        origin_raw="(0,0,0)",
        size=1,
        subgroup_index=2,
        k_coordinates=["0", "0", "0"],
        parent_sg=139,
        pad_opd=True,
    )
    assert body.startswith("P1   (a)  71 Immm")
    assert not body.startswith("GM")

    m2 = format_opd_line_body(
        opd_symbol="C1",
        opd_dir_raw="(a,b)",
        space_group_number=99,
        space_group_symbol="P4mm",
        basis_raw="(1,0,0),(0,1,0),(0,0,6)",
        origin_raw="(0,0,0)",
        size=12,
        subgroup_index=24,
        k_coordinates=["0", "0", "1/6"],
        parent_sg=139,
        pad_opd=False,
    )
    assert m2.startswith("C1 (a,b)  99 P4mm")


def test_short_folder_names_follow_each_method_rule():
    subgroup = _sg("N1+", "4D1", number=2)

    assert folder_label_for_subgroup(subgroup, export_method=1) == "N1+_4D1_SG2"
    assert folder_label_for_subgroup(subgroup, export_method=2) == "N1+_4D1"
    assert (
        folder_label_for_subgroup(subgroup, export_method=3, sequence=7)
        == "C07_SG2"
    )


def test_unique_folder_name_disambiguates_with_stable_identity_digest():
    used: set[str] = set()
    first = _sg("LD1", "C1", index=0, symbol="P4/mmm")
    second = _sg("LD1", "C1", index=1, symbol="P4mm")
    second.origin = [0.5, 0, 0]

    a = unique_folder_name(first, used, export_method=1)
    b = unique_folder_name(second, used, export_method=1)

    assert a == "LD1_C1_SG123"
    assert re.fullmatch(r"LD1_C1_SG123_[0-9a-f]{10}", b)
    assert a != b

    case_insensitive_used = {"ld1_c1"}
    method2 = unique_folder_name(first, case_insensitive_used, export_method=2)
    assert re.fullmatch(r"LD1_C1_[0-9a-f]{10}", method2)


def test_method3_generated_case_id_is_generic_and_order_independent():
    first = _sg("GM1+", "P1", index=0, number=139)
    second = _sg("N1+", "4D1", index=1, number=2)

    generated = method3_case_folder([first, second])
    assert re.fullmatch(r"M3-[0-9a-f]{10}", generated)
    assert generated == method3_case_folder([second, first])
    assert method3_case_folder([first], "case:01") == "case_01"


def test_zip_contains_only_method2_subgroups_named_by_ir_opd():
    """压缩包只含给定子群，按子群文件夹分类；不混入其它文件名。"""
    parent = _cubic()
    disp = {"LD1": np.zeros((2, 3))}
    disp["LD1"][0, 2] = 1.0
    specs = [
        SubgroupExportSpec(
            subgroup=_sg("LD1", "C1", index=0),
            structure=parent,
            parent_structure=parent,
            parent_sg=139,
            parent_symbol="I4/mmm",
            mode_displacements_sc=disp,
            folder_name="LD1_C1",
        ),
        SubgroupExportSpec(
            subgroup=_sg("LD5", "P6", index=1, number=11, symbol="P2_1/m"),
            structure=parent,
            parent_structure=parent,
            parent_sg=139,
            parent_symbol="I4/mmm",
            folder_name="LD5_P6",
        ),
    ]
    raw = build_export_zip(
        specs,
        [FORMAT_CIF, FORMAT_ISOVIZ, FORMAT_MODES, FORMAT_TOPAS],
    )
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        names = zf.namelist()

    # 各子群文件夹在 ZIP 根下（官网同款）
    assert any(n.startswith("LD1_C1/") for n in names)
    assert any(n.startswith("LD5_P6/") for n in names)
    assert "LD1_C1/subgroup.cif" in names
    assert "LD1_C1/data.isoviz" in names
    assert "LD1_C1/Complete modes details.txt" in names
    assert "LD1_C1/topas.str" in names
    assert "LD5_P6/subgroup.cif" in names
    # 不应出现旧版 output_dir 风格的无关文件名
    joined = "\n".join(names)
    assert "mixed_" not in joined
    assert "distorted_" not in joined
    assert ".json" not in joined
    assert len(names) == 8  # 2 子群 × 4 格式


def test_cif_only_zip_has_no_other_formats():
    spec = SubgroupExportSpec(
        subgroup=_sg("LD1", "C1"),
        structure=_cubic(),
        folder_name="LD1_C1",
    )
    raw = build_export_zip([spec], [FORMAT_CIF])
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        names = zf.namelist()
    assert names == ["LD1_C1/subgroup.cif"]


def test_zip_never_emits_duplicate_paths_for_colliding_short_names():
    parent = _cubic()
    first = _sg("LD1", "C1", index=0)
    second = _sg("LD1", "C1", index=1)
    second.origin = [0.5, 0, 0]
    specs = [
        SubgroupExportSpec(first, parent, folder_name="LD1_C1"),
        SubgroupExportSpec(second, parent, folder_name="LD1_C1"),
    ]

    raw = build_export_zip(specs, [FORMAT_CIF])
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        names = zf.namelist()

    assert len(names) == 2
    assert len({name.casefold() for name in names}) == 2
    assert "LD1_C1/subgroup.cif" in names
    assert any(
        re.fullmatch(r"LD1_C1_[0-9a-f]{10}/subgroup\.cif", name)
        for name in names
    )


def _minimal_export_api(parent: Structure) -> IsoDistort:
    iso = object.__new__(IsoDistort)
    iso.structure = parent
    iso.symmetry_info = None
    iso.distortion_types = []
    iso._selected_subgroup = None
    iso.phase_path = None
    iso.distortion_modes = []
    iso.mode_displacements = {}
    iso.mode_occupancies = {}
    iso.mode_displacements_sc = {}
    iso._mode_label_overrides = {}
    iso.distorted_structure = None
    iso.number_of_independent_modulations = 0
    iso._spec_for_subgroup = lambda subgroup, **kwargs: SubgroupExportSpec(
        subgroup=subgroup,
        structure=parent,
        folder_name=kwargs["folder_name"],
    )
    return iso


def test_method3_api_zip_uses_generated_case_and_short_candidate_folders():
    parent = _cubic()
    first = _sg("GM1+", "P1", index=0, number=139)
    second = _sg("N1+", "4D1", index=1, number=2)
    iso = _minimal_export_api(parent)

    raw = iso.export_subgroups_zip(
        formats=[FORMAT_CIF],
        subgroups=[first, second],
        export_method=3,
    )
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        names = zf.namelist()
        case = method3_case_folder([first, second])
        status = json.loads(zf.read(f"{case}/export_candidate_status.json"))

    assert names == [
        f"{case}/C01_SG139/subgroup.cif",
        f"{case}/C02_SG2/subgroup.cif",
        f"{case}/export_candidate_status.json",
        f"{case}/export_candidate_status.txt",
    ]
    assert status["status"] == "success"
    assert status["successful_candidate_count"] == status["requested_candidate_count"] == 2


def test_directory_export_never_overwrites_an_existing_short_folder(tmp_path):
    parent = _cubic()
    subgroup = _sg("N1+", "4D1", index=0, number=2)
    iso = _minimal_export_api(parent)

    first = iso.export_subgroups(
        tmp_path,
        formats=[FORMAT_CIF],
        subgroups=[subgroup],
        export_method=1,
    )
    first_content = first[0].read_bytes()
    second = iso.export_subgroups(
        tmp_path,
        formats=[FORMAT_CIF],
        subgroups=[subgroup],
        export_method=1,
    )

    assert first == [
        tmp_path / "N1+_4D1_SG2" / "subgroup.cif",
        tmp_path / "export_candidate_status.json",
        tmp_path / "export_candidate_status.txt",
    ]
    assert second[0].parent.name == (
        f"N1+_4D1_SG2_{subgroup_identity_digest(subgroup)}"
    )
    assert first[0].read_bytes() == second[0].read_bytes() == first_content
    assert json.loads(first[1].read_text(encoding="utf-8"))["status"] == "success"


def test_directory_writer_render_failure_leaves_no_destination(
    tmp_path,
    monkeypatch,
):
    spec = SubgroupExportSpec(
        subgroup=_sg("LD1", "C1"),
        structure=_cubic(),
        folder_name="LD1_C1",
    )
    dest_dir = tmp_path / "LD1_C1"

    def fail_on_second_format(fmt, _spec):
        if fmt == FORMAT_ISOVIZ:
            raise RuntimeError("later render failed")
        return b"first format"

    monkeypatch.setattr(
        "backend.export.distortion_formats.render_format",
        fail_on_second_format,
    )

    with pytest.raises(RuntimeError, match="later render failed"):
        write_subgroup_files(dest_dir, spec, [FORMAT_CIF, FORMAT_ISOVIZ])

    assert not dest_dir.exists()
    assert list(tmp_path.iterdir()) == []


def test_directory_writer_rejects_existing_destination_without_changes(tmp_path):
    spec = SubgroupExportSpec(
        subgroup=_sg("LD1", "C1"),
        structure=_cubic(),
        folder_name="LD1_C1",
    )
    dest_dir = tmp_path / "LD1_C1"
    dest_dir.mkdir()
    sentinel = dest_dir / "keep.txt"
    sentinel.write_bytes(b"unchanged")

    with pytest.raises(FileExistsError, match="目标目录已存在"):
        write_subgroup_files(dest_dir, spec, [FORMAT_CIF])

    assert sentinel.read_bytes() == b"unchanged"
    assert list(dest_dir.iterdir()) == [sentinel]


def test_directory_writer_rejects_duplicate_filenames_before_publication(tmp_path):
    spec = SubgroupExportSpec(
        subgroup=_sg("LD1", "C1"),
        structure=_cubic(),
        folder_name="LD1_C1",
    )
    dest_dir = tmp_path / "LD1_C1"

    with pytest.raises(ValueError, match="重复文件名"):
        write_subgroup_files(dest_dir, spec, [FORMAT_CIF, FORMAT_CIF])

    assert not dest_dir.exists()
    assert list(tmp_path.iterdir()) == []


def test_format_writers_contain_official_markers():
    parent = _cubic()
    disp = {"LD1": np.array([[0.0, 0.0, 0.2], [0.0, 0.0, 0.0]])}
    spec = SubgroupExportSpec(
        subgroup=_sg("LD1", "C1"),
        structure=parent,
        parent_structure=parent,
        parent_sg=139,
        parent_symbol="I4/mmm",
        mode_displacements_sc=disp,
        mode_labels={"LD1": "[Eu:a:dsp]A2u(a)"},
    )
    cif = render_cif(parent)
    assert "data_isodistort-output" in cif
    assert "_cell_length_a" in cif
    cif_spec = render_cif(parent, spec)
    assert "_iso_parentcell_length_a" in cif_spec
    assert "_space_group_symop_operation_xyz" in cif_spec

    isoviz = render_isoviz(spec)
    assert "!isoversion" in isoviz
    assert "!displacivemodelist" in isoviz
    assert "LD1" in isoviz or "[Eu:a:dsp]A2u(a)" in isoviz
    # IsoVIZ invariant: mode vector count == atomcoordlist rows for parentatom
    lines = isoviz.splitlines()
    coords: list[int] = []
    in_c = False
    for line in lines:
        if line.startswith("!atomcoordlist"):
            in_c = True
            continue
        if line.startswith("!") and in_c:
            in_c = False
        if in_c and line.strip():
            coords.append(int(line.split()[0]))
    i = next(k for k, line in enumerate(lines) if line.startswith("!displacivemodelist"))
    parentatom = None
    nvecs = 0
    for line in lines[i + 1 :]:
        if not line.strip():
            break
        if line.startswith("!"):
            break
        parts = line.split()
        try:
            pa = int(parts[0])
            float(parts[2])
            float(parts[3])
            int(parts[1])
            int(parts[4])
            parentatom = pa
            nvecs = 0
            continue
        except (ValueError, IndexError):
            pass
        if parentatom is not None:
            nvecs += 1
    assert parentatom is not None
    assert nvecs == coords.count(parentatom)

    details = render_complete_modes(spec)
    assert "Complete modes details" in details
    assert "normfactor" in details
    assert "As=" in details and "Ap=" in details

    topas = render_topas(spec)
    assert topas.startswith("'Topas .str file generated by ISODISTORT")
    assert "space_group" in topas
    assert "prm  !a1" in topas or "prm !a1" in topas
    assert "mode-amplitude to delta" in topas


def test_mode_maxamp_is_inverse_dmax_at_unit_as():
    """ISODISTORT slider/TOPAS bound makes dmax reach exactly 1 Angstrom.

    The eight equal displacements emulate a primitive-cell-normalized mode:
    after As normalization each atom moves 1/sqrt(8) Angstrom, so the allowed
    amplitude is sqrt(8), independently of the arbitrary fractional scale of
    the input eigenvector.
    """
    lattice = np.diag([4.0, 5.0, 10.0])
    mode = np.zeros((8, 3), dtype=float)
    mode[:, 2] = 0.2

    scaled, maxamp = cart_normalized_mode_matrix(mode, lattice)
    dmax_at_as_one = np.max(np.linalg.norm(scaled @ lattice, axis=1))

    assert np.sum((scaled @ lattice) ** 2) == pytest.approx(1.0)
    assert maxamp == pytest.approx(np.sqrt(8.0))
    assert maxamp * dmax_at_as_one == pytest.approx(1.0)


def test_centered_mode_normalization_uses_primitive_cell_and_physical_dmax():
    lattice = np.diag([4.0, 5.0, 10.0])
    mode = np.zeros((8, 3), dtype=float)
    mode[:, 2] = 1.0

    scaled, maxamp = cart_normalized_mode_matrix(
        mode, lattice, centering_mult=2
    )
    cartesian = scaled @ lattice

    assert np.sum(cartesian**2) / 2 == pytest.approx(1.0)
    assert maxamp * np.max(np.linalg.norm(cartesian, axis=1)) == pytest.approx(1.0)


@pytest.mark.parametrize("magnitude", [1e-20, 1e-300, 1e300])
@pytest.mark.parametrize("sign", [-1.0, 1.0])
def test_cart_normalization_preserves_direction_at_extreme_column_scales(magnitude, sign):
    lattice = np.array([[4.0, 0.4, 0.2], [0.1, 5.0, 0.7], [0.3, -0.2, 6.0]])
    mode = np.array([[1.0, -2.0, 0.5], [0.25, 0.0, 1.5], [-0.75, 0.5, 0.0]])
    # The reference is evaluated at ordinary magnitude from the declared
    # row-coordinate metric, independently of the implementation's scaling.
    ordinary_cart = mode @ lattice
    expected = sign * mode / np.sqrt(np.sum(ordinary_cart**2) / 2)
    expected_cart = expected @ lattice
    expected_bound = 1.0 / np.max(np.linalg.norm(expected_cart, axis=1))

    normalized, bound = cart_normalized_mode_matrix(
        sign * magnitude * mode, lattice, centering_mult=np.int64(2)
    )

    np.testing.assert_allclose(normalized, expected, rtol=2e-14, atol=0)
    cart = normalized @ lattice
    assert np.sum(cart**2) / 2 == pytest.approx(1.0, rel=2e-14)
    assert bound == pytest.approx(expected_bound, rel=2e-14)
    assert bound * np.max(np.linalg.norm(cart, axis=1)) == pytest.approx(1.0, rel=2e-14)


@pytest.mark.parametrize("lattice_scale", [1e-300, 1e300])
def test_cart_normalization_avoids_lattice_norm_overflow_and_underflow(lattice_scale):
    mode = np.array([[1.0, 2.0, 0.0], [-1.0, 0.5, 1.0]])
    lattice = lattice_scale * np.array([[4.0, 0.5, 0.0], [0.0, 5.0, 0.25], [0.5, 0.0, 6.0]])
    normalized, bound = cart_normalized_mode_matrix(mode, lattice)
    cart = normalized @ lattice
    assert np.isfinite(normalized).all()
    assert np.sum(cart**2) == pytest.approx(1.0, rel=2e-14)
    assert bound * np.max(np.linalg.norm(cart, axis=1)) == pytest.approx(1.0, rel=2e-14)


@pytest.mark.parametrize("mode,lattice", [
    # A/L loses the first Cartesian contribution while the third is rounded
    # into the subnormal range. Previously the returned norm squared was
    # 0.5325667378703975, yet the returned amplitude bound was exactly 1.
    ([[1.0, 0.0, 3e-24]], np.diag([2e-24, 1e300, 1.0])),
    # All scaled lattice/input components are normal, but their nonzero
    # product underflows; checking only the final dot product misses this.
    ([[1e-24, 0.0, 1.0]], np.diag([1e-200, 1e100, 1.0])),
    # The original column's component range cannot survive division by max|U|.
    ([[1e300, 1e-300, 1e300]], np.diag([1.0, 1e300, 1.0])),
    # Direction survives all intermediate products but not the returned V.
    ([[1.0, 1e-300, 0.0]], 1e300 * np.eye(3)),
])
@pytest.mark.parametrize("sign", [-1.0, 1.0])
def test_cart_normalization_rejects_component_underflow(mode, lattice, sign):
    with pytest.raises(ValueError, match="underflow"):
        cart_normalized_mode_matrix(sign * np.asarray(mode), lattice)


def test_cart_normalization_preserves_small_normal_cartesian_components():
    mode = np.array([[1.0, 0.0, 1e-300]])
    lattice = np.diag([2e-300, 1.0, 1.0])
    normalized, bound = cart_normalized_mode_matrix(mode, lattice)
    expected_cartesian = np.array([[2.0, 0.0, 1.0]]) / np.sqrt(5.0)
    np.testing.assert_allclose(normalized @ lattice, expected_cartesian, rtol=2e-14, atol=0)
    assert bound == pytest.approx(1.0, rel=2e-14)


def test_cart_normalization_ignores_lattice_components_absent_from_the_mode():
    # A subnormal entry in a row multiplied only by structural zeros cannot
    # affect this column. Do not classify it as a lost contribution.
    normalized, bound = cart_normalized_mode_matrix(
        np.array([[1.0, 0.0, 0.0]]), np.diag([1.0, 1e-310, 1.0]),
    )
    np.testing.assert_array_equal(normalized, [[1.0, 0.0, 0.0]])
    assert bound == 1.0


@pytest.mark.parametrize("multiplicity", [0, -1, True, np.bool_(True), 1.5, 2.0, "2", np.nan])
def test_cart_normalization_rejects_invalid_multiplicity(multiplicity):
    with pytest.raises(ValueError, match="positive integer"):
        cart_normalized_mode_matrix(np.array([[1.0, 0.0, 0.0]]), np.eye(3), centering_mult=multiplicity)


@pytest.mark.parametrize("mode", [
    np.zeros((2, 3)), np.zeros((0, 3)), np.ones(3), np.ones((2, 2)),
    np.array([[np.nan, 0.0, 0.0]]), np.array([[np.inf, 0.0, 0.0]]),
    np.array([[1.0 + 1.0j, 0.0, 0.0]]),
])
def test_cart_normalization_rejects_zero_nonfinite_or_invalid_mode(mode):
    with pytest.raises(ValueError):
        cart_normalized_mode_matrix(mode, np.eye(3))


@pytest.mark.parametrize("lattice", [
    np.ones((2, 3)), np.zeros((3, 3)),
    np.array([[1.0, 2.0, 3.0], [2.0, 4.0, 6.0], [0.0, 0.0, 1.0]]),
    np.diag([1.0, np.nan, 1.0]), np.diag([1.0, np.inf, 1.0]),
])
def test_cart_normalization_rejects_invalid_lattice(lattice):
    with pytest.raises(ValueError):
        cart_normalized_mode_matrix(np.array([[1.0, 0.0, 0.0]]), lattice)


def test_cart_normalization_does_not_treat_small_nonzero_lattice_volume_as_singular():
    lattice = np.diag([1e-20, 1.0, 1.0])
    normalized, bound = cart_normalized_mode_matrix(np.array([[1.0, 0.0, 0.0]]), lattice)
    np.testing.assert_allclose(normalized @ lattice, [[1.0, 0.0, 0.0]], rtol=2e-14, atol=0)
    assert bound == pytest.approx(1.0, rel=2e-14)


def test_complete_modes_uses_primitive_norm_ap_and_dmax_definitions():
    structure = Structure(
        np.diag([4.0, 5.0, 10.0]),
        ["Eu"] * 4,
        [[0, 0, 0], [0.5, 0.5, 0.5], [0.25, 0.25, 0.25], [0.75, 0.75, 0.75]],
    )
    subgroup = _sg("GM1+", "P1", number=139, symbol="I4/mmm")
    subgroup.size = 2
    mode = np.zeros((4, 3), dtype=float)
    mode[:, 2] = 1.0
    spec = SubgroupExportSpec(
        subgroup=subgroup,
        structure=structure,
        parent_structure=structure,
        mode_displacements_sc={"mode": mode},
        amplitudes={"mode": 2.0},
    )

    details = render_complete_modes(spec)

    # Σ_conventional |B'u|^2=400 A^2; I centring gives 200 A^2 per
    # primitive cell.  With As=2 A and s=2: norm=1/sqrt(200),
    # Ap=sqrt(2) A and dmax=As*norm*10=sqrt(2) A.
    assert "normfactor = 0.0707107 Angstrom^-1" in details
    assert "As=  2.000000" in details
    assert "Ap=  1.414214" in details
    assert "dmax=  1.414214 Angstrom" in details
    assert "over one primitive unit cell equal to 1.0" in details
    assert "centering-equivalent atoms" in details


def test_i4mmm_cif_keeps_origin_zero_wyckoff():
    """I4/mmm identity subgroup must keep Eu at 2a (0,0,0), not a quarter-shifted 8g."""
    from pymatgen.core import Lattice

    parent = Structure(
        Lattice.tetragonal(4.402, 11.163),
        ["Eu", "Eu", "Al", "Al", "Al", "Al", "Al", "Al", "Al", "Al"],
        [
            [0, 0, 0], [0.5, 0.5, 0.5],
            [0, 0.5, 0.25], [0.5, 0, 0.25], [0.5, 0, 0.75], [0, 0.5, 0.75],
            [0, 0, 0.38], [0, 0, 0.62], [0.5, 0.5, 0.12], [0.5, 0.5, 0.88],
        ],
    )
    sg = SubgroupInfo(
        index=0,
        space_group_number=139,
        space_group_symbol="I4/mmm",
        subgroup_index=1,
        size=1,
        opd_symbol="P1",
        opd_dir_raw="(a)",
        basis_vectors=[[1, 0, 0], [0, 1, 0], [0, 0, 1]],
        basis_raw="(1,0,0),(0,1,0),(0,0,1)",
        origin=[0.0, 0.0, 0.0],
        origin_raw="(0,0,0)",
        k_point_label="GM",
        irrep_label="GM1+",
        k_coordinates=["0", "0", "0"],
        parent_sg=139,
    )
    spec = SubgroupExportSpec(
        subgroup=sg,
        structure=parent,
        parent_structure=parent,
        parent_sg=139,
        parent_symbol="I4/mmm",
    )
    text = render_cif(parent, spec)
    assert 'H-M "I 4/m 2/m 2/m"' in text
    assert re.search(r"Eu\d*_1\s+Eu\s+2\s+a\s+0\.00000\s+0\.00000\s+0\.00000", text)
    assert re.search(r"Al\d*_1\s+Al\s+4\s+d\s+0\.00000\s+0\.50000\s+0\.25000", text)
    assert re.search(r"Al\d*_\d+\s+Al\s+4\s+e\s+0\.00000\s+0\.00000\s+0\.38000", text)
    assert "_iso_parent-to-child.transform_Pp_abc a,b,c;0,0,0" in text
    assert "8 g" not in text


def test_k_active_substitutes_ld_parameter():
    from backend.tables.kpoints_official import official_special_k_coords

    coords = official_special_k_coords(139, "LD", [], ["1/6"])
    assert coords == ["0", "0", "1/6"]


def test_subgroup_cif_origin_preserves_atom_count(tmp_path):
    """The subgroup's origin must make its symmetry operations valid."""
    from pymatgen.io.cif import CifParser

    from backend.input_cif import read_cif

    parent = read_cif(_REPO / "experiment_data" / "EuAl4 Parent.cif")
    subgroup = SubgroupInfo(
        index=0, space_group_number=137, space_group_symbol="P4_2/nmc",
        subgroup_index=2, size=2, opd_symbol="P1", opd_dir_raw="(a)",
        basis_vectors=[[1, 0, 0], [0, 1, 0], [0, 0, 1]],
        origin=[0.25, 0.75, 0.25], origin_raw="(1/4,3/4,1/4)",
        k_point_label="M", irrep_label="M4-", parent_sg=139,
    )
    spec = SubgroupExportSpec(
        subgroup=subgroup, structure=parent, parent_structure=parent,
        parent_sg=139, parent_symbol="I4/mmm",
    )
    path = tmp_path / "subgroup.cif"
    path.write_text(render_cif(parent, spec), encoding="utf-8")
    parsed = CifParser(str(path), occupancy_tolerance=100).parse_structures(
        primitive=False
    )[0]
    assert len(parsed) == len(parent) == 10
    assert parsed.composition == parent.composition


def test_explicit_valid_origin_outweighs_asymmetric_site_count():
    """NdNiO2 A1+ P1 uses origin zero even though z=1/4 has fewer ASU rows."""
    from backend.utils.parent_header import parent_wyckoff_display
    from backend.export.isodistort_cif import _apply_origin_choice, _setting
    from backend.input_cif import SymmetryValidator, read_cif
    from backend.input_cif.coordinate_transform import build_supercell

    path = _REPO / "experiment_data" / "NdNiO2 own.cif"
    parent = read_cif(path)
    basis = [[1, 1, 0], [-1, 1, 0], [0, 0, 2]]
    child = build_supercell(parent, basis)
    subgroup = SubgroupInfo(
        index=0, space_group_number=139, space_group_symbol="I4/mmm",
        subgroup_index=1, size=2, opd_symbol="P1", opd_dir_raw="(a)",
        basis_vectors=basis, origin=[0, 0, 0], k_point_label="A",
        irrep_label="A1+", parent_sg=123,
    )
    _shifted, origin = _apply_origin_choice(
        child, _setting(subgroup, force_p1=False), [0, 0, 0]
    )
    assert np.allclose(origin, [0, 0, 0])
    wyckoff = SymmetryValidator().validate(parent)["wyckoff_sites"]
    labels = parent_wyckoff_display(parent, wyckoff, path)
    spec = SubgroupExportSpec(
        subgroup=subgroup, structure=child, parent_structure=parent,
        parent_sg=123, parent_symbol="P4/mmm",
        parent_wyckoff_sites=wyckoff, parent_wyckoff_lines=labels,
    )
    displayed = render_isoviz(spec).split("!atomcoordlist \n", 1)[1].split("\n\n", 1)[0]
    assert len(displayed.splitlines()) == 35
    assert "0.25000   0.25000   0.00000" in displayed


def test_topas_uses_target_subgroup_orbits():
    """A P1 TOPAS file must keep sites equivalent only in the parent group."""
    parent = Structure(
        [[3, 0, 0], [0, 3, 0], [0, 0, 3]],
        ["Fe", "Fe"], [[0, 0, 0], [0.5, 0.5, 0.5]],
    )
    subgroup = SubgroupInfo(
        index=0, space_group_number=1, space_group_symbol="P1",
        subgroup_index=1, size=1, opd_symbol="P1", opd_dir_raw="(a)",
        basis_vectors=[[1, 0, 0], [0, 1, 0], [0, 0, 1]],
        origin=[0, 0, 0], k_point_label="GM", irrep_label="GM1+",
        parent_sg=229,
    )
    spec = SubgroupExportSpec(
        subgroup=subgroup, structure=parent, parent_structure=parent,
        parent_sg=229, parent_symbol="Im-3m",
        parent_wyckoff_sites=[{
            "species": "Fe", "multiplicity": 2, "wyckoff_letter": "a",
            "representative_index": 0, "equivalent_indices": [0, 1],
            "display_label": "Fe", "display_order": 0,
        }],
    )
    text = render_topas(spec)
    sites = re.findall(r"^\s*site (\S+)", text, re.M)
    assert len(sites) == len(set(sites)) == 2


def test_isoviz_expands_boundary_images_and_mode_vectors():
    """Boundary atoms and their mode vectors need the same display images."""
    parent = Structure(
        [[3, 0, 0], [0, 3, 0], [0, 0, 3]], ["Fe"], [[0, 0, 0]],
    )
    subgroup = SubgroupInfo(
        index=0, space_group_number=221, space_group_symbol="Pm-3m",
        subgroup_index=1, size=1, opd_symbol="P1", opd_dir_raw="(a)",
        basis_vectors=[[1, 0, 0], [0, 1, 0], [0, 0, 1]],
        origin=[0, 0, 0], k_point_label="GM", irrep_label="GM1+",
        parent_sg=221,
    )
    spec = SubgroupExportSpec(
        subgroup=subgroup, structure=parent, parent_structure=parent,
        parent_sg=221, parent_symbol="Pm-3m",
        mode_displacements_sc={"test": np.array([[1.0, 0.0, 0.0]])},
    )
    text = render_isoviz(spec)
    atom_rows = text.split("!atomcoordlist \n", 1)[1].split("\n\n", 1)[0].splitlines()
    flags = text.split("!atomsinunitcell \n", 1)[1].split("\n\n", 1)[0].splitlines()
    mode_rows = text.split("!displacivemodelist \n", 1)[1].split("\n\n", 1)[0].splitlines()
    assert len(atom_rows) == len(flags) == 8
    assert [int(flag) for flag in flags] == [1, 0, 0, 0, 0, 0, 0, 0]
    assert len(mode_rows) == 9  # header plus one vector per displayed image


def test_isoviz_subtypes_follow_target_subgroup_orbits():
    """Atoms merged by parent symmetry remain separate P1 subatoms."""
    parent = Structure(
        [[3, 0, 0], [0, 3, 0], [0, 0, 3]],
        ["Fe", "Fe"], [[0, 0, 0], [0.5, 0.5, 0.5]],
    )
    subgroup = SubgroupInfo(
        index=0, space_group_number=1, space_group_symbol="P1",
        subgroup_index=1, size=1, opd_symbol="P1", opd_dir_raw="(a)",
        basis_vectors=[[1, 0, 0], [0, 1, 0], [0, 0, 1]],
        origin=[0, 0, 0], k_point_label="GM", irrep_label="GM1+",
        parent_sg=229,
    )
    spec = SubgroupExportSpec(
        subgroup=subgroup, structure=parent, parent_structure=parent,
        parent_sg=229, parent_symbol="Im-3m",
        parent_wyckoff_sites=[{
            "species": "Fe", "multiplicity": 2, "wyckoff_letter": "a",
            "representative_index": 0, "equivalent_indices": [0, 1],
            "display_label": "Fe", "display_order": 0,
        }],
    )
    text = render_isoviz(spec)
    subtypes = text.split("!atomsubtypelist \n", 1)[1].split("\n\n", 1)[0].splitlines()
    coord_rows = text.split("!atomcoordlist \n", 1)[1].split("\n\n", 1)[0].splitlines()
    assert len(subtypes) == 2
    assert {int(row.split()[1]) for row in coord_rows} == {1, 2}


def test_exports_preserve_parent_cif_atom_labels_and_order():
    """The NdNiO2 source spells its sites O / ND / NI in that order."""
    from backend.utils.parent_header import parent_wyckoff_display
    from backend.input_cif import SymmetryValidator, read_cif

    path = _REPO / "experiment_data" / "NdNiO2 own.cif"
    parent = read_cif(path)
    sites = SymmetryValidator().validate(parent)["wyckoff_sites"]
    lines = parent_wyckoff_display(parent, sites, path)
    assert [line.split()[0] for line in lines] == ["O", "ND", "NI"]
    subgroup = SubgroupInfo(
        index=0, space_group_number=123, space_group_symbol="P4/mmm",
        subgroup_index=1, size=1, opd_symbol="P1", opd_dir_raw="(a)",
        basis_vectors=[[1, 0, 0], [0, 1, 0], [0, 0, 1]],
        origin=[0, 0, 0], k_point_label="GM", irrep_label="GM1+",
        parent_sg=123,
    )
    spec = SubgroupExportSpec(
        subgroup=subgroup, structure=parent, parent_structure=parent,
        parent_sg=123, parent_symbol="P4/mmm",
        parent_wyckoff_sites=sites, parent_wyckoff_lines=lines,
    )
    type_rows = render_isoviz(spec).split("!atomtypelist \n", 1)[1].split("\n\n", 1)[0]
    assert [row.split()[1] for row in type_rows.splitlines()] == ["O", "ND", "NI"]
    site_rows = render_cif(parent, spec).split("_atom_site_label", 1)[1]
    assert "O_1" in site_rows and "ND_1" in site_rows and "NI_1" in site_rows


def test_parent_header_reads_atom_sites_after_fullprof_global_block(tmp_path):
    """FullProf metadata loops must not trap atom-site discovery in an earlier block."""
    from backend.utils.parent_header import parse_cif_atom_site_rows

    path = tmp_path / "fullprof_multiblock.cif"
    path.write_text(
        """data_global
loop_
_publ_manuscript_incl_extra_item
_publ_manuscript_incl_extra_info
_publ_manuscript_incl_extra_defn
'_pd_proc_ls_prof_cR_factor' 'corrected background' no
data_structure
loop_
_atom_site_label
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
_atom_site_type_symbol
La1 1.0 1.0 0.43204 La
Ni1 0.5 0.5 0.5 Ni
""",
        encoding="utf-8",
    )

    assert parse_cif_atom_site_rows(path) == [
        {"label": "La1", "type_symbol": "La", "frac": (1.0, 1.0, 0.43204)},
        {"label": "Ni1", "type_symbol": "Ni", "frac": (0.5, 0.5, 0.5)},
    ]


def test_parent_header_fractional_distance_is_integer_image_invariant():
    from backend.utils.parent_header import _frac_dist

    assert _frac_dist([0.2, -1.8, 3.2], [2.2, 0.2, 0.2]) == pytest.approx(0.0)
    assert _frac_dist([0.0, 0.0, 0.0], [2.2, 2.2, 2.2]) == pytest.approx(0.2)


def test_pmmm_wyckoff_letters_use_target_orbits_and_fixed_abc_setting():
    """Accidental parent symmetry must not relabel Pmmm sites after an axis swap."""
    from backend.input_cif import read_cif
    from backend.input_cif.coordinate_transform import build_supercell

    parent = read_cif(_REPO / "experiment_data" / "NdNiO2 own.cif")
    basis = [[-3, 0, 0], [0, 0, 1], [0, 2, 0]]
    child = build_supercell(parent, basis)
    subgroup = SubgroupInfo(
        index=0, space_group_number=47, space_group_symbol="Pmmm",
        subgroup_index=6, size=6, opd_symbol="P1", opd_dir_raw="(a)",
        basis_vectors=basis, basis_raw="(-3,0,0),(0,0,1),(0,2,0)",
        origin=[0, 0, 0], origin_raw="(0,0,0)",
        k_point_label="Y", irrep_label="Y1",
        k_coordinates=["1/3", "1/2", "0"], parent_sg=123,
    )
    spec = SubgroupExportSpec(
        subgroup=subgroup, structure=child, parent_structure=parent,
        parent_sg=123, parent_symbol="P4/mmm",
    )

    text = render_cif(child, spec)

    # These are standard-setting Pmmm coordinates and Wyckoff symbols.  A
    # metric-driven spglib axis permutation used to emit q/r/u/v instead.
    assert re.search(r"\s1\s+a\s+0\.00000\s+0\.00000\s+0\.00000", text)
    assert re.search(r"\s2\s+i\s+0\.16667\s+0\.00000\s+0\.00000", text)
    assert re.search(r"\s2\s+q\s+0\.00000\s+0\.00000\s+0\.25000", text)
    assert re.search(r"\s4\s+w\s+0\.66667\s+0\.00000\s+0\.25000", text)
    assert re.search(r"\s4\s+x\s+0\.16667\s+0\.50000\s+0\.25000", text)


def test_method1_x4_p3_cif_matches_official_setting(tmp_path):
    """X4- P3 CIF: subgroup Cmma #67, origin-2 ASU, same atoms as official."""
    from pymatgen.core import Lattice
    from pymatgen.io.cif import CifParser

    from tests.validation.backend.paths import ITEM_DIR, TRUE_DIR

    official = TRUE_DIR / "X4- P3 CIF.cif"
    local_sc = ITEM_DIR / "X4- P3 CIF.cif"
    if not official.is_file() or not local_sc.is_file():
        pytest.skip("official/local X4- P3 CIF not present")
    sc = CifParser(str(local_sc), occupancy_tolerance=100).parse_structures(primitive=False)[0]
    ref = CifParser(str(official), occupancy_tolerance=100).parse_structures(primitive=False)[0]
    parent = Structure(
        Lattice.tetragonal(4.402, 11.163),
        ["Eu", "Eu", "Al", "Al", "Al", "Al", "Al", "Al", "Al", "Al"],
        [
            [0, 0, 0], [0.5, 0.5, 0.5],
            [0, 0.5, 0.25], [0.5, 0, 0.25], [0.5, 0, 0.75], [0, 0.5, 0.75],
            [0, 0, 0.38], [0, 0, 0.62], [0.5, 0.5, 0.12], [0.5, 0.5, 0.88],
        ],
    )
    parent_wyckoff = [
        {"species": "Eu", "multiplicity": 2, "wyckoff_letter": "a",
         "representative_index": 0, "equivalent_indices": [0, 1]},
        {"species": "Al", "multiplicity": 4, "wyckoff_letter": "d",
         "representative_index": 2, "equivalent_indices": [2, 3, 4, 5]},
        {"species": "Al", "multiplicity": 4, "wyckoff_letter": "e",
         "representative_index": 6, "equivalent_indices": [6, 7, 8, 9]},
    ]
    sg = SubgroupInfo(
        index=0,
        space_group_number=67,
        space_group_symbol="Cmma",
        subgroup_index=4,
        size=2,
        opd_symbol="P3",
        opd_dir_raw="(a;0)",
        basis_vectors=[[0, 0, 1], [1, -1, 0], [1, 1, 0]],
        basis_raw="(0,0,1),(1,-1,0),(1,1,0)",
        origin=[0.0, 0.5, 0.5],
        origin_raw="(0,1/2,1/2)",
        k_point_label="X",
        irrep_label="X4-",
        k_coordinates=["1/2", "1/2", "0"],
        parent_sg=139,
    )
    spec = SubgroupExportSpec(
        subgroup=sg,
        structure=sc,
        parent_structure=parent,
        parent_sg=139,
        parent_symbol="I4/mmm",
        folder_name="X4- P3",
        parent_wyckoff_sites=parent_wyckoff,
    )
    text = render_cif(sc, spec)
    assert "data_isodistort-output" in text
    assert "_symmetry_Int_Tables_number 67" in text
    assert "C 2/m 2/m 2/a" in text
    assert "067:-C 2a 2" in text
    assert "_iso_parent-to-child.transform_Pp_abc" in text
    assert "c,a-b,a+b" in text
    assert re.search(r"Eu1_1\s+Eu\s+4\s+g\s+0\.00000\s+0\.25000\s+0\.25000", text)
    assert re.search(r"Al1_1\s+Al\s+4\s+a\s+0\.25000\s+0\.00000\s+0\.00000", text)
    assert re.search(r"Al1_2\s+Al\s+4\s+b\s+0\.25000\s+0\.00000\s+0\.50000", text)
    assert re.search(r"Al2_1\s+Al\s+8\s+n\s+0\.38000\s+0\.25000\s+0\.25000", text)
    assert "0,0,Dz" in text
    assert "Dx,0,Dz" in text
    assert "# Eu1 2a (0,0,0)" in text
    assert "# Al1 4d (0,1/2,1/4)" in text
    assert "# Al2 4e (0,0,z), z= 0.38000" in text
    tmp_cif = tmp_path / "x4_p3.cif"
    tmp_cif.write_text(text, encoding="utf-8")
    got = CifParser(str(tmp_cif), occupancy_tolerance=100).parse_structures(primitive=False)[0]
    assert len(got) == len(ref) == 20
    assert abs(got.lattice.a - ref.lattice.a) < 1e-4
    assert abs(got.lattice.b - ref.lattice.b) < 1e-4

    def _match(first, second, tol=1e-4) -> bool:
        used: set[int] = set()
        for site in first:
            found = False
            for j, other in enumerate(second):
                if j in used or site.species_string != other.species_string:
                    continue
                delta = np.abs(site.frac_coords - other.frac_coords)
                delta = np.minimum(delta, 1.0 - delta)
                if np.all(delta < tol):
                    used.add(j)
                    found = True
                    break
            if not found:
                return False
        return True

    assert _match(got, ref)
