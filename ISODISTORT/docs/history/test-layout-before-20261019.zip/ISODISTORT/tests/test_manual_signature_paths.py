"""Guard manual provenance signatures against the retired package layout."""

from __future__ import annotations

from pathlib import Path
import importlib
import json
from types import SimpleNamespace

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[1]
MANUAL_ROOT = PROJECT_ROOT / "tests" / "manual"


def test_manual_signature_targets_exist_in_the_three_layer_layout() -> None:
    expected = (
        PROJECT_ROOT / "application" / "session" / "core_api.py",
        PROJECT_ROOT / "backend" / "wrappers" / "iso_wrapper.py",
        PROJECT_ROOT / "backend" / "wrappers" / "smodes_wrapper.py",
        PROJECT_ROOT / "backend" / "input_cif" / "__init__.py",
        PROJECT_ROOT / "backend" / "input_cif" / "cif_io.py",
        PROJECT_ROOT / "backend" / "utils" / "affine_embeddings.py",
        PROJECT_ROOT / "backend" / "method1" / "search.py",
        PROJECT_ROOT / "backend" / "method2" / "search.py",
        PROJECT_ROOT / "backend" / "method3" / "search.py",
        PROJECT_ROOT / "backend" / "utils" / "k_lattice.py",
        PROJECT_ROOT / "backend" / "models" / "phase_path.py",
        PROJECT_ROOT / "backend" / "tables" / "spacegroup_meta.py",
        PROJECT_ROOT / "backend" / "method2" / "distortion_mapper.py",
        PROJECT_ROOT / "backend" / "method2" / "superspace.py",
        PROJECT_ROOT / "backend" / "method3" / "inverse_landau.py",
        PROJECT_ROOT / "backend" / "method3" / "inverse_landau_adapter.py",
        PROJECT_ROOT / "backend" / "method4" / "distortion_engine.py",
        PROJECT_ROOT / "backend" / "method4" / "decomposition.py",
        PROJECT_ROOT / "backend" / "method4" / "strain.py",
        PROJECT_ROOT / "backend" / "export" / "isodistort_cif.py",
        MANUAL_ROOT / "official_html_resolver.py",
        MANUAL_ROOT / "validate_method_outputs.py",
    )

    missing = [str(path) for path in expected if not path.is_file()]
    assert not missing, f"manual signature targets are missing: {missing}"


def test_manual_audits_do_not_sign_retired_package_paths() -> None:
    retired_fragments = (
        '/ "backend" / "distortion" /',
        '/ "backend" / "backend" /',
        '/ "backend" / "structure" /',
        '/ "backend" / "io" /',
        "ISODISTORT/isocore/",
        "ISODISTORT/tests_dev/",
    )
    offenders: list[str] = []
    for path in sorted(MANUAL_ROOT.glob("*.py")):
        source = path.read_text(encoding="utf-8-sig")
        for fragment in retired_fragments:
            if fragment in source:
                offenders.append(f"{path.name}: {fragment}")

    assert not offenders, "retired manual signature paths remain: " + "; ".join(offenders)


def test_comparison_signatures_cover_the_relocated_scientific_implementation():
    from tests.validation.backend.provenance import validation_source_paths

    paths = validation_source_paths(PROJECT_ROOT)
    assert "cif-validator:application/single/service.py" in paths
    assert "cif-validator:backend/cif/service.py" in paths
    assert "cif-validator:backend/comparison/service.py" in paths
    assert "cif-validator:backend/results/__init__.py" in paths
    assert "cif-validator:backend/provenance/service.py" in paths
    assert all(path.is_file() for path in paths.values())
    assert not any(path.name == "compare_cif.py" for path in paths.values())


def test_numeric_audit_inventory_includes_shared_verification_policy_and_snapshot():
    from tests.manual.audit_method12_numeric_semantics import _file_inventory

    paths = set(_file_inventory(PROJECT_ROOT / "output", []))
    assert PROJECT_ROOT / "tests/validation/backend/results/model.py" in paths
    assert PROJECT_ROOT / "tests/validation/backend/provenance/service.py" in paths


def _preparer_fixture(tmp_path, monkeypatch, name):
    """Sign a disposable copy of actual production sources, without executing it."""
    module = importlib.import_module(f"tests.manual.{name}")
    root = tmp_path / "ISODISTORT"
    for layer in ("backend", "application"):
        for source in (PROJECT_ROOT / layer).rglob("*.py"):
            target = root / source.relative_to(PROJECT_ROOT)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
    script = root / "tests/manual" / f"{name}.py"
    script.parent.mkdir(parents=True)
    script.write_bytes(Path(module.__file__).read_bytes())
    config = root / "resources/config/settings.yaml"
    config.parent.mkdir(parents=True)
    config.write_bytes((PROJECT_ROOT / "resources/config/settings.yaml").read_bytes())
    inputs = tmp_path / "experiment_data"
    inputs.mkdir()
    for parent in ("EuAl4 Parent.cif", "NdNiO2 own.cif"):
        (inputs / parent).write_text("independent signature test input\n", encoding="utf-8")
    monkeypatch.setattr(module, "__file__", str(script))
    monkeypatch.setattr(module, "PACKAGE_ROOT", root)
    monkeypatch.setattr(module, "WORKSPACE", tmp_path)
    return module, root


@pytest.mark.parametrize("name", ["prepare_method3_manifest", "prepare_method4_inputs"])
@pytest.mark.parametrize("relative", [
    "backend/utils/affine_embeddings.py", "backend/wrappers/base_wrapper.py",
    "application/session/publication.py", "backend/export/child_frame.py",
    "backend/models/phase_path.py", "backend/utils/k_lattice.py",
    "resources/config/settings.yaml",
])
def test_preparer_signatures_change_with_migrated_implementations(tmp_path, monkeypatch, name, relative):
    module, root = _preparer_fixture(tmp_path, monkeypatch, name)
    before = module._signature()
    target = root / relative
    target.write_bytes(target.read_bytes() + b"\n# changed implementation\n")
    assert module._signature() != before


def test_method3_changed_affine_implementation_invalidates_pass_checkpoint(tmp_path, monkeypatch):
    module, root = _preparer_fixture(tmp_path, monkeypatch, "prepare_method3_manifest")
    checkpoint = tmp_path / "checkpoint.json"
    checkpoint.write_text(json.dumps({
        "signature": module._signature(), "results": {"case": {"status": "pass"}},
    }), encoding="utf-8")
    target = root / "backend/utils/affine_embeddings.py"
    target.write_bytes(target.read_bytes() + b"\n# changed affine calculation\n")
    calls = []
    subgroup = SimpleNamespace(
        irrep_label="GM1", opd_symbol="P1", space_group_number=1,
        space_group_symbol="P1", basis_vectors=[[1, 0, 0], [0, 1, 0], [0, 0, 1]],
        origin=[0, 0, 0], official_fields=lambda: {"k_active": "GM"},
    )

    def search(**_kwargs):
        calls.append("searched")
        return [SimpleNamespace(subgroup=subgroup)]

    monkeypatch.setattr(module, "IsoDistort", lambda: SimpleNamespace(
        load_structure=lambda _path: None, search_method_3=search,
    ))
    monkeypatch.setattr(module, "CHECKPOINT_PATH", checkpoint)
    monkeypatch.setattr(module, "MANIFEST_PATH", tmp_path / "manifest.json")
    monkeypatch.setattr(module, "CASES", {"EuAl4 Parent.cif": [{
        "id": "case", "expected_candidate": {"irrep": "GM1", "opd": "P1", "sg": 1},
        "distortion_types": ["displacive"], "space_group_type": 1,
        "supercell_basis": subgroup.basis_vectors, "direct_sublattice_centering": "P",
        "lattice_type": "direct", "category": "identity",
    }]})
    assert module._run_preflight({"signature": module._signature()}) == 0
    assert calls == ["searched"]


def test_method4_changed_affine_implementation_refuses_old_frozen_input_batch(tmp_path, monkeypatch):
    module, root = _preparer_fixture(tmp_path, monkeypatch, "prepare_method4_inputs")
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({"signature": module._signature(), "parents": {}}), encoding="utf-8")
    before = manifest.read_bytes()
    target = root / "backend/utils/affine_embeddings.py"
    target.write_bytes(target.read_bytes() + b"\n# changed affine calculation\n")
    monkeypatch.setattr(module, "MANIFEST_PATH", manifest)
    monkeypatch.setattr(module, "PARENTS", {})
    monkeypatch.setattr("sys.argv", ["prepare_method4_inputs"])
    with pytest.raises(RuntimeError, match="different source signature"):
        module.main()
    assert manifest.read_bytes() == before
