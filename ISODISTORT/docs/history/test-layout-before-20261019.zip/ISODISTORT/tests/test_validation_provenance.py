"""Content and source-drift contracts, independent of live ISO or official outputs."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.validation.backend.provenance import (
    FileSnapshot,
    build_provenance_state,
    changed_provenance_surfaces,
    production_source_paths,
    validation_source_paths,
    write_json_atomic,
)


def _write(path: Path, content: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def _fixture(tmp_path: Path):
    root = tmp_path / "ISODISTORT"
    config = _write(root / "resources/config/settings.yaml", json.dumps({
        "isobyu": {"bin_dir": "../../runtime", "data_dir": "../../runtime"},
    }))
    _write(root / "backend/method3/solver.py", "algorithm = 1\n")
    _write(root / "application/session/service.py", "contract = 1\n")
    _write(root / "pyproject.toml", "[project]\nname='fixture'\n")
    _write(root / "requirements.txt", "numpy\n")
    _write(root / "runtime/iso", "independent-program-v1")
    _write(root / "runtime/data_isotropy.txt", "generic-data-v1")
    source = _write(tmp_path / "input/parent.cif", "independent-input-v1")

    def state(**kwargs):
        return build_provenance_state(
            schema=1, kind="fixture-validation", workspace=tmp_path, package_root=root,
            inputs=[("parent", source)], metadata={"selection": "case"}, **kwargs,
        )

    return root, config, source, state


@pytest.mark.parametrize("relative", [
    "backend/method3/solver.py", "application/session/service.py", "requirements.txt",
    "resources/config/settings.yaml", "runtime/iso", "runtime/data_isotropy.txt",
])
def test_common_provenance_detects_all_executable_input_surfaces(tmp_path, relative):
    root, _config, _source, state = _fixture(tmp_path)
    before = state()
    target = root / relative
    target.write_text(target.read_text(encoding="utf-8") + "\n", encoding="utf-8")
    after = state()
    assert before["signature"] != after["signature"]
    assert changed_provenance_surfaces(before, after)


def test_common_provenance_ignores_outputs_but_tracks_new_code_and_runtime(tmp_path, monkeypatch):
    root, _config, _source, state = _fixture(tmp_path)
    original = state()
    _write(root / "output/cache/result.json", "generated")
    _write(root / "backend/method3/__pycache__/solver.pyc", "cache")
    assert state()["signature"] == original["signature"]
    _write(root / "backend/method3/new_solver.py", "algorithm = 2")
    added = state()
    assert added["signature"] != original["signature"]
    monkeypatch.setattr("tests.validation.backend.provenance.service.importlib.metadata.version", lambda _name: "fixture-v2")
    assert "runtime" in changed_provenance_surfaces(added, state())


def test_provenance_signs_the_same_captured_inputs_used_for_parsing(tmp_path):
    _root, _config, source, state = _fixture(tmp_path)
    captured = FileSnapshot.capture(source)
    source.write_text("changed after parsing", encoding="utf-8")
    frozen = state(captured_inputs=[captured])
    record = next(row for row in frozen["inputs"] if row["label"] == "parent")
    assert record["sha256"] == captured.sha256
    assert record["bytes"] == len(captured.content)
    assert "parent" in changed_provenance_surfaces(frozen, state())


def test_registry_tracks_new_comparison_modules_without_a_hardcoded_file_list(tmp_path):
    root = tmp_path / "ISODISTORT"
    first = _write(root / "tests/validation/backend/cif/service.py", "parser = 1")
    assert set(validation_source_paths(root).values()) == {first}
    second = _write(root / "tests/validation/backend/provenance/service.py", "signer = 1")
    _write(root / "tests/validation/backend/provenance/__pycache__/service.pyc", "cache")
    assert set(validation_source_paths(root).values()) == {first, second}


def test_common_provenance_consumes_the_shared_production_registry(tmp_path, monkeypatch):
    from tests.validation.backend.provenance import service

    root, _config, _source, state = _fixture(tmp_path)
    expected = production_source_paths(root)
    first = state()
    actual = {row["label"] for row in first["inputs"] if row["label"].startswith("production:")}
    assert actual == set(expected)
    added = _write(root / "application/session/publication.py", "publication = 1")
    assert added in production_source_paths(root).values()
    after_add = state()
    assert "production:application/session/publication.py" in changed_provenance_surfaces(first, after_add)
    added.unlink()
    assert state()["signature"] == first["signature"]
    monkeypatch.setattr(service, "production_source_paths", lambda _root: {})
    assert not any(row["label"].startswith("production:") for row in state()["inputs"])


def test_atomic_report_failure_preserves_previous_content_and_removes_temporary(tmp_path, monkeypatch):
    path = _write(tmp_path / "report.json", '{"complete": true}\n')
    before = path.read_bytes()
    with pytest.raises(TypeError):
        write_json_atomic(path, {"unsupported": object()})
    assert path.read_bytes() == before

    def fail_publish(_source, _target):
        raise OSError("simulated publication failure")

    monkeypatch.setattr("tests.validation.backend.provenance.service.os.replace", fail_publish)
    with pytest.raises(OSError, match="publication failure"):
        write_json_atomic(path, {"complete": False})
    assert path.read_bytes() == before
    assert sorted(item.name for item in tmp_path.iterdir()) == ["report.json"]


def test_method3_uses_shared_provenance_for_config_and_iso_inputs(tmp_path, monkeypatch):
    from tests.manual import audit_method3_basis_metamorphism as audit

    root, config, _source, _state = _fixture(tmp_path)
    parent = _write(tmp_path / "experiment_data/parent.cif", "parent-input")
    manifest = {"parents": [{"parent_cif": parent.name, "cases": []}]}
    manifest_path = _write(tmp_path / "manifest.json", json.dumps(manifest))
    snapshot = FileSnapshot.capture(manifest_path)
    monkeypatch.setattr(audit, "PACKAGE_ROOT", root)
    monkeypatch.setattr(audit, "WORKSPACE", tmp_path)
    before = audit._provenance_state(manifest, snapshot)
    config.write_text(config.read_text(encoding="utf-8") + "\n", encoding="utf-8")
    after = audit._provenance_state(manifest, snapshot)
    assert "runtime-config" in changed_provenance_surfaces(before, after)
    _write(root / "runtime/iso", "new-independent-program")
    assert "backend:iso-binary" in changed_provenance_surfaces(after, audit._provenance_state(manifest, snapshot))


@pytest.mark.parametrize("manifest", [
    {"status": "unfrozen_pending_independent_inputs", "parents": []},
    {"status": "frozen", "parents": []},
])
def test_method3_rejects_unfrozen_or_empty_scope_before_execution(tmp_path, monkeypatch, manifest):
    from tests.manual import audit_method3_basis_metamorphism as audit

    path = _write(tmp_path / "manifest.json", json.dumps(manifest))
    monkeypatch.setattr("sys.argv", ["audit", "--manifest", str(path)])
    with pytest.raises(SystemExit) as failure:
        audit.main()
    assert failure.value.code == 2


@pytest.mark.parametrize("update_manifest", [False, True])
def test_method4_manifest_replacement_after_parse_cannot_receive_new_signature(tmp_path, monkeypatch, update_manifest):
    from tests.manual import validate_method4_local as audit
    from tests.manual.method4_provenance import build_method4_provenance_state

    root, _config, _source, _state = _fixture(tmp_path)
    manifest_path = _write(tmp_path / "manifest.json", json.dumps({
        "signature": "parsed-input", "parents": {}, "local_validation_tolerances": {},
    }))
    report_path = tmp_path / "report.json"
    original_read_text, original_read_bytes = Path.read_text, Path.read_bytes
    replaced = False

    def replace_after_read(path, value):
        nonlocal replaced
        if path.resolve() == manifest_path.resolve() and not replaced:
            replaced = True
            path.write_text(json.dumps({
                "signature": "replacement-input", "parents": {}, "local_validation_tolerances": {},
            }), encoding="utf-8")
        return value

    monkeypatch.setattr(Path, "read_text", lambda path, *a, **kw: replace_after_read(path, original_read_text(path, *a, **kw)))
    monkeypatch.setattr(Path, "read_bytes", lambda path: replace_after_read(path, original_read_bytes(path)))
    monkeypatch.setattr(audit, "build_method4_provenance_state", lambda source, selection: build_method4_provenance_state(
        source, selection, workspace=tmp_path, package_root=root,
    ))
    monkeypatch.setattr(audit, "WORKSPACE", tmp_path)
    monkeypatch.setattr("sys.argv", ["audit", "--manifest", str(manifest_path), "--json-output", str(report_path)]
                        + (["--update-manifest-status"] if update_manifest else []))
    assert audit.main() == 1
    report = json.loads(original_read_text(report_path, encoding="utf-8"))
    assert report["provenance_failure_count"] == 1
    assert "input-manifest" in report["provenance"]["changed_surfaces_during_run"]
    assert json.loads(original_read_text(manifest_path, encoding="utf-8"))["signature"] == "replacement-input"
    assert report["provenance"]["manifest_self_update"]["performed"] is False


@pytest.mark.parametrize("stage", ["a", "b"])
def test_stage_signatures_use_the_consumed_json_snapshots_after_disk_replacement(tmp_path, stage):
    from tests.manual import audit_method3_stage_a_diagnostics as stage_a
    from tests.manual import audit_method3_stage_b_feasibility as stage_b

    manifest = _write(tmp_path / "manifest.json", '{"parents": []}')
    route = _write(tmp_path / "routes.json", '{"cases": ["consumed"]}')
    previous = _write(tmp_path / "stage-a.json", '{"cases": ["consumed"]}')
    captured = tuple(FileSnapshot.capture(path) for path in (manifest, route, previous))
    for path in (manifest, route, previous):
        path.write_text('{"parents": [], "cases": ["replacement"]}', encoding="utf-8")
    if stage == "a":
        state = stage_a._signature_state(
            manifest, route, tmp_path, manifest=json.loads(captured[0].text),
            runtime_versions={}, tolerances={}, captured_inputs=captured,
        )
        expected_labels = ("manifest", "official-route-audit")
    else:
        state = stage_b._signature_state(
            manifest_path=manifest, route_report_path=route, stage_a_report_path=previous,
            input_root=tmp_path, package_root=stage_b.PACKAGE_ROOT, tool_path=Path(stage_b.__file__),
            runtime_versions={}, tolerances={}, max_quotient_order=1, case_ids=None,
            captured_inputs=captured,
        )
        expected_labels = ("manifest", "official-route-report", "stage-a-all-report")
        assert stage_b._load_json(captured[1], "route")["cases"] == ["consumed"]
    records = {row["label"]: row for row in state["inputs"]}
    for label, snapshot in zip(expected_labels, captured):
        assert records[label]["sha256"] == snapshot.sha256
        assert records[label]["sha256"] != FileSnapshot.capture(snapshot.path).sha256


def test_method4_official_gate_rejects_a_parsed_manifest_signed_from_replacement_bytes(tmp_path, monkeypatch):
    from tests.manual import audit_method4_official as audit
    from tests.manual.method4_provenance import build_method4_provenance_state

    root, _config, _source, _state = _fixture(tmp_path)
    path = _write(tmp_path / "manifest.json", '{"parents": {}, "signature": "consumed"}')
    snapshot = FileSnapshot.capture(path)
    path.write_text('{"parents": {}, "signature": "replacement"}', encoding="utf-8")
    observed = []

    def sign(source, selection):
        observed.append(source)
        return build_method4_provenance_state(source, selection, workspace=tmp_path, package_root=root)

    monkeypatch.setattr(audit, "build_method4_provenance_state", sign)
    result = audit._local_report_provenance_gate({}, json.loads(snapshot.text), path)
    assert "parsed manifest does not match the captured signed content" in result["issues"]
    result = audit._local_report_provenance_gate({}, json.loads(snapshot.text), snapshot)
    assert "parsed manifest does not match the captured signed content" not in result["issues"]
    assert observed[-1] is snapshot
