"""Robustness (invalid inputs) and reproducibility."""
from __future__ import annotations

import importlib
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
from data_dir import experiment_data_dir
from pymatgen.core import Lattice, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

from application.session import IsoDistort
from backend.wrappers import BushMode, DistortionMode, SubgroupInfo
from backend.export import StructureExporter
from backend.input_cif import read_cif
from backend.method4 import DistortionEngine

DATA_DIR = experiment_data_dir()
CIFS_DIR = Path(__file__).resolve().parent / "cifs_30"


# --- from test_robustness.py ---

def test_negative_amplitude_is_allowed():
    """负振幅：位移方向翻转，不崩溃（合法数学输入）。"""
    struct = Structure(Lattice.cubic(5.0), ["A", "B"],
                       [[0, 0, 0], [0.5, 0.5, 0.5]])
    disp = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, 0.0]])
    engine = DistortionEngine()
    d = engine.generate_single_mode(struct, disp, amplitude=-0.1)
    assert len(d) == 2
    # 原子 0 沿 -x 位移（≠ 原坐标）
    assert abs(d[0].frac_coords[0]) > 1e-6


def test_wrong_sized_displacements_raise():
    """位移向量与原子数不一致必须报错，不能静默。"""
    struct = Structure(Lattice.cubic(5.0), ["A", "B"],
                       [[0, 0, 0], [0.5, 0.5, 0.5]])
    engine = DistortionEngine()
    with pytest.raises(ValueError):
        engine.generate_single_mode(struct, np.zeros((3, 3)), amplitude=0.1)


def test_invalid_basis_matrix_raises():
    """非法基矢（非 3x3）必须报错。"""
    struct = Structure(Lattice.cubic(5.0), ["A"], [[0, 0, 0]])
    engine = DistortionEngine()
    with pytest.raises(ValueError):
        engine.generate_single_mode(struct, np.zeros((1, 3)),
                                    amplitude=0.1, supercell=[[1, 0], [0, 1]])


def test_corrupt_cif_raises_clear_error(tmp_path):
    """损坏的 CIF 必须给出清晰错误而非崩溃。"""
    bad = tmp_path / "bad.cif"
    bad.write_text("this is not a cif file at all\n", encoding="utf-8")
    with pytest.raises(ValueError):
        read_cif(str(bad))


def test_occupancy_is_not_silently_clamped():
    """A missing scalar mode model cannot be repaired by clipping amplitudes."""
    parent = Structure(Lattice.cubic(4), [{"Al": 0.6}], [[0, 0, 0]])
    with pytest.raises(NotImplementedError, match="occupational"):
        DistortionEngine().generate_modes(
            parent, occupancy_patterns=[(np.array([-1.0]), 5.0)],
        )
    assert parent[0].species["Al"] == 0.6


# --- from test_robustness_extended.py ---

def test_read_cif_missing_file_raises(tmp_path):
    with pytest.raises(OSError):
        read_cif(str(tmp_path / "nope.cif"))


def test_read_cif_empty_file_raises(tmp_path):
    bad = tmp_path / "empty.cif"
    bad.write_text("", encoding="utf-8")
    with pytest.raises((ValueError, KeyError, IndexError)):
        read_cif(str(bad))


def test_read_cif_garbage_raises(tmp_path):
    bad = tmp_path / "garbage.cif"
    bad.write_text("not a cif at all\n" * 10, encoding="utf-8")
    with pytest.raises((ValueError, KeyError, IndexError)):
        read_cif(str(bad))


def test_negative_amplitude_at_api_level(tmp_path):
    """API 层负振幅：数学上合法（位移方向翻转），不崩溃。"""
    cif = CIFS_DIR / "sg001.cif"
    if not cif.exists():
        pytest.skip("测试 CIF 不存在")
    iso = IsoDistort()
    iso.set_distortion_scope({
        "displacive": ["*"], "occupational": [], "strain": [],
        "magnetic": [], "rotational": [],
    })
    iso.load_structure(cif)
    subs = iso.list_subgroups_at("GM", "GM1")
    found = False
    for sg in subs:
        try:
            iso.search_method_2(subgroup_idx=sg.index,
                                distortion_type=["displacive"])
        except Exception:  # noqa: BLE001,S112 - 无模式子群跳过
            continue
        if iso.mode_displacements:
            label = next(iter(iso.mode_displacements))
            d = iso.generate_distortion(irrep_label=label, amplitude=-0.1)
            assert len(d) == len(iso.structure)
            found = True
            break
    if not found:
        pytest.skip("该母相无可计算位移模式")


def test_extreme_amplitude_no_crash():
    """极大振幅（1e6）：数值上允许，但必须不崩溃、不产生 NaN。"""
    struct = Structure(Lattice.cubic(5.0), ["Fe", "Fe"],
                       [[0, 0, 0], [0.5, 0.5, 0.5]])
    disp = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, 0.0]])
    d = DistortionEngine().generate_single_mode(struct, disp, amplitude=1e6)
    assert np.all(np.isfinite(d.frac_coords))
    assert len(d) == 2


def test_tiny_amplitude_returns_parent_within_tolerance():
    """极小振幅（1e-12）：位移在容差内，结构 ≈ 母相。"""
    struct = Structure(Lattice.cubic(5.0), ["Fe", "Fe"],
                       [[0, 0, 0], [0.5, 0.5, 0.5]])
    disp = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, 0.0]])
    d = DistortionEngine().generate_single_mode(struct, disp, amplitude=1e-12)
    diff = d.frac_coords - struct.frac_coords
    diff -= np.round(diff)
    assert np.max(np.abs(diff)) < 1e-6


def test_huge_supercell_atom_count():
    """超大超胞 (10,10,10)：原子数精确 = 1000×。"""
    struct = Structure(Lattice.cubic(3.0), ["Fe"], [[0, 0, 0]])
    d = DistortionEngine().generate_single_mode(
        struct, np.zeros((1, 3)), amplitude=0.0, supercell=[10, 10, 10]
    )
    assert len(d) == 1000


def test_many_atoms_structure_no_crash():
    """原子数极多的结构（200 原子）：引擎不崩溃。"""
    coords = []
    for i in range(200):
        coords.append([(i % 10) / 10.0, ((i // 10) % 10) / 10.0,
                       (i // 100) / 2.0])
    struct = Structure(Lattice.cubic(20.0), ["Fe"] * 200, coords)
    disp = np.tile([1.0, 0.0, 0.0], (200, 1))
    d = DistortionEngine().generate_single_mode(struct, disp, amplitude=0.1)
    assert len(d) == 200
    assert np.all(np.isfinite(d.frac_coords))


def test_nan_displacement_rejected():
    """含 NaN 的位移向量必须报错（不能静默产生非法结构）。"""
    struct = Structure(Lattice.cubic(5.0), ["Fe"], [[0, 0, 0]])
    disp = np.array([[np.nan, 0.0, 0.0]])
    with pytest.raises((ValueError, FloatingPointError)):
        DistortionEngine().generate_single_mode(struct, disp, amplitude=0.1)


def test_zero_length_displacement_ok():
    """全零位移 + 非零振幅 = 母相（合法，不报错）。"""
    struct = Structure(Lattice.cubic(5.0), ["Fe"], [[0, 0, 0]])
    d = DistortionEngine().generate_single_mode(
        struct, np.zeros((1, 3)), amplitude=0.5
    )
    diff = d.frac_coords - struct.frac_coords
    diff -= np.round(diff)
    assert np.max(np.abs(diff)) < 1e-9


# ------------------------------------------------------------------
# 第三层 §3：可重复性（确定性群论计算，结果必须逐次一致）
# ------------------------------------------------------------------

def test_engine_deterministic_repeat():
    """同一输入两次生成：逐字节一致（确定性）。"""
    struct = Structure(Lattice.cubic(4.0), ["Fe", "O"],
                       [[0, 0, 0], [0.5, 0.5, 0.5]])
    disp = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]])
    engine = DistortionEngine()
    d1 = engine.generate_single_mode(struct, disp, amplitude=0.1)
    d2 = engine.generate_single_mode(struct, disp, amplitude=0.1)
    assert d1.frac_coords.shape == d2.frac_coords.shape
    assert np.allclose(d1.frac_coords, d2.frac_coords, atol=1e-12)
    # 导出 CIF 逐字节一致
    out1 = StructureExporter().to_cif(d1, "rep_test_1")
    out2 = StructureExporter().to_cif(d2, "rep_test_2")
    assert out1.read_bytes() == out2.read_bytes(), \
        "同一输入两次导出的 CIF 必须逐字节一致"


def test_read_cif_roundtrip_stable(tmp_path):
    """CIF 读回两次：识别空间群一致（可重复性）。"""
    cif = CIFS_DIR / "sg123.cif"
    if not cif.exists():
        pytest.skip("测试 CIF 不存在")
    s1 = read_cif(str(cif))
    s2 = read_cif(str(cif))
    g1 = SpacegroupAnalyzer(s1, symprec=1e-3).get_space_group_number()
    g2 = SpacegroupAnalyzer(s2, symprec=1e-3).get_space_group_number()
    assert g1 == g2 == 123
    assert np.allclose(s1.frac_coords, s2.frac_coords, atol=1e-12)


def test_method1_options_repeatable(tmp_path):
    """API 层 method1_options 两次调用：选项列表一致（可重复性）。"""
    cif = CIFS_DIR / "sg139.cif"
    if not cif.exists():
        cif = DATA_DIR / "EuAl4 Parent.cif"
    if not cif.exists():
        pytest.skip("无可用母相 CIF")
    iso = IsoDistort()
    iso.set_distortion_scope({
        "displacive": ["*"], "occupational": [], "strain": [],
        "magnetic": [], "rotational": [],
    })
    iso.load_structure(cif)
    o1 = iso.method1_options()
    o2 = iso.method1_options()
    assert [g["number"] for g in o1["space_groups"]] == \
        [g["number"] for g in o2["space_groups"]]
    assert [g["label"] for g in o1["conventional_lattices"]] == \
        [g["label"] for g in o2["conventional_lattices"]]


def _candidate(*, index: int, irrep: str) -> SubgroupInfo:
    return SubgroupInfo(
        index=index,
        space_group_number=12,
        subgroup_index=2,
        space_group_symbol="C2/m",
        k_point_label="GM",
        irrep_label=irrep,
        opd_symbol="P1",
        basis_vectors=[[1, 0, 0], [0, 1, 0], [0, 0, 1]],
    )


def test_method2_explicit_candidates_do_not_replace_other_result_pool():
    """Method tables may reuse indices; the explicit pool must select the target."""
    wrong = _candidate(index=0, irrep="GM1+")
    target = _candidate(index=0, irrep="GM2+")
    seen: dict = {}

    class Search:
        def search(self, parent_sg, candidates, query, wyckoff_letters,
                            **kwargs):
            seen["candidates"] = candidates
            return SimpleNamespace(
                subgroup=candidates[0], modes=[], metadata={},
            )

    class Mapper:
        @staticmethod
        def map_modes_to_atoms(structure, wyckoff_sites, modes):
            return {}

    iso = object.__new__(IsoDistort)
    iso.structure = Structure(Lattice.cubic(1.0), ["H"], [[0.0, 0.0, 0.0]])
    iso.symmetry_info = {"space_group_number": 139, "wyckoff_sites": []}
    iso.subgroups = [wrong]
    iso._selected_subgroup = None
    iso._method2 = Search()
    iso._dist_mapper = Mapper()
    iso._iso = SimpleNamespace(list_k_points=lambda *_a, **_k: [])
    iso._smodes = None
    iso._letters_for_species = lambda species: []
    iso._union_scope_species = lambda types, **_kwargs: set()
    iso._resolve_k_vector = lambda *a, **k: [0.0, 0.0, 0.0]
    iso._compute_scoped_modes = lambda *args, **kwargs: []
    iso.mode_occupancies = {}
    iso.mode_displacements_sc = {}
    iso._mode_label_overrides = {}
    iso.number_of_independent_modulations = 0

    result = iso.search_method_2(0, candidates=[target])

    assert seen["candidates"] == [target]
    assert result.subgroup is target
    assert iso._selected_subgroup is target
    assert iso.subgroups == [wrong]


def test_export_current_modes_require_full_subgroup_identity():
    """Equal display indices from different Method tables must not share modes."""
    selected = _candidate(index=0, irrep="GM1+")
    other = _candidate(index=0, irrep="GM2+")
    iso = object.__new__(IsoDistort)
    iso._selected_subgroup = selected
    iso.phase_path = SimpleNamespace(subgroup_index=0)
    iso.distortion_modes = []
    iso.mode_displacements = {"GM1+": {}}
    iso.mode_occupancies = {}
    iso.mode_displacements_sc = {}
    iso._mode_label_overrides = {}
    iso.distorted_structure = None
    iso._spec_for_subgroup = lambda subgroup, **kwargs: SimpleNamespace(
        subgroup=subgroup, **kwargs
    )

    specs = iso._collect_export_specs([other], ["modes"], False)

    assert specs[0].use_current_modes is False
    assert specs[0].use_generated_structure is False


def test_export_current_cache_uses_exact_embedding_identity():
    """Embeddings that differ below display precision must not share cached modes."""

    selected = _candidate(index=0, irrep="GM1+")
    other = _candidate(index=0, irrep="GM1+")
    other.basis_vectors[0][0] = "1.00000000001"
    iso = object.__new__(IsoDistort)
    iso._selected_subgroup = selected
    iso.phase_path = SimpleNamespace(subgroup_index=0)
    iso.distortion_modes = []
    iso.mode_displacements = {"cached": {}}
    iso.mode_occupancies = {}
    iso.mode_displacements_sc = {}
    iso._mode_label_overrides = {}
    iso.distorted_structure = None
    iso.number_of_independent_modulations = 0
    iso._spec_for_subgroup = lambda subgroup, **kwargs: SimpleNamespace(
        subgroup=subgroup, **kwargs
    )

    specs = iso._collect_export_specs([other], ["modes"], False)

    assert specs[0].use_current_modes is False
    assert specs[0].use_generated_structure is False


def test_same_affine_embedding_different_routes_never_share_mode_or_final_cache():
    selected = _candidate(index=0, irrep="GM1+")
    selected.method3_embedding_id = "same-affine-subgroup"
    selected.k_coordinates = ["0", "0", "0"]
    selected.opd_dir_raw = "(a)"
    selected.opd_vector = [1]

    changed_irrep = deepcopy(selected)
    changed_irrep.irrep_label = "GM2+"
    changed_opd = deepcopy(selected)
    changed_opd.opd_symbol = "P2"
    changed_opd.opd_dir_raw = "(a,b)"
    changed_opd.opd_vector = [1, 1]
    changed_k = deepcopy(selected)
    changed_k.k_point_label = "X"
    changed_k.k_coordinates = ["1/2", "0", "0"]

    selected_key = IsoDistort._method3_embedding_guard_key(selected)
    assert all(
        IsoDistort._method3_embedding_guard_key(candidate) != selected_key
        for candidate in (changed_irrep, changed_opd, changed_k)
    )
    exact_fixed_space = deepcopy(selected)
    exact_fixed_space.method3_route_resolution = "exact_fixed_space"
    assert (
        IsoDistort._method3_embedding_guard_key(exact_fixed_space)
        != selected_key
    )

    selected.basis_vectors = [[2, 0, 0], [0, 1, 0], [0, 0, 1]]
    selected.origin = [0, 0, 0]
    selected_key = IsoDistort._method3_embedding_guard_key(selected)
    parent_cell_shift = deepcopy(selected)
    parent_cell_shift.origin = [1, 0, 0]
    assert (
        IsoDistort._method3_embedding_guard_key(parent_cell_shift)
        != selected_key
    )
    child_lattice_shift = deepcopy(selected)
    child_lattice_shift.origin = [2, 0, 0]
    assert (
        IsoDistort._method3_embedding_guard_key(child_lattice_shift)
        == selected_key
    )

    iso = object.__new__(IsoDistort)
    iso._selected_subgroup = selected
    iso.phase_path = SimpleNamespace(subgroup_index=0)
    iso.distortion_modes = []
    iso.mode_displacements = {"cached": {}}
    iso.mode_occupancies = {}
    iso.mode_displacements_sc = {}
    iso._mode_label_overrides = {}
    iso.distorted_structure = object()
    iso.number_of_independent_modulations = 0
    iso.distortion_types = ["displacive"]
    iso.distortion_scope = {}
    iso._scope_species = lambda _kind, **_kwargs: {"H"}
    selected_context = iso._mode_context_key(
        selected,
        0,
        ["displacive"],
        {},
    )
    iso._mode_cache_key = selected_context
    iso._generated_structure_cache_key = selected_context
    iso._spec_for_subgroup = lambda subgroup, **kwargs: SimpleNamespace(
        subgroup=subgroup, **kwargs
    )

    specs = iso._collect_export_specs([changed_irrep], ["modes"], False)

    assert specs[0].use_current_modes is False
    assert specs[0].use_generated_structure is False


def test_method2_rejects_duplicate_local_candidate_indices():
    iso = object.__new__(IsoDistort)
    iso.structure = object()
    iso.subgroups = []
    first = _candidate(index=0, irrep="GM1+")
    second = _candidate(index=0, irrep="GM2+")

    with pytest.raises(ValueError, match="ambiguous"):
        iso.search_method_2(0, candidates=[first, second])


def test_compute_scoped_modes_does_not_mutate_source_mode():
    raw = DistortionMode(
        irrep_label="GM1+",
        mode_type="magnetic",
        wyckoff_site="a",
        wyckoff_orbit_id="orbit-a",
        bush_modes=[
            BushMode(
                irrep_label="GM1+",
                opd_symbol="P1",
                wyckoff_letter="a",
                point=[0.0, 0.0, 0.0],
            )
        ],
    )
    iso = object.__new__(IsoDistort)
    iso.mode_occupancies = {}
    iso._scope_species = lambda _kind, **_kwargs: {"Fe"}
    iso._letters_for_species = lambda _species: ["a"]
    iso._orbit_ids_for_species = lambda _species: ["orbit-a"]

    scoped = iso._compute_scoped_modes(
        ["displacive"],
        raw_modes=[raw],
    )

    assert raw.mode_type == "magnetic"
    assert scoped[0] is not raw
    assert scoped[0].mode_type == "displacive"


@pytest.mark.parametrize(
    ("export_method", "legacy"),
    ((2, True), (3, False)),
)
def test_export_method_rejects_conflicting_legacy_folder_switch(
    export_method,
    legacy,
):
    with pytest.raises(ValueError, match="conflicts"):
        IsoDistort._export_folder_method(export_method, legacy)


def test_export_method_legacy_switch_remains_compatible_when_new_argument_omitted():
    assert IsoDistort._export_folder_method(None, None) == 2
    assert IsoDistort._export_folder_method(None, True) == 1
    assert IsoDistort._export_folder_method(None, False) == 2
    assert IsoDistort._export_folder_method(1, True) == 1


def test_export_recomputes_every_candidate_for_requested_nmod_and_restores_state():
    """A ZIP must not mix cached modes from one nmod with nmod=0 fallbacks."""
    selected = _candidate(index=0, irrep="LD1")
    other = _candidate(index=1, irrep="LD2")
    iso = object.__new__(IsoDistort)
    iso._selected_subgroup = selected
    iso.phase_path = SimpleNamespace(subgroup_index=0)
    original_mode = DistortionMode(
        irrep_label="LD1",
        mode_type="magnetic",
        wyckoff_site="a",
        wyckoff_orbit_id="orbit-a",
        bush_modes=[
            BushMode(
                irrep_label="LD1",
                opd_symbol="P1",
                wyckoff_letter="a",
                point=[0.0, 0.0, 0.0],
            )
        ],
    )
    iso.distortion_modes = [original_mode]
    iso.mode_displacements = {"cached-nmod-1": {}}
    iso.mode_occupancies = {}
    iso.mode_displacements_sc = {}
    iso._mode_label_overrides = {}
    iso.distorted_structure = None
    iso.number_of_independent_modulations = 1
    iso._scope_species = lambda _kind, **_kwargs: {"Fe"}
    iso._letters_for_species = lambda _species: ["a"]
    iso._orbit_ids_for_species = lambda _species: ["orbit-a"]
    iso._spec_for_subgroup = lambda subgroup, **kwargs: SimpleNamespace(
        subgroup=subgroup, **kwargs
    )
    calls: list[tuple[int, int]] = []

    def search_method_2(
        subgroup_idx,
        *,
        distortion_type,
        number_of_independent_modulations,
        candidates,
        distortion_scope,
    ):
        calls.append((subgroup_idx, number_of_independent_modulations))
        assert distortion_type == ["displacive", "strain"]
        assert distortion_scope == {}
        iso._selected_subgroup = candidates[0]
        iso.number_of_independent_modulations = number_of_independent_modulations
        iso.mode_displacements = {f"fresh-{subgroup_idx}": {}}
        iso.distortion_modes = iso._compute_scoped_modes(
            ["displacive"],
            raw_modes=[original_mode],
        )

    iso.search_method_2 = search_method_2

    specs = iso._collect_export_specs(
        [selected, other],
        ["modes"],
        True,
        number_of_independent_modulations=2,
    )

    assert calls == [(0, 2), (1, 2)]
    assert [spec.use_current_modes for spec in specs] == [True, True]
    assert [spec.use_generated_structure for spec in specs] == [False, False]
    assert iso._selected_subgroup is selected
    assert iso.distortion_modes == [original_mode]
    assert iso.distortion_modes[0].mode_type == "magnetic"
    assert iso.mode_displacements == {"cached-nmod-1": {}}
    assert iso.number_of_independent_modulations == 1


def test_removed_compatibility_namespace_stays_removed():
    """The retired ``isodistort`` alias package must not come back.

    The project exposes three layers (``backend`` / ``application`` /
    ``frontend``) and shared resources.  A resurrected alias package would load a
    second copy of the data classes and break identity comparisons.
    """
    canonical = importlib.import_module("backend.wrappers.iso_wrapper")
    assert canonical.SubgroupInfo is SubgroupInfo
    for retired in ("isodistort", "isocore", "web", "features", "backend.api", "frontend.i18n"):
        with pytest.raises(ModuleNotFoundError):
            importlib.import_module(retired)
