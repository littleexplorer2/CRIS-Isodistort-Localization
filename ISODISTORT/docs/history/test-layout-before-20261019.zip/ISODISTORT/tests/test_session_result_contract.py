"""Independent state and external displacement contracts, without official answers."""
from dataclasses import FrozenInstanceError, asdict, replace
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

from application.session import IsoDistort
import application.session.core_api as core_api
from backend.export.distortion_formats import cart_normalized_mode_matrix
from backend.wrappers import SubgroupInfo
from backend.models.phase_path import validate_modulation_count
from backend.method2 import Method2Solver
from backend.method2 import superspace
from tests.test_production_displacive_core import _p1_api_with_canonical_modes


def test_action_snapshot_preserves_internal_aliases_and_new_state(monkeypatch):
    class RuntimeStub:
        def clone_runtime_from(self, source):
            self.source = source
        def close(self):
            pass
    monkeypatch.setattr(core_api, "IsoWrapper", RuntimeStub)
    monkeypatch.setattr(core_api, "SmodesWrapper", RuntimeStub)
    session = IsoDistort()
    selected = SubgroupInfo(index=0, space_group_number=1)
    session.subgroups = [selected]
    session._selected_subgroup = selected
    session.additional_scientific_state = {"candidate": selected, "values": [1]}
    snapshot = session.snapshot_for_action()
    assert snapshot.structure is None
    assert snapshot._selected_subgroup is snapshot.subgroups[0]
    assert snapshot.additional_scientific_state["candidate"] is snapshot.subgroups[0]
    snapshot.additional_scientific_state["values"].append(2)
    snapshot._selected_subgroup.index = 3
    assert session.subgroups[0].index == 0
    assert session.additional_scientific_state["values"] == [1]
    assert snapshot._iso is not session._iso


def _calculated_session():
    # Independent P1 full microscopic basis on an oblique lattice. These are
    # analytically constructed unit displacement columns, not website outputs.
    session, selected = _p1_api_with_canonical_modes()
    session.mode_displacements_sc = {}
    for index, mode in enumerate(session.distortion_modes):
        column = np.zeros((len(session.structure), 3))
        column[index // 3, index % 3] = -1 if index % 2 else 1
        session.mode_displacements_sc[mode.amplitude_key] = column
    session.distortion_scope = {}
    session.number_of_independent_modulations = 0
    session._mode_cache_key = session._mode_context_key(selected, 0, session.distortion_types)
    return session


def _selection_session(monkeypatch):
    """Exercise both public adapters with an independent analytic P1 basis.

    Only the backend mode calculation is replaced. Candidate guards, species
    selection, session commit, and the immutable snapshot are real code.
    """
    session = _calculated_session()
    session.subgroups = [session._selected_subgroup]
    session.distortion_types = ["displacive", "strain"]
    session._iso = SimpleNamespace(list_k_points=lambda _parent: [])
    session._smodes = object()
    session._method2 = Method2Solver(session._iso)
    source_modes = session.distortion_modes
    source_columns = session.mode_displacements_sc
    calls = []

    def calculate(_parent, _info, target, letters, *_runtimes, **kwargs):
        calls.append((target.index, tuple(letters), kwargs.get("nmod", 0),
                      tuple(kwargs.get("wyckoff_orbit_ids") or ())))
        allowed = set(kwargs.get("wyckoff_orbit_ids") or ())
        modes = [mode for mode in source_modes
                 if not allowed or mode.wyckoff_orbit_id in allowed]
        return superspace.ParametricModeResult(
            modes=modes,
            supercell_displacements={mode.amplitude_key: source_columns[mode.amplitude_key].copy()
                                     for mode in modes},
            labels={mode.amplitude_key: mode.amplitude_key for mode in modes},
            nmod=kwargs.get("nmod", 0),
        )

    monkeypatch.setattr(superspace, "compute_parametric_modes", calculate)
    monkeypatch.setattr(superspace, "compute_special_modes_with_rootless_supplement", calculate)
    return session, calls


@pytest.mark.parametrize("entry", ["select_path", "search_method_2"])
@pytest.mark.parametrize("invalid", ["ambiguous", "diagnostic", "registered_diagnostic"])
def test_public_selection_rejects_unsafe_candidates_before_calculation(monkeypatch, entry, invalid):
    session, calls = _selection_session(monkeypatch)
    if invalid == "ambiguous":
        session.subgroups.append(replace(session.subgroups[0], irrep_label="GM2+"))
        expected, message = ValueError, "ambiguous"
    elif invalid == "diagnostic":
        session.subgroups[0].method3_route_resolution = "affine_only_unresolved_coupled_route"
        expected, message = RuntimeError, "no resolved single-IR or coupled-IR"
    else:
        session._unresolved_method3_embedding_keys = {
            session._method3_embedding_guard_key(session.subgroups[0])}
        expected, message = RuntimeError, "no resolved single-IR or coupled-IR"
    old_phase = session.phase_path
    old_modes = session.distortion_modes
    with pytest.raises(expected, match=message):
        getattr(session, entry)(0)
    assert calls == []
    assert session.phase_path is old_phase
    assert session.distortion_modes is old_modes


def test_select_path_commits_explicit_types_before_snapshot(monkeypatch):
    session, calls = _selection_session(monkeypatch)
    path = session.select_path(0, distortion_type=["displacive"])
    snapshot = session.displacement_snapshot()
    assert path is session.phase_path
    assert session.distortion_types == ["displacive"]
    assert len(snapshot.columns) == 6
    assert len(calls) == 1


@pytest.mark.parametrize("nmod", [0, 1, 3])
@pytest.mark.parametrize("species", [["*"], ["H"], ["He"]])
@pytest.mark.parametrize("types", [None, ["displacive"]])
def test_public_selection_entries_preserve_current_nmod_and_species_scope(monkeypatch, nmod, species, types):
    snapshots = []
    paths = []
    for entry in ("select_path", "search_method_2"):
        session, calls = _selection_session(monkeypatch)
        session.number_of_independent_modulations = nmod
        session.set_distortion_scope({"displacive": species})
        kwargs = {} if entry == "select_path" else {"number_of_independent_modulations": nmod}
        returned = getattr(session, entry)(0, distortion_type=types, **kwargs)
        snapshots.append(session.displacement_snapshot())
        paths.append(asdict(session.phase_path))
        assert session.number_of_independent_modulations == nmod
        assert session.distortion_scope["displacive"] == species
        assert session.distortion_types == (types or ["displacive", "strain"])
        assert len(calls) == 1
        if entry == "select_path":
            assert returned is session.phase_path
        else:
            assert returned.metadata["number_of_independent_modulations"] == nmod
    assert snapshots[0] == snapshots[1]
    assert paths[0] == paths[1]
    expected_orbits = {"orbit-h", "orbit-he"} if species == ["*"] else {
        "orbit-h" if species == ["H"] else "orbit-he"}
    assert len(snapshots[0].columns) == 3 * len(expected_orbits)
    assert all(any(orbit in column.key for orbit in expected_orbits) for column in snapshots[0].columns)


def test_public_snapshot_preserves_columns_frame_identity_and_is_immutable():
    session = _calculated_session()
    snapshot = session.displacement_snapshot()
    assert snapshot.schema == "isodistort.displacement-snapshot.v1"
    assert [column.key for column in snapshot.columns] == list(session.mode_displacements_sc)
    basis = np.array(session._selected_subgroup.basis_vectors, dtype=float)
    expected_frame = np.mod(session.structure.frac_coords @ np.linalg.inv(basis), 1)
    np.testing.assert_allclose(snapshot.fractional_coordinates, expected_frame, atol=1e-14, rtol=0)
    for column in snapshot.columns:
        np.testing.assert_array_equal(column.fractional_vectors, session.mode_displacements_sc[column.key])
    with pytest.raises(FrozenInstanceError):
        snapshot.nmod = 1
    first = snapshot.columns[0]
    session.mode_displacements_sc[first.key][:] = 25
    assert first.fractional_vectors[0] == (1., 0., 0.)
    assert json.loads(snapshot.candidate_identity_json)["parent_sg"] == 1
    assert asdict(snapshot)["schema"] == snapshot.schema


@pytest.mark.parametrize("corruption", ["nmod", "candidate", "orphan", "nan", "scope", "types", "zero"])
def test_snapshot_rejects_changed_or_incomplete_result(corruption):
    session = _calculated_session()
    if corruption == "nmod":
        session.number_of_independent_modulations = 1
    elif corruption == "candidate":
        session._selected_subgroup.k_parameters = ["1/7"]
    elif corruption == "scope":
        session.set_distortion_scope({"displacive": ["H"]})
    elif corruption == "types":
        session.set_distortion_types(["strain"])
    elif corruption == "zero":
        session.mode_displacements_sc[list(session.mode_displacements_sc)[-1]][:] = 0
    elif corruption == "orphan":
        session.mode_displacements_sc["orphan"] = np.ones((2, 3))
    else:
        session.mode_displacements_sc[next(iter(session.mode_displacements_sc))][0, 0] = np.nan
    with pytest.raises((RuntimeError, ValueError)):
        session.displacement_snapshot()


def test_cris_to_gd_preserves_displacement_and_reciprocal_pairing(monkeypatch):
    gd = Path(__file__).resolve().parents[3] / "GD"
    if not (gd / "isodistort_to_gd.py").is_file():
        pytest.skip("Sibling GD converter is not available")
    monkeypatch.syspath_prepend(str(gd))
    from isodistort_to_gd import bundle_from_displacement_snapshot
    session = _calculated_session()
    snapshot = session.displacement_snapshot()
    bundle = bundle_from_displacement_snapshot(
        snapshot, cart_normalized_mode_matrix, cif=Path("independent-P1.cif"),
    )
    assert bundle.irrep == "GM1+" and bundle.opd == "P1"
    assert "unit GD coefficient" in bundle.metadata["maxamp_convention"]
    tiny = replace(snapshot, columns=tuple(replace(c, fractional_vectors=tuple(
        tuple(1e-20 * v for v in row) for row in c.fractional_vectors)) for c in snapshot.columns))
    tiny_bundle = bundle_from_displacement_snapshot(
        tiny, cart_normalized_mode_matrix, cif=Path("independent-P1.cif"))
    np.testing.assert_allclose(tiny_bundle.mode_frac, bundle.mode_frac, rtol=2e-7, atol=2e-8)
    with pytest.raises(TypeError):
        bundle_from_displacement_snapshot(snapshot, cart_normalized_mode_matrix,
                                          cif=Path("input.cif"), irrep="LD1")
    corrupted = replace(snapshot, columns=(*snapshot.columns[:-1], replace(
        snapshot.columns[-1], fractional_vectors=((0., 0., 0.), (0., 0., 0.)))))
    with pytest.raises(ValueError, match="positive finite"):
        bundle_from_displacement_snapshot(corrupted, cart_normalized_mode_matrix,
                                          cif=Path("input.cif"))
    lattice = np.asarray(snapshot.lattice_angstrom)
    # An independent metric calculation on the oblique lattice verifies scale,
    # sign and ordering. GD stores float32, so use its rounding error budget.
    for index, column in enumerate(snapshot.columns):
        raw = np.asarray(column.fractional_vectors)
        metric_norm = np.sqrt(np.sum((raw @ lattice) ** 2))
        expected = raw / metric_norm
        np.testing.assert_allclose(bundle.mode_frac[index], expected, rtol=2e-7, atol=2e-8)
        dmax = np.max(np.linalg.norm(bundle.mode_frac[index] @ lattice, axis=1))
        assert bundle.max_bounds[index] * dmax == pytest.approx(1, rel=2e-7)
    amplitudes = np.linspace(-0.2, 0.3, len(snapshot.columns))
    expected_delta = sum(a * np.asarray(c.fractional_vectors) /
                         np.sqrt(np.sum((np.asarray(c.fractional_vectors) @ lattice) ** 2))
                         for a, c in zip(amplitudes, snapshot.columns, strict=True))
    np.testing.assert_allclose(np.einsum("i,ijk->jk", amplitudes, bundle.mode_frac),
                               expected_delta, rtol=2e-7, atol=2e-8)
    h = np.array([2., -1., 3.])
    x = np.asarray(snapshot.fractional_coordinates[0])
    basis = np.array(session._selected_subgroup.basis_vectors, dtype=float)
    x_parent = x @ basis
    assert h @ x_parent == pytest.approx((h @ bundle.hkl_transform) @ x, abs=1e-12)
    # This non-symmetric basis distinguishes the correct dual map from h @ B.
    assert not np.isclose(h @ x_parent, (h @ basis) @ x)


def test_method3_identity_has_one_serializable_source():
    from backend.method3 import Method3ResultItem
    subgroup = SubgroupInfo(index=0, space_group_number=1,
                            method3_route_resolution="exact_fixed_space",
                            method3_embedding_id="m3e1-" + "a" * 64)
    item = Method3ResultItem(subgroup, "1", [[1, 0, 0], [0, 1, 0], [0, 0, 1]])
    restored = SubgroupInfo(**asdict(subgroup))
    assert restored.method3_embedding_id == item.embedding_id
    assert item.route_resolution == restored.method3_route_resolution
    with pytest.raises(AttributeError):
        item.embedding_id = "conflicting copy"
    assert "embedding_id" not in vars(item)


@pytest.mark.parametrize("value", [True, False, 1.5, -1, "1", None])
def test_modulation_count_does_not_coerce_a_different_scientific_request(value):
    with pytest.raises(ValueError, match="nmod"):
        validate_modulation_count(value)


def test_modulation_count_reports_unsupported_domain_instead_of_clamping():
    for value in range(4):
        assert validate_modulation_count(value) == value
    with pytest.raises(NotImplementedError, match="nmod=0..3"):
        validate_modulation_count(4)
