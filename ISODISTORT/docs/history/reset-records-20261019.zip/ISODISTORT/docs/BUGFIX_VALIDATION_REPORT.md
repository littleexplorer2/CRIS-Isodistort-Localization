# 当前验证缺口与证据入口

待办与调度只维护在 [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md)；
下载动作见 [DOWNLOAD_CHECKLIST.md](DOWNLOAD_CHECKLIST.md)。
已完成 debug、下载、迁移和修改历史的完整原文见 [可恢复归档](history/README.md)。

## 2026-10-17 页面存档改名、4310 冻结空列表与列表驱动的目录建立

用户本轮要求：(1) 冻结 4310 的 Method 3/4 列表；(2) 按 k/IR 信息改 webpage_info 中 Method 2
相关 HTML 文件名并完善存储体系；(3) 文件管理体系只能依据已有列表构建，未知结果列表留空等
下载，不得用本地网页版输出构建；(4) 重新给出下载清单、目的地与命名。本轮不改生产代码与
科学算法。

修改点：

- **webpage_info 页面存档改名**：25 张 Method 2 相关页面改为
  `<步号> <上下文后缀> - <官网原文件名>.html`（IR 页 `3. <K>_nmod<N> - …`；结果页
  `4.<i> <K>_nmod<N>_<IR> - …`；候选详情 `5./6. …`；叠加 IR 历史页用 `irs=<n>`）。HTML 与
  `_files` 目录同前缀，HTML 内的资源引用共 118 处重写；另有 11 处历史遗留的错误引用被修到
  本页资源目录（4310 的 8 张结果页、3.5 页与 `a.` 页），1 个孤立资源目录
  `4.a.  …_files` 归位。改名/内容哈希/引用修复全部登记在 `webpage_info/_PAGE_INDEX.json`；
  非 Method 2 页（`1.`、`2.`、`a.`）保持原名，只登记哈希。存储约定见
  `webpage_info/README.md`。
- **4310 X nmod=0 结构已按已归档结果列表建好**：`webpage_info/4310_tetra.cif/` 的 IR 页 +
  `4.1`–`4.8` 结果页共 24 行，与旧嵌套候选 24 个逐行一致；候选移入
  `output_compare/4310_tetra.cif/官网/Method2/X/nmod0/` 并统一为 `<IR>_<OPD>`，提交态截图
  一并移入。核对报告 `output/validation/method2_existing_list_verification_20261017.json`
  （24/24 行↔目录，四件套齐全，24/24 与 Method 1 目录身份一致）。
- **4310 Method 3/4 列表冻结为空**：manifest 新增 `frozen_empty_result_lists`；无独立输入
  案例，无结果页可下载，不建目录；解冻条件写明。
- **结果列表下载目的地改为页面存档**：新页面写入 `webpage_info/<母相>/`（原
  `output_compare/.../_incoming_result_lists/` 空目录已删除）。阶段清单升级为
  `official-result-list-stage/v2`：102 个查询里 1 个已完整归档（X nmod0）、2 个部分归档
  （LD nmod0 缺 2 张、Y nmod0 缺 3 张结果页）、99 个需完整页面集；已归档页面不重下。
- manifest revision 4：候选下载 99 次提交、登记复用 3 个 nmod=0 查询；移除预构建的目录字段，
  明确“查询目录只在列表完整后建立”；本地产物/输入网格审计按下载分区重跑。
- 复用清单重建（X 候选新路径/新名），SHA-256 `5f75cdde…`；旧归档总文件数与字节数不变
  （4,753 文件、566,828,527 B）。

科学影响判断：输入标签、代表值、母相哈希、仿射模板小余群结论不变（pass 报告仍有效）；
变化只在页面命名、列表取得顺序与目录映射。所有目录都来自真实官网列表行；未知列表不建
目录、不用本地网页版输出推断；LD/Y/X 的 nmod0 候选复用有独立指纹登记；nmod0/nmod1 是否
相同仍未预设。webpage_info 的内容改动仅限登记过的改名与资源引用修复（每页记录改名前后的
SHA-256），页面语义未改。

验证：25 页改名与 118+11 处引用修复全部登记，`webpage_info/_PAGE_INDEX.json` 记录每页
改名前后的 SHA-256 与资源目录指纹，全部本地 `_files` 引用可解析（`all_refs_resolve=true`）；
X/nmod0 核对 24/24 pass（四件套齐全、24/24 与 Method 1 目录身份一致）；阶段清单/manifest
102 查询、51 个 k 标签与 nmod{0,1} 一致；候选阶段计数 99 下载 + 3 登记复用；grid report
重跑 pass（99/3、0 issue）；定向测试 34 passed；`pytest tests_repo` 34 passed；完整
`pytest ISODISTORT/tests -q` → **1168 passed、2 skipped、0 failed**（22:41，日志
`output/validation/full_suite_20261017_pages.log`；尾部慢测为 `test_web`/`test_wsl` 的真实
ISO 计算，监控中 WSL `iso` 进程持续出现，非卡死）；文档相对链接 0 缺失；`output_compare`
无遗留 inbox，官方树空目录只剩 4310 Method3/4（冻结空列表，预期）。

剩余缺口：99 个查询的结果列表页尚未下载，候选阶段未开始；Method 2 列表/候选只读审计工具
仍未实现；4310 Method 3/4 需先冻结独立输入才能解冻空列表。

## 2026-10-17 下载流程改为先取官网结果列表（历史中间版，已被上节取代）

用户要求先只下载官网**结果列表页**，由代理按列表修正 `output_compare` 的文件夹结构，并补齐
Method 2 全部 k 点（不再是每晶体一个 k 点）。本轮只改下载阶段、清单和目录预建，不改生产
代码与科学算法。

修改点：

- 撤销“每个 Method 2 查询一个 `result_table.html`”假设。实测官网 Method 2 结果为
  **每个查询 1 张 IR 列表页 + 每个 IR 1 张 `order parameter direction` 结果列表页**；缺任一
  IR 页都无法证明候选全集。清单与 manifest（revision 3）已改正。
- 新建 102 个结果列表 inbox：
  `output_compare/<母相>/官网/Method2/_incoming_result_lists/<K>/nmod<0|1>/`
  （EuAl4 30 = 15 k × 2；NdNiO2 42 = 21 k × 2；4310 30 = 15 k × 2）。页面命名沿用官网流程
  步号：IR 页 `3.`，各 IR 结果页 `4.1`、`4.2`…；HTML 与 `_files` 同前缀。
- 新增阶段清单 [official_result_list_stage_20261017.json](manifests/official_result_list_stage_20261017.json)
  （102 查询的 inbox、参数、坐标、计划正式目录）与人工执行表
  `output/validation/official_full_download/20261017-official-full-v2/result-list-worklist.md`；
  manifest 增加 `result_list_stage`、每查询 `k_directory` / `nmod_directories`，正式结构计划
  为 `Method2/<K>/nmod<N>/`（K 与旧 k 点同层，新增 k 点平行）。
- 列表可用性核查（本轮结论）：Method 2 三母相全缺列表，需下载 102 个查询；Method 1 的完整
  列表已在只读 `webpage_info/<母相>/a. ISODISTORT_ order parameter direction.html`，行数
  123/82/125 且与 `output_compare` 全部 330 个 Method 1 候选目录身份逐项相等，无需重下；
  EuAl4/NdNiO2 的 Method 3 各 20/20、Method 4 各 12/12 案例目录已含自己的官网结果页；
  4310 的 Method 3/4 范围未冻结，暂无列表可下载。
- 正式目录与候选目录**尚未重建**：等结果列表到齐后按页面隐藏字段（k 向量、nmod、IR）解析，
  只按真实结果行创建候选目录，并把旧 LD/Y/X 候选移入对应 `<K>/nmod0/`；旧目录现在保持原位。

科学影响判断：输入标签、代表值、母相哈希、仿射模板小余群结论都不变（既有 pass 报告仍有效）；
变化的只是官方结果列表的获取顺序与目录映射，不涉及本地求解合同，也没有从官网结果反推输入。
Method 1 的“列表已存在”结论由行数与身份逐项相等支持，不是仅凭行数；Method 3/4 的状态沿用
既有案例目录证据，4310 未冻结范围不作任何推断。

验证：inbox 目录 30/42/30 共 102 个且为空；阶段清单与 manifest 的 102 个查询、51 个 k 标签、
每查询 nmod{0,1} 一致；两阶段计数（列表 102 查询 / 候选 100 提交）分别记录；JSON 可解析；
文档相对链接可解析；既有 Method 2 候选目录 94 个与复用登记指纹未变。

剩余缺口：结果列表尚未下载，目录重建和列表↔候选行核对未执行；Method 2 列表/候选只读审计
工具仍未实现（下载清单第 9 节）；4310 的 Method 3/4 列表要等独立范围冻结。

## 2026-10-17 下载清单 v2：改到 output_compare 并复用旧归档

用户要求把官网下载目标改到既有 `output_compare` 树、复用旧文件且不重复下载。本轮只改下载
范围/目录、审计输入分区和相关文档，不改生产代码与科学算法。

修改点：

- 新批次 `20261017-official-full-v2`（`output_root=output_compare`）。旧 v1 清单冻结字节
  （SHA-256 `879c72e9…`，52,683 B）归档为
  [official-download-manifest-20261016.zip](history/official-download-manifest-20261016.zip)
  （ZIP SHA-256 `0d5f55a3…`）；v1 批次根从未下载官网文件，空骨架已删除并留迁移说明。
- 新增只读复用登记 [official_archive_reuse_20261017.json](manifests/official_archive_reuse_20261017.json)
  （later rebuilt the same day; current SHA-256 `5f75cdde…`）：登记旧官网归档指纹（4,753 文件、566,828,527 B、聚合
  `4315459f…`）与 3 个可复用 Method 2 输出——EuAl4 `LD g=1/6` nmod=0（22 候选）、
  NdNiO2 `Y a=1/3` nmod=0（48 候选）、4310 `X` nmod=0（24 候选，含提交态截图
  `4b6586cf…`）。生成器 `tests/manual/register_official_archive_reuse.py` 只读
  `output_compare`，拒绝把登记文件写进归档内部；候选数、k 点头与
  `!numberOfModulations` 不符时拒绝登记。
- 在 `output_compare/<母相>/官网/Method2/` 预建并核对 **100 个空查询目录**
  （EuAl4 29 / NdNiO2 41 / 4310 30）；既有候选目录与文件指纹未动。
- **nmod 覆盖修正**：旧 v1 把 EuAl4 LD、NdNiO2 Y 的 nmod0 与 nmod1 共 4 个查询都记为
  “已登记”，但归档 94 个候选的 `!numberOfModulations` 全为 0（只有 nmod=0）。v2 改为
  2 个登记复用查询，并把 LD/Y 的 nmod=1 计入下载：提交次数 98 → **100**（范围查询 102 =
  32 固定 + 70 参数化）。4310 X nmod=0 只补 `result_table.html`，候选引用旧归档。
- 输入网格审计脚本与测试改为按 `download_nmod_values` / `registered_nmod_values` 分区核对；
  新报告 `output/validation/reciprocal_scope_20261017_reuse/grid-report.json`
  （SHA-256 `789bec50…`），修订前报告保持不动、仅对 v1 有效。

科学影响判断：51 个输入标签、代表值、母相哈希、仿射模板一般位置与同星判据结论不变
（仍 pass、0 issue）；变化只在 nmod 下载/登记分区与下载落盘位置。输入仍来自独立冻结的
k/nmod 控件参数，没有从官网结果反推、挑选或补齐任何输入。条件复用未预设 nmod1 等价：
必须先下载结果表，再按候选身份与逐字节比较登记结论。复用件只作只读参考，不进入本地计算链。

隔离核查：新下载只写入预登记空目录；既有归档只读且登记指纹可在审计中重算；登记脚本拒绝
写入归档；未新增答案通道，未复制官网候选/模式/振幅到计算输入。

验证：`verify_parametric_k_grid.py --report reciprocal_scope_20261017_reuse/grid-report.json`
→ `verdict=pass`、`download_queries=100`、`registered_queries=2`；
`pytest ISODISTORT/tests/test_parametric_k_grid.py ISODISTORT/tests/test_official_archive_reuse.py -q`
→ 34 passed；完整 `pytest ISODISTORT/tests -q` → **1168 passed、2 skipped、0 failed**
（23:04，日志 `output/validation/full_suite_20261017_reuse.log`），跳过项与此前记录的两类
环境依赖一致（外部 X4- P3 CIF 配对、需要原生 POSIX shell 的生命周期测试）；
`pytest tests_repo -q` → 34 passed；复用清单重建与提交文件一致，且在 100 个空目录建好
后重新通过；100 个查询目录与 manifest `download_directories` 逐一存在且为空；文档相对
链接全部可解析；本轮文件无真实尾随空白，编辑文件保持各自原有 CRLF/LF 约定。
`git diff --check` 在整仓 CRLF 文本上会把行尾 CR 报成 trailing whitespace（既有约定，
非本轮引入），不能作为本轮失败判据。

剩余缺口：Method 2 新查询的只读审计工具尚未实现（下载清单第 9 节）；LD/Y nmod=1 候选能否
去重须由下载后的比较确定；复用候选身份/指纹是 2026-10-17 的登记证据，不是身份等价或数值
正确的科学证明；Method 3/4 独立范围仍未冻结。

## 2026-10-17 下载输入的倒格与一般位置复核

本轮只修改输入审计和相关证据/计划，不改变生产科学算法，不运行新的官网差分。
输入为三个母相 CIF 的既定哈希、标准四方 setting 及独立冻结的 k/nmod 控件参数；
通用 k 表与精确晶格工具可参与计算，官网结果、预期候选数和 manifest 自报 pass 均不参与。
推导见[补充证明](reference_library/latex/unsupported_algorithm_proofs.tex)的
`sec:grid-duality`；依据为 IUCr 倒格教学材料与 International Tables 的对偶格定义。

原胞直接平移按行组成 P，倒格等价条件为 `P(k1-k2) ∈ Z³`，点操作为 `R^-T`。
一般位置小余群通过仿射模板常数项/系数的精确条件取得，未用有限样点估计。
当前输入共 51 标签（16 固定、35 参数化），全部通过模板内一般位置与同星碰撞检查；
没有模倒格别名。I 心的 GM 与 M 不等价；EuAl4/4310 的 Q 小余群阶数为 2、W 为 4。
现有代表值和 98 次待下载查询保持不变（该轮按 v1 清单计数；v2 修正为 100，见上节）；
每条查询的目录已在机器清单登记并核对存在。
这些结论不证明非公度物理表示、全部参数域、nmod>=2 等价性或 Method 3/4 范围完备。

同类审查覆盖生产 `search_methods` 的原胞相位判等、`opd_format` 的 P/A/B/C/I/F/R
选择规则与逆转置星臂、`superspace` 的平移相位及验证器的原胞晶格包含判定。
这些现有路径已考虑心化；生产公开星臂 API 对本次全部 51 个独立输入给出的臂数与精确
轨道稳定子结果一致。该交叉检查不等于证明这些模块的所有分支正确。

旧 DS 网格报告已标为 invalidated；旧 Method 3 闭包从官网输出取种子，且缺少母/子
原胞心化、指数与完备性证明，所有相关报告/checkpoint 均禁止继续用于验收或续跑。
`measure_method3_closure.py` 只保留明确返回 2 的停用提示，不再读取种子或启动搜索。
修正前源文件、报告和清单已按 SHA-256 归档，见[历史索引](history/README.md)。
“40 个历史分类一致”、114 种目标群、HNF 类数与其推算规模全部撤销为当前范围依据；
历史案例本身保留，Method 3/4 独立输入枚举的待办见开发计划。

本轮证据目录为 `output/validation/reciprocal_scope_20261017/`（不提交）：
`grid-report.json` 保存输入摘要和源码签名，`production-star-crosscheck.json` 保存 51 项
公开接口核对；`test-start-signatures.json` 固定回归开始时的三层和测试源文件。
新增 26 项测试覆盖七种心化、基变换协变性、非正交轴、仿射退化反例、输入漂移及停用门禁。
完整科学回归 **1160 passed、2 skipped、0 failed**，耗时 19 分 28 秒（`full.xml` / `full.log`）；
仓库架构/打包门禁 **34 passed**（`repo.xml`）。161 个三层/测试 Python 文件在回归前后
SHA-256 全部一致，见 `final-evidence.json`。跳过项为缺失 X4- P3 外部 CIF 配对、需要原生
POSIX shell 的生命周期测试；本轮未执行人工 GUI 或新官网全量差分。
资料完整性、LaTeX 引用与新增页面渲染检查通过，未增加经验拟合、材料特判或官网答案输入。

## 2026-10-16 重置

用户要求先完成官网三母相有限全量输出的下载、再重新开始验证与 debug。旧的 74 项本地
刷新冻结清单及其 20261009 批次产物整体作废并归档，细节见
[重置记录](manifests/validation_reset_20261016.json) 与[历史索引](history/README.md)。
当前**没有生效的本地刷新冻结清单**：`download_local_web_outputs.mjs` 会因 `status != frozen`
拒绝运行，这是预期行为。理论与代码审查、三层重构验证、参考资料库与 pytest 结论不依赖
官网下载范围，继续有效；所有“官网↔本地”对照结论只适用于旧官网集，必须在新官网集下重做。
本轮只改文档与机器记录，未改生产代码、算法、配置默认值或科学合同。

## 集成验证与管线合同检查（2026-10-16）

验证公共入口为 `tests.validation`；生产模块不导入测试支持包。入口、默认配置、
源码签名、部署器和架构清单已按当前目录统一。原 CIF 比较器 AST 与迁移前相同；
Method 4 的两个数据合同及五个计算方法与迁移前快照 AST 相同，这只证明移动未改写
相应算法，不代表对全部科学输入的认证。公共兼容入口继续调用同一实现。

本轮涉及科学语义的共享合同如下：

- 心化矩阵采用精确有理数；惯用胞中原胞个数为 `1 / abs(det(P))`，原胞/惯用胞
  体积比与该指数的乘积为一。验证覆盖 P/A/B/C/I/F/R 的独立晶格重数；不引入
  材料相关比例或振幅拟合。
- 超胞采用行约定 `x_parent = x_child @ B`；物种和占据保持一致，位点及整数平移
  必须在给定笛卡尔误差球中唯一。容差单位为 Å，默认值来自配置
  `symmetry_cartesian_tolerance_angstrom`。重排和扩胞坐标守恒为正例；缺失站点、
  斜晶格和同站点多个周期像为反例。该合同仅适用于未畸变对应，不代替畸变结构匹配。
- 数学依据为资料库补充证明 `sec:shared-mapping`，对应 C02/C03；Method 4 归属
  与 C15 的来源链同步。这里未改变动力学或能量模型，能量守恒不是这次重构的验收项。
- 比较容差沿用测试 YAML 的晶格、周期分数坐标和标量三个域；非有限或负容差拒绝。
  语义、声明的参考哈希与严格字节条件逐项成立才通过；空批次不表示成功。
  比较器只读取冻结文件，验证参数不回传生产计算。

原始证据位于 `output/validation/pipeline_cleanup/`（不提交）：
`final-source-evidence.json` 保存源码/配置/依赖指纹和 AST 核对；`repo-final.xml`
记录仓库门禁及实际 wheel 检查 34 passed；目录清理后的 `directory-removal.xml`
记录门禁、集成比较和受影响配对测试 75 passed、1 skipped（缺少外部 CIF 配对）。
完整科学回归于 2026-10-17 完成：**1132 passed、3 skipped、0 failed**，耗时
20 分 18 秒，见同目录 `full-final.xml` 与 `full-final.log`。三个跳过项分别缺少
X4- P3 外部配对文件、需要原生 POSIX shell、缺少 EuAl4 LD1 `g=1/6` 本地子群数据库。
运行期间的目录清理只改动测试支持和路径引用，生产三层指纹未变；对应最终版本已由
上述 75 passed、1 skipped 的补充复测覆盖。源码指纹、Ruff F821/F401 和
`git diff --check` 终检通过。

资料完整性及引用检查通过，两篇 LaTeX 编译成功；新增证明页面的渲染检查范围见
资料库 `audit/DELIVERY_REVIEW.md`。未运行官网全量差分或人工 GUI 验收，既有科学
缺口仍保留；静态去重与调用扫描不构成对所有动态路径不存在死代码的形式化证明。

## 理论与代码一致性审查（2026-10-15）

本轮按文献和两份证明检查实际调用链，详细反例、推导、修复和限制统一见
[理论审查报告](reference_library/audit/THEORY_CODE_AUDIT.md)。
[实现清单](reference_library/audit/implementation_audit.json) 保存逐能力状态与最终检查数字；
原始日志、JUnit、k 参数回代及源码指纹在
`output/validation/theory_design_audit_20261015/`（相对于 ISODISTORT）。

已移除官网存档回填、占据率排序二分/夹取、以位移代替转动和按重数猜 Wyckoff 字母；
修复行基矢点群作用、精确晶格判定、分数显示和含常数/负号/耦合的波矢换算。
Wyckoff 标签增加实际 Hall/原点门禁，标准表种子经独立交叉检查；旧母胞映射的均匀
复制与最近邻补位已替换为既有完整子胞映射的覆盖性检查。
最小二乘仍用于有来源且满秩的固定模式基分解，它不是材料答案拟合。
未实现物理模型明确拒绝；未对全部二进制、表数据、晶体、官网版本或 GUI 作认证。
此前三层重构的测试数字只适用于其当时源码，不代替本轮结果。

## 三层重构验证（2026-10-15）

三个子项目统一为 `frontend → application → backend`，模块目录与维护约束以根
`AGENTS.md`、各子项目 `agent.md` 及 `tests_repo/architecture_manifest.json` 为准。
本轮仅修改 CRIS；选课工具只读参考。原有工作区改动保留。

- 科学算法与会话迁移：对照本轮修改前快照，31 个文件在规范导入替换后的 AST 相同。
  该检查证明迁移没有改写这些计算实现，不代表新增科学输入已验证。
- 首次 ISODISTORT 完整运行：1034 passed、4 failed、3 skipped。两项失败是本轮前已存在
  的导出状态报告断言遗漏（在修改前快照复现）；另两项是旧会话包与新包的 monkeypatch
  状态未共享。分别补齐报告内容/文件保持断言、改为同一模块对象兼容别名后，相关文件
  复测 53 passed/1 skipped 与 51 passed。最终完整复核为 **1040 passed、3 skipped、
  0 failed**，耗时 19 分 24 秒；证据为同目录 `full-final-results.xml` 与
  `full-final-pytest.log`。
  三个跳过项分别缺少 X4- P3 官网/本地配对文件、需要原生 POSIX shell，以及缺少
  EuAl4 LD1 `g=1/6` 本地子群数据库；本轮不生成可能耗时数小时的子群数据库。
- 仓库级门禁与实际 ISODISTORT wheel：32 passed；当时的比较工具：29 passed；
  ISOVIZ_INPUT：40 passed。当时的两个小工具均包含隔离源码后的实际 wheel/CLI 检查；GUI 未启动。
- 三个 wheel 均检查规范入口和资源；两个小工具的 YAML 由唯一源配置在构建时打包，
  自定义配置与包内配置分别保持正确的相对路径基准。旧入口的可变状态兼容有回归覆盖。
- 部署诊断：24 pass、2 warn、0 fail；两个 warn 分别为缺少成对比较 CIF 与振幅 CSV，
  没有将无用户输入视作真实使用验收成功。静态 Ruff F 与 `git diff --check` 通过。
- 手工审计源码签名已覆盖实际 `backend/`、`application/` 及独立比较器的实现，避免
  迁移后只签名旧导入壳。原历史报告继续只适用于当时的源码签名。
- 提交前补查手工网页下载器，将应用层纳入运行前后源码摘要，并新增 2026-10-15
  运行修订；旧冻结输入和旧修订未改写。回归以独立临时文件验证三层源码变化会改变
  摘要、字节码不会改变摘要、合同和父 manifest 漂移会被拒绝；没有启动浏览器下载。

本轮原始日志、JUnit XML、部署诊断及 AST 对照：
`../output/validation/layer_refactor_20261015/`（不提交）。打包测试所需的 setuptools/wheel
临时安装在 CRIS 内的 `ISOVIZ_INPUT/.test-tmp/build-deps`，共享 `.venv` 没有重建或改写；
长期开发依赖已在各项目开发依赖清单中登记。

未执行官网全量重新下载、全部科学输入扩展矩阵或 IsoVIZ/VESTA 人工 GUI 验收；
下面已有科学验证缺口继续保留。

## 当前需要核验

- 官网有限输入集：Method 2 代表网格已精确复核；v2 清单共 100 次查询提交待用户下载和只读
  审计（其中 2 个查询只登记复用、1 个只补结果表、2 个条件候选复用），已归档 94 个 Method 2
  候选按[复用清单](manifests/official_archive_reuse_20261017.json)引用；Method 3/4 仍缺独立
  枚举与上界，旧闭包证据失效，不能据此开始下载。
- 本地输出刷新：**当前没有生效的冻结清单**（旧的 74 项已于 2026-10-16 作废归档）；
  新官网集审计通过后重建清单与 runtime revision，再执行真实网页运行。
- NdNiO2 Y `a=1/3`：旧批次在 `status=running` 且缺四格式 ZIP 的状态下被重置；
  在新官网集下重新执行 nmod=0/1 全候选长时验收。
- 官网补证：EuAl4 G05 auto-origin basis HTML 已于 2026-10-17 补齐并核对为 `pass`。basis 页
  （`output_compare/…/Method4/G05/auto-origin/ISODISTORT_ distorted structure (basis).html`，
  SHA-256 `9e2bfc51…`）的位置、文件名、页面角色与隐藏字段都正确，且不是显式那份（`ce01fea7…`）；
  提交态由新增截图 `Screenshot 2026-10-17 005445.png`（SHA-256 `230d2182…`）证明：
  `Specify basis as` 的三行系数给出基矢 `(0,1,1),(1,0,0),(0,0,-1)`、`Automatic origin detection`
  选中、`Nearest-site method` 选中、robust 未启用、Types = strain + ALL displacive。
  证据替换已登记：被审计的 `Screenshot 2026-09-27 204517.png`（`cc388949…`）已不在归档中，
  旧审计报告保持其自身快照不改写；数值证据未被改动。
- 泛用性、非 Γ 来源合同、混合占位、跨晶系、工具 GUI、性能与并发缺口：
  按开发计划逐项验收。

## 正在使用的证据入口

- 重置记录：`manifests/validation_reset_20261016.json`（作废范围、归档指纹、开放上界）。
- 旧冻结清单：`manifests/local_web_output_refresh_manifest.json`（状态已改为
  `superseded`，案例表保留作参考；冻结字节只在归档中）。
- 旧批次归档：`../docs/history/local-web-output-refresh-20261009.zip`
  （2,150 条目，SHA-256 `935d62e3…8dead`，已逐文件核对一致）。
- 下载清单与目录：`DOWNLOAD_CHECKLIST.md`；新官网材料写入
  `../output/validation/official_full_download/<批次>/<母相>/官网/<Method>/`。
- 导出诊断：`../output/validation/ndnio2_export_audit_20261006/`。
- 既有机器报告仍在 `../output/validation/`；历史索引和适用源码签名可从归档恢复。
  旧官网集的对照报告只适用于其原有官网集与源码签名，不得作为新范围验收。

解释任何结果前核对输入、实际源码、配置、依赖、后端及结束签名；
签名漂移、工具缺失、GUI 未运行或证据不足须显式记录。
归档中的通过结论仅适用于其原有签名和范围。

## 主要科学依据

统一入口为[理论参考资料库](reference_library/README.md)，其中维护作者论文、独立方法、
IUCr 标准与教程、来源审核、能力映射及两份带引用的 LaTeX 论证。
书目元数据只在 `reference_library/sources.json` 维护；当前编译与资料完整性检查见
`reference_library/audit/validation.json`，数学/实现的适用边界见
`reference_library/audit/QUALITY_REVIEW.md`。资料整理未重跑本报告中的科学或 GUI 批次。

这些文献定义算法与不变量；官网结果只用于检验实现是否复现同一科学语义。
