"""Locate and dispatch prepared structures to the IsoVIZ visualizer."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

from ..config_loader import get_config


def cris_root() -> Path:
    return get_config().project_root.parent


def find_isoviz_launcher(root: Path | None = None) -> Path | None:
    """Return a shortcut, executable, or JAR if one is configured."""
    cfg = get_config()
    for env_name in cfg.isoviz_env_vars:
        env_path = os.environ.get(env_name)
        if env_path:
            candidate = Path(env_path).expanduser()
            if candidate.is_file():
                return candidate
    search_dirs = [root] if root is not None else cfg.launcher_search_dirs
    names = cfg.launcher_names or (
        "ISOViz.lnk",
        "IsoVIZ.lnk",
        "ISOVIZ.lnk",
        "IsoViz.exe",
        "ISOViz.exe",
        "IsoViz.jar",
        "ISOViz.jar",
        "isoviz.jar",
    )
    for base in search_dirs:
        if base is None:
            continue
        for name in names:
            hit = Path(base) / name
            if hit.is_file():
                return hit
    return None


def java_executable() -> str | None:
    return shutil.which("javaw") or shutil.which("java")


def open_isoviz(isoviz_file: Path, *, launcher: Path | None = None) -> None:
    """Open a ``.isoviz`` file using the configured shortcut, JAR, or executable."""
    target = isoviz_file.resolve()
    if not target.is_file():
        raise FileNotFoundError(f"IsoVIZ file not found: {target}")
    app = launcher or find_isoviz_launcher()
    if app is not None and app.suffix.lower() == ".jar":
        _run_jar(app, target)
        return
    if app is not None and app.suffix.lower() in {".exe", ".bat", ".cmd"}:
        subprocess.Popen([str(app), str(target)], close_fds=True)  # noqa: S603
        return
    if app is not None and app.suffix.lower() == ".lnk" and sys.platform.startswith("win"):
        # A configured shortcut is an explicit launcher choice.  Do not first
        # rely on the machine's possibly unrelated .isoviz file association.
        subprocess.Popen(  # noqa: S603 - configured local GUI launcher
            ["cmd", "/c", "start", "", str(app), str(target)],  # noqa: S607
            close_fds=True,
        )
        return
    if sys.platform.startswith("win"):
        try:
            os.startfile(str(target))  # type: ignore[attr-defined]  # noqa: S606
            return
        except OSError:
            pass
        if app is not None:
            subprocess.Popen(  # noqa: S603
                ["cmd", "/c", "start", "", str(app), str(target)],  # noqa: S607
                close_fds=True,
            )
            return
        raise RuntimeError(
            "Windows could not open the .isoviz file. Associate it with IsoVIZ, "
            "or place ISOViz.lnk in CRIS/local_tools/launchers, or set "
            "ISOVIZ / ISOVIZ_JAR."
        )
    if app is not None:
        subprocess.Popen([str(app), str(target)], close_fds=True)  # noqa: S603
        return
    raise RuntimeError(
        "IsoVIZ was not found. Install the Java IsoVIZ tool, or set ISOVIZ / ISOVIZ_JAR "
        "to the .exe / .jar path."
    )


def _run_jar(jar: Path, isoviz_file: Path) -> None:
    java = java_executable()
    if not java:
        raise RuntimeError("Java is required to launch IsoVIZ from a .jar file.")
    subprocess.Popen(  # noqa: S603
        [java, "-jar", str(jar), str(isoviz_file)],
        close_fds=True,
    )
