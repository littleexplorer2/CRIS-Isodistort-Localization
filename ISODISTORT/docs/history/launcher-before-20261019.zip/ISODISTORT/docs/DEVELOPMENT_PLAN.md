# 当前开发与验证计划

本文件只保存待办；已完成架构调整、理论影响和实测结果见
[验证报告](BUGFIX_VALIDATION_REPORT.md)。下载动作唯一入口是
[下载清单](DOWNLOAD_CHECKLIST.md)，任务状态见
[检验清单](manifests/validation_checklist_20261019.json)。

## 当前顺序

1. 补齐现有 Method 2 下载任务：102 查询保持不变，优先补 LD2/LD5、Y2/Y3/Y4
   共 5 张缺失列表，再按官网实际列表补其他查询；已有 94 个四件套继续引用原件。
2. 核定 Method 3/4 的独立输入、有限界限、daughter 指纹、基矢/原点及匹配合同。
   不使用官网结果反推输入，不恢复已撤销的闭包种子或 checkpoint。
3. 为满足前置条件的任务创建新运行签名，独立计算并冻结本地结果，再只读对照官网。
   工程回归和有限反例测试不能代替逐候选科学验收。
4. 在真实用户浏览器完成上传、连续动作、下载、取消、关闭及 GD 实际计算接收的人工验收；
   HTTP 自动化与转换器测试仅覆盖各自合同。

## 待修的程序漏洞

本轮已修复的缺陷及证据移入验证报告，不在这里重复维护。

以下目录迁移与后续架构问题仅完成只读检查，依用户要求未实施：

- P2：`main_requirement.py` 已在 ISODISTORT 根，但第 9 行仍用 `parents[2]`，
  得到 CRIS 的父目录，普通直接启动不能导入根部署器。后续同步根定位并增加任意 cwd 的入口测试。
  当前使用根 `setup_cris.py` 部署。
- P2：GUI 启动器已在 CRIS `launchers/`，但 ISOVIZ_INPUT 配置、缺省值、运行/部署提示
  及根 `.gitignore` 仍使用 `local_tools/launchers`。后续统一同步并验证发现与忽略规则；
  当前可用 `ISOVIZ` / `ISOVIZ_JAR` 显式指定。根 `.gitkeep` 不承担目录发现或忽略职责。
- P2：`frontend/web/index.html` 的一般响应会直接替换 `STATE`。并行请求的旧响应若晚于
  新母相响应到达，可回退前端 revision 并重新显示旧结果。静态调用链已确认，尚未做浏览器
  倒序响应复现。后续集中处理响应接收及结果表所属 revision，验证旧响应不会污染新上下文。

- WSL 诊断流可能混合 UTF-16 服务提示与 UTF-8 程序错误，当前整流解码会使后一段乱码。
  反例保存在 `output/validation/architecture_20261019/full-verified.log`；
  后续须固定混合编码输入合同并添加反例，再改进 `base_wrapper.py` 的错误文本解码。
  本轮已依据原始错误定位并修复目录寿命问题，尚未声称修复所有诊断编码。

后续遇到最小反例须登记受影响合同与证据；仍未支持的物理类型、输入域及缺证明能力
继续按照 `reference_library/coverage.json` 拒绝或标记 inconclusive，不能视为已修复。

## 待执行的优化计划

- 完成缺失官网结果集合的身份、角色、资源引用和 SHA-256 审计；不存在的结果不造占位。
- 完成已定义三晶体、四 Method 的独立科学验证，保留 unsupported/diagnostic/inconclusive。
- 仅在真实性能基线指出瓶颈后优化会话/运行目录复制成本；优化须保持事务隔离和生成数据库完整性。
- 根据实际新增用例扩充可执行模块边界与数学反例，禁止重新引入已移除的旧入口或答案缓存。

- P3（只读建议，未实施）：将 `application/workflows/service.py` 的动作处理器与事务策略
  合并为唯一登记；当前 `_ACTIONS` / `_MUTATIONS` 两份清单可能在新增动作时漏同步。
  本次未发现现有动作登记错误，后续验收应逐动作检查事务及 revision 策略。
